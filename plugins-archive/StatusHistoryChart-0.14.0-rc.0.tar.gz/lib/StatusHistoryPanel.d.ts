import type { PanelProps } from '@perses-dev/plugin-system';
import type { TimeSeriesData } from '@perses-dev/spec';
import type { ReactElement } from 'react';
import type { StatusHistoryChartOptions } from './status-history-model.js';
export type StatusHistoryChartPanelProps = PanelProps<StatusHistoryChartOptions, TimeSeriesData>;
export declare function StatusHistoryPanel(props: StatusHistoryChartPanelProps): ReactElement | null;
//# sourceMappingURL=StatusHistoryPanel.d.ts.map