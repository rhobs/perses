import type { LegendItem } from '@perses-dev/components';
import type { PanelData } from '@perses-dev/plugin-system';
import type { TimeScale, TimeSeriesData } from '@perses-dev/spec';
import type { StatusHistoryChartOptions } from '../status-history-model';
import type { StatusHistoryDataItem } from '../StatusHistoryChartBase';
interface StatusHistoryDataModel {
    legendItems: LegendItem[];
    statusHistoryData: StatusHistoryDataItem[];
    xAxisCategories: number[];
    yAxisCategories: string[];
    timeScale?: TimeScale;
    colors: Array<{
        value: string | number;
        color: string;
    }>;
}
export declare function useStatusHistoryDataModel(queryResults: Array<PanelData<TimeSeriesData>>, themeColors: string[], spec: StatusHistoryChartOptions): StatusHistoryDataModel;
export {};
//# sourceMappingURL=data-transform.d.ts.map