import type { OptionsEditorProps } from '@perses-dev/plugin-system';
import type { FC } from 'react';
import type { StatusHistoryChartOptions } from './status-history-model';
export type StatusHistoryValueMappingEditorProps = OptionsEditorProps<StatusHistoryChartOptions>;
export declare const StatusHistoryValueMappingEditor: FC<StatusHistoryValueMappingEditorProps>;
//# sourceMappingURL=StatusHistoryValueMappingEditor.d.ts.map