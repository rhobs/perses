import type { ValueMapping } from '@perses-dev/components';
import type { LegendSpecOptions, OptionsEditorProps } from '@perses-dev/plugin-system';
export declare function createInitialStatusHistoryChartOptions(): Record<string, unknown>;
export interface StatusHistoryChartOptions {
    legend?: LegendSpecOptions;
    mappings?: ValueMapping[];
    sorting?: StatusHistorySorting;
}
export type StatusHistorySorting = 'asc' | 'desc';
export type StatusHistroyChartEditorProps = OptionsEditorProps<StatusHistoryChartOptions>;
//# sourceMappingURL=status-history-model.d.ts.map