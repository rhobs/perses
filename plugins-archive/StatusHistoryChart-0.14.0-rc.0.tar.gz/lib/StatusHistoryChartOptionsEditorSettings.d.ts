import type { ReactElement } from 'react';
import type { StatusHistroyChartEditorProps } from './status-history-model.js';
export declare function StatusHistoryChartOptionsEditorSettings(props: StatusHistroyChartEditorProps): ReactElement;
//# sourceMappingURL=StatusHistoryChartOptionsEditorSettings.d.ts.map