import type { PanelPlugin } from '@perses-dev/plugin-system';
import type { StatusHistoryChartOptions } from './status-history-model';
import type { StatusHistoryChartPanelProps } from './StatusHistoryPanel';
export declare const StatusHistoryChart: PanelPlugin<StatusHistoryChartOptions, StatusHistoryChartPanelProps>;
//# sourceMappingURL=StatusHistoryChart.d.ts.map