import { DatasourcePlugin } from '@perses-dev/plugin-system';
import { VictoriaLogsClient } from '../../model/client';
import { VictoriaLogsDatasourceSpec } from './types';
export declare const VictoriaLogsDatasource: DatasourcePlugin<VictoriaLogsDatasourceSpec, VictoriaLogsClient>;
//# sourceMappingURL=VictoriaLogsDatasource.d.ts.map