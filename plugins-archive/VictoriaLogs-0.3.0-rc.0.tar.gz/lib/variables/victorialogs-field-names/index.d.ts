export * from './VictoriaLogsFieldNamesVariable';
//# sourceMappingURL=index.d.ts.map