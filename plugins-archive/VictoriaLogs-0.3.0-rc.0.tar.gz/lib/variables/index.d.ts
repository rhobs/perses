export * from './victorialogs-field-names';
export * from './victorialogs-field-values';
//# sourceMappingURL=index.d.ts.map