import { VariablePlugin } from '@perses-dev/plugin-system';
import { VictoriaLogsFieldValuesVariableOptions } from '../types';
export declare const VictoriaLogsFieldValuesVariable: VariablePlugin<VictoriaLogsFieldValuesVariableOptions>;
//# sourceMappingURL=VictoriaLogsFieldValuesVariable.d.ts.map