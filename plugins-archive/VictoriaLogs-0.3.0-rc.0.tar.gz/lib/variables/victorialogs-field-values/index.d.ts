export * from './VictoriaLogsFieldValuesVariable';
//# sourceMappingURL=index.d.ts.map