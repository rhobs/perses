import { LRLanguage } from '@codemirror/language';
import { Extension } from '@uiw/react-codemirror';
export declare function LogsQLExtension(): Array<LRLanguage | Extension>;
//# sourceMappingURL=logsql-extension.d.ts.map