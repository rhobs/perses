import { DatasourceSelector } from '@perses-dev/core';
export interface VictoriaLogsTimeSeriesQuerySpec {
    query: string;
    datasource?: DatasourceSelector;
    step?: string;
}
//# sourceMappingURL=types.d.ts.map