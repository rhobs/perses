export * from './victorialogs-time-series-query';
export * from './victorialogs-log-query';
//# sourceMappingURL=index.d.ts.map