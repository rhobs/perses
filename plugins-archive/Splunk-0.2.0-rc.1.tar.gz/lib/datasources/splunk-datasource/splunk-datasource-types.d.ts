import type { HTTPProxy } from '@perses-dev/spec';
export interface SplunkDatasourceSpec {
    directUrl?: string;
    proxy?: HTTPProxy;
}
//# sourceMappingURL=splunk-datasource-types.d.ts.map