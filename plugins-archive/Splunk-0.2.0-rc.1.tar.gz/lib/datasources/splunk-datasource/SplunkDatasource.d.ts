import type { DatasourcePlugin } from '@perses-dev/plugin-system';
import type { SplunkClient } from '../../model/splunk-client';
import type { SplunkDatasourceSpec } from './splunk-datasource-types';
export declare const SplunkDatasource: DatasourcePlugin<SplunkDatasourceSpec, SplunkClient>;
//# sourceMappingURL=SplunkDatasource.d.ts.map