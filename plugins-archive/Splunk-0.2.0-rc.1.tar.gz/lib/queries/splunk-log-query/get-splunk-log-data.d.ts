import type { LogQueryPlugin } from './log-query-plugin-interface';
import type { SplunkLogQuerySpec } from './splunk-log-query-types';
export declare const getSplunkLogData: LogQueryPlugin<SplunkLogQuerySpec>['getLogData'];
//# sourceMappingURL=get-splunk-log-data.d.ts.map