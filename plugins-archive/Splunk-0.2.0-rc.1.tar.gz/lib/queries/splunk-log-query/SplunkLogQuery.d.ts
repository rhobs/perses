import type { LogQueryPlugin } from './log-query-plugin-interface';
import type { SplunkLogQuerySpec } from './splunk-log-query-types';
export declare const SplunkLogQuery: LogQueryPlugin<SplunkLogQuerySpec>;
//# sourceMappingURL=SplunkLogQuery.d.ts.map