import type { TimeSeriesQueryPlugin } from '@perses-dev/plugin-system';
import type { SplunkTimeSeriesQuerySpec } from './splunk-time-series-query-types';
export declare const SplunkTimeSeriesQuery: TimeSeriesQueryPlugin<SplunkTimeSeriesQuerySpec>;
//# sourceMappingURL=SplunkTimeSeriesQuery.d.ts.map