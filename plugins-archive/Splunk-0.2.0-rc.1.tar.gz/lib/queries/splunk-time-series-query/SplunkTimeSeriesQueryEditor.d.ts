import type { OptionsEditorProps } from '@perses-dev/plugin-system';
import type { ReactElement } from 'react';
import type { SplunkTimeSeriesQuerySpec } from './splunk-time-series-query-types';
type SplunkQueryEditorProps = OptionsEditorProps<SplunkTimeSeriesQuerySpec>;
export declare function SplunkTimeSeriesQueryEditor(props: SplunkQueryEditorProps): ReactElement;
export {};
//# sourceMappingURL=SplunkTimeSeriesQueryEditor.d.ts.map