import type { TimeSeriesQueryPlugin } from '@perses-dev/plugin-system';
import type { SplunkTimeSeriesQuerySpec } from './splunk-time-series-query-types';
export declare const getSplunkTimeSeriesData: TimeSeriesQueryPlugin<SplunkTimeSeriesQuerySpec>['getTimeSeriesData'];
//# sourceMappingURL=get-splunk-time-series-data.d.ts.map