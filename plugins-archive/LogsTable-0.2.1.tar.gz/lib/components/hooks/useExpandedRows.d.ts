export interface UseExpandedRowsReturn {
    expandedRows: Set<number>;
    toggleExpand: (index: number) => void;
    clearExpanded: () => void;
}
export declare const useExpandedRows: () => UseExpandedRowsReturn;
//# sourceMappingURL=useExpandedRows.d.ts.map