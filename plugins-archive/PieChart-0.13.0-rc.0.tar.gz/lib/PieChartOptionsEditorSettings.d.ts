import { ReactElement } from 'react';
import { PieChartOptionsEditorProps } from './pie-chart-model';
export declare function PieChartOptionsEditorSettings(props: PieChartOptionsEditorProps): ReactElement;
//# sourceMappingURL=PieChartOptionsEditorSettings.d.ts.map