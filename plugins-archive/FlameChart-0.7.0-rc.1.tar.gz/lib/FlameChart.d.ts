import type { PanelPlugin } from '@perses-dev/plugin-system';
import type { FlameChartPanelProps } from './components';
import type { FlameChartOptions } from './flame-chart-model';
/**
 * The core FlameChart panel plugin for Perses.
 */
export declare const FlameChart: PanelPlugin<FlameChartOptions, FlameChartPanelProps>;
//# sourceMappingURL=FlameChart.d.ts.map