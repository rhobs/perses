import type { ProfileData } from '@perses-dev/spec';
import type { ReactElement } from 'react';
export interface TableChartProps {
    width: number;
    height: number;
    data: ProfileData;
    searchValue: string;
    onSearchValueChange: (value: string) => void;
    onSelectedIdChange: (id: number) => void;
}
export declare function TableChart(props: TableChartProps): ReactElement;
//# sourceMappingURL=TableChart.d.ts.map