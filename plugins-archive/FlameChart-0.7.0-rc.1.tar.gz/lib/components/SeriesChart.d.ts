import type { ProfileData } from '@perses-dev/spec';
import type { ReactElement } from 'react';
export interface SeriesChartProps {
    width: number;
    height: number;
    data: ProfileData;
}
export declare function SeriesChart(props: SeriesChartProps): ReactElement;
//# sourceMappingURL=SeriesChart.d.ts.map