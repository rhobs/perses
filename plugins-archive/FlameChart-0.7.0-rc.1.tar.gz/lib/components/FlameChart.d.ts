import type { ProfileData } from '@perses-dev/spec';
import type { ReactElement } from 'react';
export interface FlameChartProps {
    width: number;
    height: number;
    data: ProfileData;
    palette: 'package-name' | 'value';
    selectedId: number;
    searchValue: string;
    onSelectedIdChange: (newId: number) => void;
}
export declare function FlameChart(props: FlameChartProps): ReactElement;
//# sourceMappingURL=FlameChart.d.ts.map