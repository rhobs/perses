import type { PanelProps } from '@perses-dev/plugin-system';
import type { ProfileData } from '@perses-dev/spec';
import type { FC } from 'react';
import type { FlameChartOptions } from '../flame-chart-model';
export type FlameChartPanelProps = PanelProps<FlameChartOptions, ProfileData>;
export declare const FlameChartPanel: FC<FlameChartPanelProps>;
//# sourceMappingURL=FlameChartPanel.d.ts.map