import type { PanelPlugin } from '@perses-dev/plugin-system';
import type { HeatMapChartPanelProps } from './components';
import type { HeatMapChartOptions } from './heat-map-chart-model';
/**
 * The core HeatMapChart panel plugin for Perses.
 */
export declare const HeatMapChart: PanelPlugin<HeatMapChartOptions, HeatMapChartPanelProps>;
//# sourceMappingURL=HeatMapChart.d.ts.map