import type { PanelProps } from '@perses-dev/plugin-system';
import type { TimeSeriesData } from '@perses-dev/spec';
import type { ReactElement } from 'react';
import type { HeatMapChartOptions } from '../heat-map-chart-model';
export type HeatMapChartPanelProps = PanelProps<HeatMapChartOptions, TimeSeriesData>;
export declare function HeatMapChartPanel(props: HeatMapChartPanelProps): ReactElement | null;
//# sourceMappingURL=HeatMapChartPanel.d.ts.map