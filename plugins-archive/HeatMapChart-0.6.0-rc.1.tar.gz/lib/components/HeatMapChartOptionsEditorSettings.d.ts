import type { ReactElement } from 'react';
import type { HeatMapChartOptionsEditorProps } from '../heat-map-chart-model';
export declare function HeatMapChartOptionsEditorSettings(props: HeatMapChartOptionsEditorProps): ReactElement;
//# sourceMappingURL=HeatMapChartOptionsEditorSettings.d.ts.map