import type { Theme } from '@mui/material';
import type { FormatOptions } from '@perses-dev/components';
import type { HeatMapData } from './HeatMapChart';
interface CustomTooltipProps {
    data: HeatMapData;
    label: string;
    marker: string;
    xAxisCategories: number[];
    theme: Theme;
    yAxisFormat?: FormatOptions;
    countFormat?: FormatOptions;
}
export declare function generateTooltipHTML({ data, label, marker, xAxisCategories, theme, yAxisFormat, countFormat, }: CustomTooltipProps): string;
export {};
//# sourceMappingURL=HeatMapTooltip.d.ts.map