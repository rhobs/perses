import type { PanelData } from '@perses-dev/plugin-system';
import type { TimeScale, TimeSeriesData } from '@perses-dev/spec';
export declare function getCommonTimeScaleForQueries(queries: Array<PanelData<TimeSeriesData>>): TimeScale | undefined;
export declare function generateCompleteTimestamps(timescale?: TimeScale): number[];
//# sourceMappingURL=data-transform.d.ts.map