import type { PanelData } from '@perses-dev/plugin-system';
import type { QueryDefinition, TraceData } from '@perses-dev/spec';
import type { ReactElement } from 'react';
import type { TraceTableOptions } from './trace-table-model';
export type TraceLink = (params: {
    query: QueryDefinition;
    traceId: string;
}) => string;
export interface DataTableProps {
    options: TraceTableOptions;
    result: Array<PanelData<TraceData>>;
}
export declare function DataTable(props: DataTableProps): ReactElement;
//# sourceMappingURL=DataTable.d.ts.map