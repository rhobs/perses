import type { Theme } from '@mui/material';
import type { PersesChartsTheme } from '@perses-dev/components';
export declare function getServiceColor(muiTheme: Theme, chartsTheme: PersesChartsTheme, paletteMode: 'auto' | 'categorical' | undefined, serviceName: string, error?: boolean): string;
//# sourceMappingURL=utils.d.ts.map