import type { PanelProps } from '@perses-dev/plugin-system';
import type { TraceData } from '@perses-dev/spec';
import type { ReactElement } from 'react';
import type { TraceTableOptions } from './trace-table-model';
export type TraceTablePanelProps = PanelProps<TraceTableOptions, TraceData>;
export declare function TraceTablePanel(props: TraceTablePanelProps): ReactElement;
//# sourceMappingURL=TraceTablePanel.d.ts.map