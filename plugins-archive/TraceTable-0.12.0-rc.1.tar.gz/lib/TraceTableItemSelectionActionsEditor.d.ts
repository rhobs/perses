import type { OptionsEditorProps } from '@perses-dev/plugin-system';
import type { ReactElement } from 'react';
import type { TraceTableOptions } from './trace-table-model';
type TraceTableItemSelectionActionsEditorProps = OptionsEditorProps<TraceTableOptions>;
export declare function TraceTableItemSelectionActionsEditor(props: TraceTableItemSelectionActionsEditorProps): ReactElement;
export {};
//# sourceMappingURL=TraceTableItemSelectionActionsEditor.d.ts.map