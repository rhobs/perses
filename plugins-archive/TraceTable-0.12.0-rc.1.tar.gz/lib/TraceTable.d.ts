import type { PanelPlugin } from '@perses-dev/plugin-system';
import type { TraceTableOptions } from './trace-table-model';
import type { TraceTablePanelProps } from './TraceTablePanel';
/**
 * The core TraceTable panel plugin for Perses.
 */
export declare const TraceTable: PanelPlugin<TraceTableOptions, TraceTablePanelProps>;
//# sourceMappingURL=TraceTable.d.ts.map