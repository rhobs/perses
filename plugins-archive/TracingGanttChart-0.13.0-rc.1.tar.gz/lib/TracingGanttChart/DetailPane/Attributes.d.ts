import { ReactElement } from 'react';
import * as oltpcommonv1 from '@perses-dev/spec/dist/dashboard/query-type/otlp/common/v1/common';
import { Span, Trace } from '../trace';
import { CustomLinks } from '../../gantt-chart-model';
export interface TraceAttributesProps {
    customLinks?: CustomLinks;
    trace: Trace;
    span: Span;
}
export declare function TraceAttributes(props: TraceAttributesProps): ReactElement;
export interface AttributeListProps {
    customLinks?: CustomLinks;
    attributes: oltpcommonv1.KeyValue[];
}
export declare function AttributeList(props: AttributeListProps): ReactElement;
interface AttributeItemsProps {
    customLinks?: CustomLinks;
    attributes: oltpcommonv1.KeyValue[];
}
export declare function AttributeItems(props: AttributeItemsProps): ReactElement;
interface AttributeItemProps {
    name: string;
    value: string;
    link?: string;
}
export declare function AttributeItem(props: AttributeItemProps): ReactElement;
export declare function renderAttributeValue(value: oltpcommonv1.AnyValue): string;
export {};
//# sourceMappingURL=Attributes.d.ts.map