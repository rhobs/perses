import { ReactElement } from 'react';
import { Trace } from './trace';
import { SpanSearch } from './Search';
export interface TraceHeaderBarProps {
    trace: Trace;
    search: SpanSearch;
}
export declare function TraceHeaderBar(props: TraceHeaderBarProps): ReactElement;
//# sourceMappingURL=TraceHeaderBar.d.ts.map