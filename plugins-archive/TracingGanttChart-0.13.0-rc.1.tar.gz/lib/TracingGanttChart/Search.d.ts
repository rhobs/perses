import { ReactElement } from 'react';
import { Trace } from './trace';
export interface SearchBarProps {
    search: SpanSearch;
}
export declare function SearchBar(props: SearchBarProps): ReactElement;
export interface SpanSearch {
    searchQuery: string;
    setSearchQuery: (query: string) => void;
    matchingSpanIds: string[];
    focusedMatchIndex: number;
    setFocusedMatchIndex: (index: number) => void;
}
export declare function useSpanSearch(trace: Trace): SpanSearch;
//# sourceMappingURL=Search.d.ts.map