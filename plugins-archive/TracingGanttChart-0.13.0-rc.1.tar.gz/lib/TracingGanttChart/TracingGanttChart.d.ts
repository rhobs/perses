import { ReactElement } from 'react';
import * as otlptracev1 from '@perses-dev/spec/dist/dashboard/query-type/otlp/trace/v1/trace';
import { CustomLinks, TracingGanttChartOptions } from '../gantt-chart-model';
export interface TracingGanttChartProps {
    options: TracingGanttChartOptions;
    customLinks?: CustomLinks;
    trace: otlptracev1.TracesData;
}
/**
 * The core GanttChart panel for Perses.
 *
 * The UI/UX of this panel is based on Jaeger UI, licensed under Apache License, Version 2.0.
 * https://github.com/jaegertracing/jaeger-ui
 */
export declare function TracingGanttChart(props: TracingGanttChartProps): ReactElement;
//# sourceMappingURL=TracingGanttChart.d.ts.map