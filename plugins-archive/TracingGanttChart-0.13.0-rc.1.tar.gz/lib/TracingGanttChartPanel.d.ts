import { PanelProps } from '@perses-dev/plugin-system';
import { ReactElement } from 'react';
import { TraceData } from '@perses-dev/spec';
import { TracingGanttChartOptions } from './gantt-chart-model';
export type TracingGanttChartPanelProps = PanelProps<TracingGanttChartOptions, TraceData>;
export declare function TracingGanttChartPanel(props: TracingGanttChartPanelProps): ReactElement;
//# sourceMappingURL=TracingGanttChartPanel.d.ts.map