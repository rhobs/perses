import { PanelData } from '@perses-dev/plugin-system';
import { QueryDataType, UnknownSpec } from '@perses-dev/core';
import { ReactElement } from 'react';
interface EmbeddedPanelProps {
    kind: string;
    spec: UnknownSpec;
    queryResults: Array<PanelData<QueryDataType>>;
}
export declare function EmbeddedPanel({ kind, spec, queryResults }: EmbeddedPanelProps): ReactElement;
export {};
//# sourceMappingURL=EmbeddedPanel.d.ts.map