import { QueryParamValues } from '@perses-dev/components';
import { DatasourceSelectValue } from '@perses-dev/plugin-system';
import { DurationString, HTTPProxy } from '@perses-dev/spec';
import { PrometheusDatasourceSelector } from '../model';
export declare const DEFAULT_SCRAPE_INTERVAL: DurationString;
export interface PrometheusDatasourceSpec {
    directUrl?: string;
    proxy?: HTTPProxy;
    scrapeInterval?: DurationString;
    queryParams?: QueryParamValues;
}
export interface PrometheusVariableOptionsBase {
    datasource?: DatasourceSelectValue<PrometheusDatasourceSelector>;
}
export type PrometheusLabelNamesVariableOptions = PrometheusVariableOptionsBase & {
    matchers?: string[];
};
export type PrometheusLabelValuesVariableOptions = PrometheusVariableOptionsBase & {
    labelName: string;
    matchers?: string[];
};
export type PrometheusPromQLVariableOptions = PrometheusVariableOptionsBase & {
    expr: string;
    labelName: string;
};
export interface PrometheusPromQLAnnotationOptions {
    datasource?: DatasourceSelectValue<PrometheusDatasourceSelector>;
    expr: string;
    title?: string;
    legend?: string;
    tags?: string[];
}
//# sourceMappingURL=types.d.ts.map