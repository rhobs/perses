import { DatasourceSelectValue } from '@perses-dev/plugin-system';
import { DurationString } from '@perses-dev/spec';
import { PrometheusDatasourceSelector } from '../../model';
/**
 * The spec/options for the PrometheusTimeSeriesQuery plugin.
 */
export interface PrometheusTimeSeriesQuerySpec {
    query: string;
    seriesNameFormat?: string;
    minStep?: DurationString;
    resolution?: number;
    datasource?: DatasourceSelectValue<PrometheusDatasourceSelector>;
}
//# sourceMappingURL=time-series-query-model.d.ts.map