import { UseQueryResult } from '@tanstack/react-query';
import { DatasourceSelector } from '@perses-dev/spec';
import { StatusError } from '@perses-dev/client';
import { MonitoredInstantQueryResponse, ParseQueryResponse } from '../model';
export declare function useParseQuery(content: string, datasource: DatasourceSelector, enabled?: boolean): UseQueryResult<ParseQueryResponse, StatusError>;
export declare function useInstantQuery(content: string, datasource: DatasourceSelector, enabled?: boolean): UseQueryResult<MonitoredInstantQueryResponse, StatusError>;
//# sourceMappingURL=query.d.ts.map