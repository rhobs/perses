import { AnnotationData } from '@perses-dev/spec';
import { AnnotationContext } from '@perses-dev/plugin-system';
import { PrometheusPromQLAnnotationOptions } from '../plugins';
export declare const getAnnotationData: (spec: PrometheusPromQLAnnotationOptions, context: AnnotationContext, abortSignal?: AbortSignal) => Promise<AnnotationData[]>;
//# sourceMappingURL=get-annotation-data.d.ts.map