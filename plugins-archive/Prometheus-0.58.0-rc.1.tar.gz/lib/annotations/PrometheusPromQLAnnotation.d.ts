import { AnnotationPlugin } from '@perses-dev/plugin-system';
import { PrometheusPromQLAnnotationOptions } from '../plugins';
export declare const PrometheusPromQLAnnotation: AnnotationPlugin<PrometheusPromQLAnnotationOptions>;
//# sourceMappingURL=PrometheusPromQLAnnotation.d.ts.map