export * from './PrometheusPromQLAnnotation';
//# sourceMappingURL=index.d.ts.map