module: "github.com/perses/perses/cue@v0"
language: {
	version: "v0.16.1"
}
source: {
	kind: "git"
}
deps: {
	"github.com/perses/shared/cue@v0": {
		v:       "v0.54.0-rc.0"
		default: true
	}
	"github.com/perses/spec/cue@v0": {
		v:       "v0.2.0-beta.9"
		default: true
	}
}
