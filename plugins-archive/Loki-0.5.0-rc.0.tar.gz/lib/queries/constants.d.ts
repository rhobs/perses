export declare const DATASOURCE_KIND = "LokiDatasource";
export declare const DEFAULT_DATASOURCE: {
    kind: string;
};
//# sourceMappingURL=constants.d.ts.map