import { LokiLogQuerySpec } from './loki-log-query-types';
import { LogQueryPlugin } from './log-query-plugin-interface';
export declare const LokiLogQuery: LogQueryPlugin<LokiLogQuerySpec>;
//# sourceMappingURL=LokiLogQuery.d.ts.map