export { getPluginModule } from './getPluginModule';
export * from './model';
export * from './queries';
export * from './datasources';
//# sourceMappingURL=index.d.ts.map