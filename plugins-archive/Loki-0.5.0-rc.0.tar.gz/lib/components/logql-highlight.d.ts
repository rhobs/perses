export declare const logqlHighlight: import("@lezer/common").NodePropSource;
//# sourceMappingURL=logql-highlight.d.ts.map