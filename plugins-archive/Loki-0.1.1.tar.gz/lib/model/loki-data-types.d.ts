import { AbsoluteTimeRange, TimeSeries, TimeSeriesData, TimeSeriesMetadata } from '@perses-dev/core';
export interface LogEntry {
    timestamp: number;
    line: string;
    labels: Record<string, string>;
}
export interface LogsData {
    entries: LogEntry[];
    totalCount: number;
    hasMore?: boolean;
}
export interface LokiTimeSeriesData extends TimeSeriesData {
    logs?: LogsData;
    resultType?: 'matrix' | 'streams';
}
export interface LokiQueryResult {
    timeRange?: AbsoluteTimeRange;
    stepMs?: number;
    series: TimeSeries[];
    logs?: LogsData;
    resultType: 'matrix' | 'streams';
    metadata?: TimeSeriesMetadata;
}
//# sourceMappingURL=loki-data-types.d.ts.map