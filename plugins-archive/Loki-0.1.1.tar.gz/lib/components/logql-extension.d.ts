import { LRLanguage } from '@codemirror/language';
import { Extension } from '@uiw/react-codemirror';
export declare function LogQLExtension(): Array<LRLanguage | Extension>;
//# sourceMappingURL=logql-extension.d.ts.map