import { TimeSeriesQueryPlugin } from '@perses-dev/plugin-system';
import { LokiTimeSeriesQuerySpec } from './loki-time-series-query-types';
export declare const LokiTimeSeriesQuery: TimeSeriesQueryPlugin<LokiTimeSeriesQuerySpec>;
//# sourceMappingURL=LokiTimeSeriesQuery.d.ts.map