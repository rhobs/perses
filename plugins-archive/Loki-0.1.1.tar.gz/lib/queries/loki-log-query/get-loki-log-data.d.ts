import { LokiLogQuerySpec } from './loki-log-query-types';
import { LogQueryPlugin } from './log-query-plugin-interface';
export declare const getLokiLogData: LogQueryPlugin<LokiLogQuerySpec>['getLogData'];
//# sourceMappingURL=get-loki-log-data.d.ts.map