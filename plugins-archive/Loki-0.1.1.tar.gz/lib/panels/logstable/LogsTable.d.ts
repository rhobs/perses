import { PanelPlugin } from '@perses-dev/plugin-system';
import { LogsOptions, LogsProps } from './logs-types';
export declare const LogsTable: PanelPlugin<LogsOptions, LogsProps>;
//# sourceMappingURL=LogsTable.d.ts.map