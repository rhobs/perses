import { PanelProps } from '@perses-dev/plugin-system';
import { LokiTimeSeriesData } from '../../model/loki-data-types';
export type QueryData = LokiTimeSeriesData;
export type LogsProps = PanelProps<LogsOptions, QueryData>;
export interface LogsOptions {
    direction?: 'forward' | 'backward';
    wrap?: boolean;
    enableDetails?: boolean;
    time?: boolean;
}
//# sourceMappingURL=logs-types.d.ts.map