import { ReactElement } from 'react';
import { LogsProps } from './logs-types';
export declare function LogsTableComponent(props: LogsProps): ReactElement | null;
//# sourceMappingURL=LogsTableComponent.d.ts.map