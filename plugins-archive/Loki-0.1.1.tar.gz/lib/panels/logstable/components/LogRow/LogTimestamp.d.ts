import React from 'react';
interface LogTimestampProps {
    timestamp: number;
}
export declare const LogTimestamp: React.FC<LogTimestampProps>;
export {};
//# sourceMappingURL=LogTimestamp.d.ts.map