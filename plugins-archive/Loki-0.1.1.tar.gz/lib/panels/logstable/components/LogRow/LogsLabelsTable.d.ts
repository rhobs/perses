import React from 'react';
interface LogLabelsTableProps {
    labels: Record<string, string>;
}
export declare const LogLabelsTable: React.FC<LogLabelsTableProps>;
export {};
//# sourceMappingURL=LogsLabelsTable.d.ts.map