import React from 'react';
import { LogEntry } from '../../../model/loki-data-types';
import { LogsOptions } from '../logs-types';
interface VirtualizedLogsListProps {
    logs: LogEntry[];
    spec: LogsOptions;
    expandedRows: Set<number>;
    onToggleExpand: (index: number) => void;
}
export declare const VirtualizedLogsList: React.FC<VirtualizedLogsListProps>;
export {};
//# sourceMappingURL=VirtualizedLogsList.d.ts.map