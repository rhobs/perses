import { LogEntry } from '../../../model/loki-data-types';
export declare const getSeverity: (log: LogEntry) => "info" | "warn" | "error" | "debug" | "unknown";
//# sourceMappingURL=utils.d.ts.map