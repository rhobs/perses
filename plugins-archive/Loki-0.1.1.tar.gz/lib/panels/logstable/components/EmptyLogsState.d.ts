import React from 'react';
interface EmptyLogsStateProps {
    message?: string;
}
export declare const EmptyLogsState: React.FC<EmptyLogsStateProps>;
export {};
//# sourceMappingURL=EmptyLogsState.d.ts.map