import React from 'react';
import { LogEntry } from '../../../model/loki-data-types';
import { LogsOptions } from '../logs-types';
interface LogsListProps {
    logs: LogEntry[];
    spec: LogsOptions;
}
export declare const LogsList: React.FC<LogsListProps>;
export {};
//# sourceMappingURL=LogsList.d.ts.map