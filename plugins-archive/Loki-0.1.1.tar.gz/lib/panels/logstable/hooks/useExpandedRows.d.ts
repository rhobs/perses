export declare const useExpandedRows: () => {
    expandedRows: Set<number>;
    toggleExpand: (index: number) => void;
    clearExpanded: () => void;
};
//# sourceMappingURL=useExpandedRows.d.ts.map