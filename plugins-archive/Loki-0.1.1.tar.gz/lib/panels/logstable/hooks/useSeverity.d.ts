import { LogEntry } from '../../../model/loki-data-types';
export declare const useSeverityColor: (log?: LogEntry) => string;
//# sourceMappingURL=useSeverity.d.ts.map