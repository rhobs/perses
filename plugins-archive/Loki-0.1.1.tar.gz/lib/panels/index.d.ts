export * from './logstable';
//# sourceMappingURL=index.d.ts.map