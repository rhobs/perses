import type { ReactElement } from 'react';
import type { GaugeChartOptionsEditorProps } from './gauge-chart-model';
export declare function GaugeChartOptionsEditorSettings(props: GaugeChartOptionsEditorProps): ReactElement;
//# sourceMappingURL=GaugeChartOptionsEditorSettings.d.ts.map