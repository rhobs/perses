import type { PanelProps } from '@perses-dev/plugin-system';
import type { TimeSeriesData } from '@perses-dev/spec';
import type { ReactElement } from 'react';
import type { GaugeChartOptions } from './gauge-chart-model';
export type GaugeChartPanelProps = PanelProps<GaugeChartOptions, TimeSeriesData>;
export declare function GaugeChartPanel(props: GaugeChartPanelProps): ReactElement | null;
export declare function GaugeChartLoading({ contentDimensions }: GaugeChartPanelProps): React.ReactElement | null;
//# sourceMappingURL=GaugeChartPanel.d.ts.map