import type { PanelPlugin } from '@perses-dev/plugin-system';
import type { GaugeChartOptions } from './gauge-chart-model';
import type { GaugeChartPanelProps } from './GaugeChartPanel';
/**
 * The core GaugeChart panel plugin for Perses.
 */
export declare const GaugeChart: PanelPlugin<GaugeChartOptions, GaugeChartPanelProps>;
//# sourceMappingURL=GaugeChart.d.ts.map