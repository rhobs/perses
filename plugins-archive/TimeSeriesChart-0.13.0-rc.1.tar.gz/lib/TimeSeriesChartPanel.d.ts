import { ReactElement } from 'react';
import { PanelProps } from '@perses-dev/plugin-system';
import { TimeSeriesData } from '@perses-dev/spec';
import { TimeSeriesChartOptions } from './time-series-chart-model';
export type TimeSeriesChartProps = PanelProps<TimeSeriesChartOptions, TimeSeriesData>;
export declare function TimeSeriesChartPanel(props: TimeSeriesChartProps): ReactElement | null;
//# sourceMappingURL=TimeSeriesChartPanel.d.ts.map