import { MouseEvent } from 'react';
import type { EChartsCoreOption, GridComponentOption, YAXisComponentOption } from 'echarts';
import { ChartInstance, FormatOptions, TimeChartSeriesMapping, TooltipConfig, ZoomEventData } from '@perses-dev/components';
import { TimeScale, TimeSeries } from '@perses-dev/spec';
import { TimeSeriesAnnotation } from './utils/annotation';
export interface TimeChartProps {
    height: number;
    data: TimeSeries[];
    seriesMapping: TimeChartSeriesMapping;
    annotations?: TimeSeriesAnnotation[];
    timeScale?: TimeScale;
    yAxis?: YAXisComponentOption | YAXisComponentOption[];
    format?: FormatOptions;
    /**
     * Map of series ID to format options, used for tooltip formatting when series have different units
     */
    seriesFormatMap?: Map<string, FormatOptions>;
    grid?: GridComponentOption;
    tooltipConfig?: TooltipConfig;
    noDataVariant?: 'chart' | 'message';
    syncGroup?: string;
    isStackedBar?: boolean;
    onDataZoom?: (e: ZoomEventData) => void;
    onDoubleClick?: (e: MouseEvent) => void;
    __experimentalEChartsOptionsOverride?: (options: EChartsCoreOption) => EChartsCoreOption;
}
export declare const TimeSeriesChartBase: import("react").ForwardRefExoticComponent<TimeChartProps & import("react").RefAttributes<ChartInstance>>;
//# sourceMappingURL=TimeSeriesChartBase.d.ts.map