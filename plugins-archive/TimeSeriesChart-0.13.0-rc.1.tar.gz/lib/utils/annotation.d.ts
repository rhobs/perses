import { AnnotationData, AnnotationDisplay } from '@perses-dev/spec';
import { AnnotationSpecWithData } from '@perses-dev/dashboards';
export type TimeSeriesAnnotation = AnnotationData & AnnotationDisplay;
export declare function convertAnnotationToTimeSeriesAnnotation(annotations: AnnotationSpecWithData[]): TimeSeriesAnnotation[];
//# sourceMappingURL=annotation.d.ts.map