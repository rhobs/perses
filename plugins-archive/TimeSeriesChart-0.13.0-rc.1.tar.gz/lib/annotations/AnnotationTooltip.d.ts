import type { LineSeriesOption } from 'echarts';
import { CursorCoordinates } from '@perses-dev/components';
import { TimeSeriesAnnotation } from '../utils/annotation';
export interface AnnotationTooltipProps {
    annotation: TimeSeriesAnnotation;
    containerId?: string;
    formatWithUserTimeZone: (date: Date, formatString: string) => string;
    pinnedPos: CursorCoordinates | null;
    enablePinning?: boolean;
    onUnpinClick?: () => void;
}
export declare function AnnotationTooltip({ annotation, containerId, formatWithUserTimeZone, pinnedPos, enablePinning, onUnpinClick, }: AnnotationTooltipProps): JSX.Element | null;
/**
 * Build ECharts series options for rendering annotations as markArea (range),
 * markLine (vertical dashed lines) and markPoint (triangle markers under the X-axis).
 */
export declare function buildAnnotationSeries(annotations: TimeSeriesAnnotation[] | undefined): LineSeriesOption[];
//# sourceMappingURL=AnnotationTooltip.d.ts.map