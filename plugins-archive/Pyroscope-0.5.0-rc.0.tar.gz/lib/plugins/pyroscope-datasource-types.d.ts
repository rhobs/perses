import { HTTPProxy } from '@perses-dev/core';
export interface PyroscopeDatasourceSpec {
    directUrl?: string;
    proxy?: HTTPProxy;
}
//# sourceMappingURL=pyroscope-datasource-types.d.ts.map