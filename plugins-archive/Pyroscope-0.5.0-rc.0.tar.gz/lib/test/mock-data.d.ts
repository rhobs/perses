import { SearchProfileTypesResponse, SearchLabelNamesResponse, SearchLabelValuesResponse } from '../model/api-types';
export declare const MOCK_PROFILE_TYPES_RESPONSE: SearchProfileTypesResponse;
export declare const MOCK_LABEL_NAMES_RESPONSE: SearchLabelNamesResponse;
export declare const MOCK_LABEL_VALUES_RESPONSE_NAME_REGION: SearchLabelValuesResponse;
//# sourceMappingURL=mock-data.d.ts.map