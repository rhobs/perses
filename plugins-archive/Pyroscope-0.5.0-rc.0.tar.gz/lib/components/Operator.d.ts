import { ReactElement } from 'react';
export interface OperatorProps {
    value: string;
    onChange?(value: string): void;
}
export declare function Operator(props: OperatorProps): ReactElement;
//# sourceMappingURL=Operator.d.ts.map