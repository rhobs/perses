import type { FetchFn, RequestHeaders } from '@perses-dev/client';
export interface ClickHouseQueryParams {
    query: string;
    start?: string;
    end?: string;
    database?: string;
}
export interface ClickHouseQueryOptions {
    datasourceUrl: string;
    headers?: RequestHeaders;
    fetch?: FetchFn;
}
export interface ClickHouseQueryResponse {
    status: 'success' | 'error';
    data: unknown;
}
export interface ClickHouseClient {
    query: (params: {
        start: string;
        end: string;
        query: string;
    }) => Promise<ClickHouseQueryResponse>;
}
export declare function replaceTimeRangePlaceholders(query: string, start?: string, end?: string): string;
export declare function formatClickHouseDateTime(date: Date): string;
export declare function query(params: ClickHouseQueryParams, queryOptions: ClickHouseQueryOptions): Promise<ClickHouseQueryResponse>;
//# sourceMappingURL=click-house-client.d.ts.map