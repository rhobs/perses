import type { LogData, TimeSeriesData } from '@perses-dev/spec';
export interface ClickHouseTimeSeriesData extends TimeSeriesData {
    logs?: LogData;
}
export interface TimeSeriesEntry {
    time: string;
    [key: string]: number | string | null | undefined;
}
//# sourceMappingURL=click-house-data-types.d.ts.map