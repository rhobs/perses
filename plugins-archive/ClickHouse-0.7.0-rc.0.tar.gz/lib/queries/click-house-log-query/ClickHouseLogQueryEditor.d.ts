import type { OptionsEditorProps } from '@perses-dev/plugin-system';
import type { ReactElement } from 'react';
import type { ClickHouseLogQuerySpec } from './click-house-log-query-types';
type ClickHouseQueryEditorProps = OptionsEditorProps<ClickHouseLogQuerySpec>;
export declare function ClickHouseLogQueryEditor(props: ClickHouseQueryEditorProps): ReactElement;
export {};
//# sourceMappingURL=ClickHouseLogQueryEditor.d.ts.map