import type { TimeSeriesQueryPlugin } from '@perses-dev/plugin-system';
import type { ClickHouseTimeSeriesQuerySpec } from './click-house-query-types';
export declare const ClickHouseTimeSeriesQuery: TimeSeriesQueryPlugin<ClickHouseTimeSeriesQuerySpec>;
//# sourceMappingURL=ClickHouseQuery.d.ts.map