import type { OptionsEditorProps } from '@perses-dev/plugin-system';
import type { ReactElement } from 'react';
import type { ClickHouseTimeSeriesQuerySpec } from './click-house-query-types';
type ClickHouseTimeSeriesQueryEditorProps = OptionsEditorProps<ClickHouseTimeSeriesQuerySpec>;
export declare function ClickHouseTimeSeriesQueryEditor(props: ClickHouseTimeSeriesQueryEditorProps): ReactElement;
export {};
//# sourceMappingURL=ClickHouseQueryEditor.d.ts.map