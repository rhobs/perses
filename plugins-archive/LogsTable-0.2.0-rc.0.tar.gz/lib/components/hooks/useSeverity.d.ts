import { LogEntry } from '@perses-dev/core';
export declare const useSeverityColor: (log?: LogEntry) => string;
//# sourceMappingURL=useSeverity.d.ts.map