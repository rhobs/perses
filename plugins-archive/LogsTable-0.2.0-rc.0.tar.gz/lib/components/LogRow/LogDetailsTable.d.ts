import React from 'react';
import { Labels } from '@perses-dev/core';
interface LogDetailsTableProps {
    log: Labels;
}
export declare const LogDetailsTable: React.FC<LogDetailsTableProps>;
export {};
//# sourceMappingURL=LogDetailsTable.d.ts.map