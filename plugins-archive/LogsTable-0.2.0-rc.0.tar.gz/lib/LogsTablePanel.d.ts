import { ReactElement } from 'react';
import { LogsTableProps } from './model';
export declare function LogsTablePanel(props: LogsTableProps): ReactElement;
//# sourceMappingURL=LogsTablePanel.d.ts.map