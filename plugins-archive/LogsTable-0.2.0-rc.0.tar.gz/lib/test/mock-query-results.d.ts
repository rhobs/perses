import { LogsQueryData } from '../model';
export declare const MOCK_LOGS_QUERY_RESULT: LogsQueryData;
export declare const MOCK_LOGS_QUERY_DEFINITION: {
    kind: string;
    spec: {
        plugin: {
            kind: string;
            spec: {
                query: string;
            };
        };
    };
};
//# sourceMappingURL=mock-query-results.d.ts.map