import type { ReactElement } from 'react';
import type { CustomLinks } from '../../gantt-chart-model';
import type { Span } from '../trace';
export interface SpanLinkListProps {
    customLinks?: CustomLinks;
    span: Span;
}
export declare function SpanLinkList(props: SpanLinkListProps): ReactElement;
//# sourceMappingURL=SpanLinks.d.ts.map