import type { ReactElement } from 'react';
import type { CustomLinks } from '../../gantt-chart-model';
import type { Trace, Span } from '../trace';
export interface SpanEventListProps {
    customLinks?: CustomLinks;
    trace: Trace;
    span: Span;
}
export declare function SpanEventList(props: SpanEventListProps): ReactElement;
//# sourceMappingURL=SpanEvents.d.ts.map