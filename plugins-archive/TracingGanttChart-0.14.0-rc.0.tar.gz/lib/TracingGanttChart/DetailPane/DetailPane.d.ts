import type { ReactElement } from 'react';
import type { CustomLinks } from '../../gantt-chart-model';
import type { Span, Trace } from '../trace';
export interface DetailPaneProps {
    customLinks?: CustomLinks;
    trace: Trace;
    span: Span;
    onCloseBtnClick: () => void;
}
/**
 * DetailPane renders a sidebar showing the span attributes etc.
 */
export declare function DetailPane(props: DetailPaneProps): ReactElement;
//# sourceMappingURL=DetailPane.d.ts.map