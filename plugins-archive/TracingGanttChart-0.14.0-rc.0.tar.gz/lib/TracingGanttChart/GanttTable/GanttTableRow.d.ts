import type { CustomLinks, TracingGanttChartOptions } from '../../gantt-chart-model';
import type { Span } from '../trace';
import type { Viewport } from '../utils';
interface GanttTableRowProps {
    options: TracingGanttChartOptions;
    customLinks?: CustomLinks;
    span: Span;
    viewport: Viewport;
    /** this span is opened in the attribute pane */
    selected?: boolean;
    /** this span is matched in the search results */
    matched?: boolean;
    /** this span is focused by clicking prev/next in the search bar */
    focused?: boolean;
    nameColumnWidth: number;
    divider: React.ReactNode;
    onClick: (span: Span) => void;
}
export declare const GanttTableRow: import("react").MemoExoticComponent<(props: GanttTableRowProps) => import("react").JSX.Element>;
export {};
//# sourceMappingURL=GanttTableRow.d.ts.map