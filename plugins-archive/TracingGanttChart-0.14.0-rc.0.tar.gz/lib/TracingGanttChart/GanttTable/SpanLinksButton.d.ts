import type { ReactElement } from 'react';
import type { CustomLinks } from '../../gantt-chart-model';
import type { Span } from '../trace';
export interface SpanLinksButtonProps {
    customLinks: CustomLinks;
    span: Span;
}
export declare function SpanLinksButton(props: SpanLinksButtonProps): ReactElement | null;
//# sourceMappingURL=SpanLinksButton.d.ts.map