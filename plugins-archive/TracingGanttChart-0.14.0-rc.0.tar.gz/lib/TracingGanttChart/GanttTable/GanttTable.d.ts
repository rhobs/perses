import type { ReactElement } from 'react';
import type { CustomLinks, TracingGanttChartOptions } from '../../gantt-chart-model';
import type { Span, Trace } from '../trace';
import type { Viewport } from '../utils';
export interface GanttTableProps {
    options: TracingGanttChartOptions;
    customLinks?: CustomLinks;
    trace: Trace;
    viewport: Viewport;
    selectedSpan?: Span;
    onSpanClick: (span: Span) => void;
    matchingSpanIds?: string[];
    focusedSpanId?: string;
}
export declare function GanttTable(props: GanttTableProps): ReactElement;
//# sourceMappingURL=GanttTable.d.ts.map