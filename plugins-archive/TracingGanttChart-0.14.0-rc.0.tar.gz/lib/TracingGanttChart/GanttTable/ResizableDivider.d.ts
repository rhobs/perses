import type { ReactElement } from 'react';
interface ResizableDividerProps {
    parentRef: React.RefObject<Element>;
    onMove: (left: number) => void;
}
export declare function ResizableDivider(props: ResizableDividerProps): ReactElement;
export {};
//# sourceMappingURL=ResizableDivider.d.ts.map