import type { ReactElement } from 'react';
import type { Trace } from '../trace';
import type { Viewport } from '../utils';
interface GanttTableHeaderProps {
    trace: Trace;
    viewport: Viewport;
    nameColumnWidth: number;
    divider: React.ReactNode;
}
export declare function GanttTableHeader(props: GanttTableHeaderProps): ReactElement;
export {};
//# sourceMappingURL=GanttTableHeader.d.ts.map