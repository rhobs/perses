import type { ReactElement } from 'react';
import type { TracingGanttChartOptions } from '../../gantt-chart-model';
import type { Span } from '../trace';
import type { Viewport } from '../utils';
export interface SpanDurationProps {
    options: TracingGanttChartOptions;
    span: Span;
    viewport: Viewport;
}
/**
 * SpanDuration renders the right column of a SpanRow, i.e. the span bar and span duration
 */
export declare function SpanDuration(props: SpanDurationProps): ReactElement;
//# sourceMappingURL=SpanDuration.d.ts.map