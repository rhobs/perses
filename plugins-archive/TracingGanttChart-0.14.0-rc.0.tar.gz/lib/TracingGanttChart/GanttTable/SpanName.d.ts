import type { ReactElement } from 'react';
import type { CustomLinks } from '../../gantt-chart-model';
import type { Span } from '../trace';
export interface SpanNameProps {
    customLinks?: CustomLinks;
    span: Span;
    nameColumnWidth: number;
}
/**
 * SpanName renders the entire left column of a SpanRow, i.e. the hierarchy and the service and span name
 */
export declare function SpanName(props: SpanNameProps): ReactElement;
//# sourceMappingURL=SpanName.d.ts.map