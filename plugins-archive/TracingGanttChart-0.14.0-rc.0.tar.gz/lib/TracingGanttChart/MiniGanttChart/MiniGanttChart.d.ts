import type { ReactElement } from 'react';
import type { TracingGanttChartOptions } from '../../gantt-chart-model';
import type { Trace } from '../trace';
import type { Viewport } from '../utils';
interface MiniGanttChartProps {
    options: TracingGanttChartOptions;
    trace: Trace;
    viewport: Viewport;
    setViewport: (v: Viewport) => void;
}
export declare function MiniGanttChart(props: MiniGanttChartProps): ReactElement;
export {};
//# sourceMappingURL=MiniGanttChart.d.ts.map