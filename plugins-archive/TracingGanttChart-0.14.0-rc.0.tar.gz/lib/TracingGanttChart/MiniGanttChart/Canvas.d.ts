import type { ReactElement } from 'react';
import type { TracingGanttChartOptions } from '../../gantt-chart-model';
import type { Trace } from '../trace';
import type { Viewport } from '../utils';
interface CanvasProps {
    options: TracingGanttChartOptions;
    trace: Trace;
    viewport: Viewport;
    setViewport: (v: Viewport) => void;
}
export declare function Canvas(props: CanvasProps): ReactElement;
export {};
//# sourceMappingURL=Canvas.d.ts.map