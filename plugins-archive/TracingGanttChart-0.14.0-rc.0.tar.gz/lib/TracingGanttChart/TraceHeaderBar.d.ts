import type { ReactElement } from 'react';
import type { SpanSearch } from './Search';
import type { Trace } from './trace';
export interface TraceHeaderBarProps {
    trace: Trace;
    search: SpanSearch;
}
export declare function TraceHeaderBar(props: TraceHeaderBarProps): ReactElement;
//# sourceMappingURL=TraceHeaderBar.d.ts.map