import type { PanelPlugin } from '@perses-dev/plugin-system';
import type { TracingGanttChartOptions } from './gantt-chart-model';
import type { TracingGanttChartPanelProps } from './TracingGanttChartPanel';
export declare const TracingGanttChart: PanelPlugin<TracingGanttChartOptions, TracingGanttChartPanelProps>;
//# sourceMappingURL=TracingGanttChart.d.ts.map