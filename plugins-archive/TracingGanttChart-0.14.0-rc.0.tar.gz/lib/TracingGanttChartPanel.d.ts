import type { PanelProps } from '@perses-dev/plugin-system';
import type { TraceData } from '@perses-dev/spec';
import type { ReactElement } from 'react';
import type { TracingGanttChartOptions } from './gantt-chart-model';
export type TracingGanttChartPanelProps = PanelProps<TracingGanttChartOptions, TraceData>;
export declare function TracingGanttChartPanel(props: TracingGanttChartPanelProps): ReactElement;
//# sourceMappingURL=TracingGanttChartPanel.d.ts.map