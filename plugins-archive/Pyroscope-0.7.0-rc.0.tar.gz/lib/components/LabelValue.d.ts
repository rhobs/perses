import type { ReactElement } from 'react';
import type { PyroscopeDatasourceSelector } from '../model';
export interface LabelValueProps {
    datasource: PyroscopeDatasourceSelector;
    labelSelector: string;
    value: string;
    labelName: string;
    onChange?(value: string): void;
}
export declare function LabelValue(props: LabelValueProps): ReactElement;
//# sourceMappingURL=LabelValue.d.ts.map