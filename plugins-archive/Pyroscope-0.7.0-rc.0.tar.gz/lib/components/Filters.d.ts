import type { ReactElement } from 'react';
import type { PyroscopeDatasourceSelector } from '../model';
import type { LabelFilter } from '../utils/types';
export interface FiltersProps {
    datasource: PyroscopeDatasourceSelector;
    value: LabelFilter[];
    service?: string;
    profileType?: string;
    onChange?: (value: LabelFilter[]) => void;
}
export declare function Filters(props: FiltersProps): ReactElement;
//# sourceMappingURL=Filters.d.ts.map