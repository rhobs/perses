import type { ReactElement } from 'react';
import type { PyroscopeDatasourceSelector } from '../model';
export interface LabelNameProps {
    datasource: PyroscopeDatasourceSelector;
    labelSelector: string;
    value: string;
    onChange?(value: string): void;
}
export declare function LabelName(props: LabelNameProps): ReactElement;
//# sourceMappingURL=LabelName.d.ts.map