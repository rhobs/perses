import type { ReactElement } from 'react';
import type { PyroscopeDatasourceSelector } from '../model';
import type { LabelFilter } from '../utils/types';
export interface FilterItemProps {
    datasource: PyroscopeDatasourceSelector;
    labelSelector: string;
    value: LabelFilter;
    onChange?: (value: LabelFilter) => void;
    deleteItem?: () => void;
}
export declare function FilterItem(props: FilterItemProps): ReactElement;
//# sourceMappingURL=FilterItem.d.ts.map