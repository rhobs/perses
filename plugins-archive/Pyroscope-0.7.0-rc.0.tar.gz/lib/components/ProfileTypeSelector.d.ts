import type { ReactElement } from 'react';
import type { PyroscopeDatasourceSelector } from '../model';
export interface ProfileTypeSelectorProps {
    datasource: PyroscopeDatasourceSelector;
    value: string;
    service?: string;
    onChange?(value: string): void;
}
export declare function ProfileTypeSelector(props: ProfileTypeSelectorProps): ReactElement;
//# sourceMappingURL=ProfileTypeSelector.d.ts.map