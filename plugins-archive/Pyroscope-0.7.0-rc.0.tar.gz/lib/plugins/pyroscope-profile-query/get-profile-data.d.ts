import type { ProfileQueryPlugin } from '@perses-dev/plugin-system';
import type { AbsoluteTimeRange, StackTrace, Timeline } from '@perses-dev/spec';
import type { PyroscopeProfileQuerySpec, FlameGraph, Series } from '../../model';
export declare function getUnixTimeRange(timeRange: AbsoluteTimeRange): {
    start: number;
    end: number;
};
export declare const getProfileData: ProfileQueryPlugin<PyroscopeProfileQuerySpec>['getProfileData'];
export declare function transformFlameGraph(flamegraph: FlameGraph | undefined): {
    stackTrace: StackTrace;
    numTicks: number;
    maxSelf: number;
};
/**
 * Converts a Pyroscope SelectSeries response into the Perses timeline shape
 */
export declare function transformTimeline(series: Series[] | undefined, startMs: number, endMs: number, stepSeconds: number): Timeline;
//# sourceMappingURL=get-profile-data.d.ts.map