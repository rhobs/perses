import type { ReactElement } from 'react';
import type { ProfileQueryEditorProps } from './query-editor-model';
export declare function PyroscopeProfileQueryEditor(props: ProfileQueryEditorProps): ReactElement;
//# sourceMappingURL=PyroscopeProfileQueryEditor.d.ts.map