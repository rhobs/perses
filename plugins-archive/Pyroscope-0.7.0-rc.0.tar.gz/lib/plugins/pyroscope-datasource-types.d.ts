import type { DurationString, HTTPProxy } from '@perses-dev/spec';
export declare const DEFAULT_MIN_STEP: DurationString;
export interface PyroscopeDatasourceSpec {
    directUrl?: string;
    proxy?: HTTPProxy;
    minStep?: DurationString;
}
//# sourceMappingURL=pyroscope-datasource-types.d.ts.map