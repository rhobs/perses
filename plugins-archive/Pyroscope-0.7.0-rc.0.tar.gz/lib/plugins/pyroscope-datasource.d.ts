import type { DatasourcePlugin } from '@perses-dev/plugin-system';
import type { PyroscopeClient } from '../model/pyroscope-client';
import type { PyroscopeDatasourceSpec } from './pyroscope-datasource-types';
export declare const PyroscopeDatasource: DatasourcePlugin<PyroscopeDatasourceSpec, PyroscopeClient>;
//# sourceMappingURL=pyroscope-datasource.d.ts.map