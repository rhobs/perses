import type { FetchFn, RequestHeaders } from '@perses-dev/client';
import type { DatasourceClient } from '@perses-dev/plugin-system';
import type { SearchProfileTypesParameters, SearchProfileTypesResponse, SearchLabelNamesParameters, SearchLabelNamesResponse, SearchLabelValuesParameters, SearchLabelValuesResponse, SelectMergeStacktracesRequest, SelectMergeStacktracesResponse, SelectSeriesRequest, SelectSeriesResponse } from './api-types';
interface PyroscopeClientOptions {
    datasourceUrl: string;
    headers?: RequestHeaders;
    minStepSeconds?: number;
}
export interface PyroscopeClient extends DatasourceClient {
    options: PyroscopeClientOptions;
    selectMergeStacktraces(body: SelectMergeStacktracesRequest, headers?: RequestHeaders): Promise<SelectMergeStacktracesResponse>;
    selectSeries(body: SelectSeriesRequest, headers?: RequestHeaders): Promise<SelectSeriesResponse>;
    searchProfileTypes(params: SearchProfileTypesParameters, headers: RequestHeaders, body: Record<string, string | number>): Promise<SearchProfileTypesResponse>;
    searchLabelNames(params: SearchLabelNamesParameters, headers: RequestHeaders, body: Record<string, string | number | string[]>): Promise<SearchLabelNamesResponse>;
    searchLabelValues(params: SearchLabelValuesParameters, headers: RequestHeaders, body: Record<string, string | number | string[]>): Promise<SearchLabelValuesResponse>;
    searchServices(params: SearchLabelValuesParameters, headers: RequestHeaders, body: Record<string, string | number>): Promise<SearchLabelValuesResponse>;
}
export interface QueryOptions {
    datasourceUrl: string;
    headers?: RequestHeaders;
    fetch?: FetchFn;
}
export declare const executeRequest: <T>(customFetch: FetchFn | undefined, ...args: Parameters<typeof global.fetch>) => Promise<T>;
/**
 * Returns the flame graph for the matching profiles.
 */
export declare function selectMergeStacktraces(body: SelectMergeStacktracesRequest, queryOptions: QueryOptions): Promise<SelectMergeStacktracesResponse>;
/**
 * Returns the time series (timeline) for the matching profiles.
 */
export declare function selectSeries(body: SelectSeriesRequest, queryOptions: QueryOptions): Promise<SelectSeriesResponse>;
/**
 * Returns a list of all profile types.
 */
export declare function searchProfileTypes(params: SearchProfileTypesParameters, queryOptions: QueryOptions, body: Record<string, string | number>): Promise<SearchProfileTypesResponse>;
/**
 * Returns a list of all label names.
 */
export declare function searchLabelNames(params: SearchLabelNamesParameters, queryOptions: QueryOptions, body: Record<string, string | number | string[]>): Promise<SearchLabelNamesResponse>;
/**
 * Returns a list of all label values for a given label name.
 */
export declare function searchLabelValues(params: SearchLabelValuesParameters, queryOptions: QueryOptions, body: Record<string, string | number | string[]>): Promise<SearchLabelValuesResponse>;
/**
 * Returns a list of all services.
 * This is a special case of label values where the label name is "service_name".
 */
export declare function searchServices(params: SearchLabelValuesParameters, queryOptions: QueryOptions, body: Record<string, string | number>): Promise<SearchLabelValuesResponse>;
export {};
//# sourceMappingURL=pyroscope-client.d.ts.map