import type { StatusError } from '@perses-dev/client';
import type { DatasourceSelector } from '@perses-dev/spec';
import type { UseQueryResult } from '@tanstack/react-query';
import type { SearchLabelNamesResponse, SearchLabelValuesResponse, SearchProfileTypesResponse } from '../model';
export declare function useLabelNames(datasource: DatasourceSelector, labelSelector: string): UseQueryResult<SearchLabelNamesResponse, StatusError>;
export declare function useLabelValues(datasource: DatasourceSelector, labelName: string, labelSelector: string): UseQueryResult<SearchLabelValuesResponse, StatusError>;
export declare function useProfileTypes(datasource: DatasourceSelector, service?: string): UseQueryResult<SearchProfileTypesResponse, StatusError>;
export declare function useServices(datasource: DatasourceSelector): UseQueryResult<SearchLabelValuesResponse, StatusError>;
export declare function filterLabelNamesOptions(labelNamesOptions: string[]): string[];
//# sourceMappingURL=use-query.d.ts.map