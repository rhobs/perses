export type OperatorType = '=' | '!=' | '=~' | '!~';
export interface LabelFilter {
    labelName: string;
    labelValue: string;
    operator: OperatorType;
}
export declare function computeFilterExpr(filters: LabelFilter[]): string;
/**
 * Builds the selector used to scope label name/value lookups, e.g. `{service_name="app",__profile_type__="..."}`.
 * Returns an empty string when no service is set: Pyroscope only narrows the blocks it reads on `service_name`,
 * so an unscoped lookup scans every block in the time range and can exceed the query-backend concurrency limit.
 */
export declare function computeLabelScopeSelector(service?: string, profileType?: string): string;
//# sourceMappingURL=types.d.ts.map