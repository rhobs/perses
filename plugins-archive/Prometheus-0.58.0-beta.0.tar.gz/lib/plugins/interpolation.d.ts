import { DatasourceSelector, DatasourceSpec } from '@perses-dev/core';
import { VariableStateMap } from '@perses-dev/components';
import { DatasourceStore } from '@perses-dev/plugin-system';
import { ClientRequestOptions, PrometheusClient } from '../model';
import { PrometheusDatasourceSpec } from './types';
export interface ResolvedPrometheusDatasource {
    client: PrometheusClient;
    requestOptions: ClientRequestOptions;
}
export declare function resolvePrometheusDatasource(datasourceStore: DatasourceStore, selector: DatasourceSelector, variableState: VariableStateMap): Promise<ResolvedPrometheusDatasource>;
export declare function interpolateDatasourceProxyParams(datasource: DatasourceSpec<PrometheusDatasourceSpec>, variableState: VariableStateMap): ClientRequestOptions;
//# sourceMappingURL=interpolation.d.ts.map