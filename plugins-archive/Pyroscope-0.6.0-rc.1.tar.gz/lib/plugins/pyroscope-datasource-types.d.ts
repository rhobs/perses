import { HTTPProxy } from '@perses-dev/spec';
export interface PyroscopeDatasourceSpec {
    directUrl?: string;
    proxy?: HTTPProxy;
}
//# sourceMappingURL=pyroscope-datasource-types.d.ts.map