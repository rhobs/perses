import { UseQueryResult } from '@tanstack/react-query';
import { DatasourceSelector } from '@perses-dev/spec';
import { StatusError } from '@perses-dev/client';
import { SearchLabelNamesResponse, SearchLabelValuesResponse, SearchProfileTypesResponse } from '../model';
export declare function useLabelNames(datasource: DatasourceSelector): UseQueryResult<SearchLabelNamesResponse, StatusError>;
export declare function useLabelValues(datasource: DatasourceSelector, labelName: string): UseQueryResult<SearchLabelValuesResponse, StatusError>;
export declare function useProfileTypes(datasource: DatasourceSelector): UseQueryResult<SearchProfileTypesResponse, StatusError>;
export declare function useServices(datasource: DatasourceSelector): UseQueryResult<SearchLabelValuesResponse, StatusError>;
export declare function filterLabelNamesOptions(labelNamesOptions: string[]): string[];
//# sourceMappingURL=use-query.d.ts.map