import { LabelFilter } from '../utils/types';
import { PyroscopeDatasourceSelector } from './pyroscope-selectors';
/**
 * The spec/options for the PyroscopeProfileQuery plugin.
 */
export interface PyroscopeProfileQuerySpec {
    datasource?: PyroscopeDatasourceSelector;
    maxNodes?: number;
    profileType: string;
    filters?: LabelFilter[];
    service?: string;
}
/**
 * A Pyroscope profile query needs at least a service and a profile type to be executable.
 * When either is missing, the query is considered incomplete and should not be run.
 */
export declare function isProfileQueryComplete(spec: Partial<Pick<PyroscopeProfileQuerySpec, 'service' | 'profileType'>>): boolean;
//# sourceMappingURL=profile-query-model.d.ts.map