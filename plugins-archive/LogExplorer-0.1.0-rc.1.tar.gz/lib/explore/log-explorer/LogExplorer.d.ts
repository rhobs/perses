import { ReactElement } from 'react';
export declare function LogExplorer(): ReactElement;
//# sourceMappingURL=LogExplorer.d.ts.map