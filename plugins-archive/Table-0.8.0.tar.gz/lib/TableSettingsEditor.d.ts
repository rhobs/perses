import { ReactElement } from 'react';
import { TableSettingsEditorProps } from './table-model';
export declare function TableSettingsEditor({ onChange, value }: TableSettingsEditorProps): ReactElement;
//# sourceMappingURL=TableSettingsEditor.d.ts.map