import type { ReactCodeMirrorProps } from '@uiw/react-codemirror';
import type { ReactElement } from 'react';
export declare function GreptimeDBQLEditor(props: ReactCodeMirrorProps): ReactElement;
//# sourceMappingURL=GreptimeDBQLEditor.d.ts.map