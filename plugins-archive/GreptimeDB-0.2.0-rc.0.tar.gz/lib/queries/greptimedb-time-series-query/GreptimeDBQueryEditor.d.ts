import type { OptionsEditorProps } from '@perses-dev/plugin-system';
import type { ReactElement } from 'react';
import type { GreptimeDBTimeSeriesQuerySpec } from './greptimedb-query-types';
type GreptimeDBTimeSeriesQueryEditorProps = OptionsEditorProps<GreptimeDBTimeSeriesQuerySpec>;
export declare function GreptimeDBTimeSeriesQueryEditor(props: GreptimeDBTimeSeriesQueryEditorProps): ReactElement;
export {};
//# sourceMappingURL=GreptimeDBQueryEditor.d.ts.map