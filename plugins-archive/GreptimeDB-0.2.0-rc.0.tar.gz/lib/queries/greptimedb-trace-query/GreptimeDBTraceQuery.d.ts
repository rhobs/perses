import type { TraceQueryPlugin } from '@perses-dev/plugin-system';
import type { GreptimeDBTraceQuerySpec } from './greptimedb-trace-query-types';
export declare const GreptimeDBTraceQuery: TraceQueryPlugin<GreptimeDBTraceQuerySpec>;
//# sourceMappingURL=GreptimeDBTraceQuery.d.ts.map