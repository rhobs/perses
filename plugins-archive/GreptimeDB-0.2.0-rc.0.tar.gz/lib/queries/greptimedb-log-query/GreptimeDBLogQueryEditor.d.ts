import type { OptionsEditorProps } from '@perses-dev/plugin-system';
import type { ReactElement } from 'react';
import type { GreptimeDBLogQuerySpec } from './greptimedb-log-query-types';
type GreptimeDBLogQueryEditorProps = OptionsEditorProps<GreptimeDBLogQuerySpec>;
export declare function GreptimeDBLogQueryEditor(props: GreptimeDBLogQueryEditorProps): ReactElement;
export {};
//# sourceMappingURL=GreptimeDBLogQueryEditor.d.ts.map