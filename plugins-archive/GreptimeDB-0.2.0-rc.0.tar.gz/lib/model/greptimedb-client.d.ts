import type { FetchFn, RequestHeaders } from '@perses-dev/client';
import type { GreptimeDBDatasourceResponse, GreptimeDBQueryRequestParameters } from '../datasources/greptimedb-datasource';
import type { GreptimeDBResponseData } from './greptimedb-data-types';
export interface GreptimeDBQueryOptions {
    datasourceUrl: string;
    headers?: RequestHeaders;
    fetch?: FetchFn;
}
export interface GreptimeDBQueryResponse {
    status: 'success' | 'error';
    data: GreptimeDBResponseData;
    error?: string;
}
export interface GreptimeDBClient {
    query: (params: GreptimeDBQueryRequestParameters) => Promise<GreptimeDBQueryResponse>;
}
export declare function greptimedbQuery(params: GreptimeDBQueryRequestParameters, queryOptions: GreptimeDBQueryOptions): Promise<GreptimeDBDatasourceResponse>;
//# sourceMappingURL=greptimedb-client.d.ts.map