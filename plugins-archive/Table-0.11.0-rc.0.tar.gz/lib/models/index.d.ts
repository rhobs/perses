export * from './model';
export * from './table-model';
//# sourceMappingURL=index.d.ts.map