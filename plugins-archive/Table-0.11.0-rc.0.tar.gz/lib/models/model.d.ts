import { PanelProps } from '@perses-dev/plugin-system';
interface TimeSeriesTableOptions {
}
export type TimeSeriesTableProps = PanelProps<TimeSeriesTableOptions>;
export {};
//# sourceMappingURL=model.d.ts.map