import { ReactElement } from 'react';
import { ColumnEditorProps } from './ColumnEditor';
export type Props = Pick<ColumnEditorProps, 'onChange' | 'column'>;
export declare const DataLinkEditor: (props: Props) => ReactElement;
//# sourceMappingURL=DataLinkEditorDialog.d.ts.map