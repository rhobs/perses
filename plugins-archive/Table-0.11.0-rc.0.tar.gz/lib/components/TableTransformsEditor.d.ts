import { ReactElement } from 'react';
import { TableSettingsEditorProps } from '../models';
export declare function TableTransformsEditor({ value, onChange }: TableSettingsEditorProps): ReactElement;
//# sourceMappingURL=TableTransformsEditor.d.ts.map