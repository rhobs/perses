import type { PanelPlugin } from '@perses-dev/plugin-system';
import type { TimeSeriesChartOptions } from './time-series-chart-model';
import type { TimeSeriesChartProps } from './TimeSeriesChartPanel';
export declare const TimeSeriesChart: PanelPlugin<TimeSeriesChartOptions, TimeSeriesChartProps>;
//# sourceMappingURL=TimeSeriesChart.d.ts.map