import type { ReactElement } from 'react';
export declare function ColorSwatches({ colors }: {
    colors: readonly string[];
}): ReactElement;
//# sourceMappingURL=ColorSwatches.d.ts.map