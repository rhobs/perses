import type { ReactElement } from 'react';
import type { TimeSeriesChartPaletteOptions } from '../time-series-chart-model';
export interface PaletteSelectorProps {
    value: TimeSeriesChartPaletteOptions | undefined;
    onChange: (palette: TimeSeriesChartPaletteOptions | undefined) => void;
}
export declare function PaletteSelector({ value, onChange }: PaletteSelectorProps): ReactElement;
//# sourceMappingURL=PaletteSelector.d.ts.map