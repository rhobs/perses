import type { PanelProps } from '@perses-dev/plugin-system';
import type { TimeSeriesData } from '@perses-dev/spec';
import type { ReactElement } from 'react';
import type { TimeSeriesChartOptions } from './time-series-chart-model';
export type TimeSeriesChartProps = PanelProps<TimeSeriesChartOptions, TimeSeriesData>;
declare function TimeSeriesChartPanelComponent(props: TimeSeriesChartProps): ReactElement | null;
export declare const TimeSeriesChartPanel: import("react").MemoExoticComponent<typeof TimeSeriesChartPanelComponent>;
export {};
//# sourceMappingURL=TimeSeriesChartPanel.d.ts.map