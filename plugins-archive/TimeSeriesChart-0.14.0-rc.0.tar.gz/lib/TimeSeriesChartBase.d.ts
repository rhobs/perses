import type { ChartInstance, FormatOptions, TimeChartSeriesMapping, TooltipConfig, ZoomEventData } from '@perses-dev/components';
import type { TimeScale, TimeSeries } from '@perses-dev/spec';
import type { EChartsCoreOption, GridComponentOption, YAXisComponentOption } from 'echarts';
import type { MouseEvent } from 'react';
import type { TimeSeriesAnnotation } from './utils/annotation';
import type { ExemplarChartData } from './utils/data-transform';
export interface TimeChartProps {
    height: number;
    data: TimeSeries[];
    seriesMapping: TimeChartSeriesMapping;
    /** All exemplar groups; only groups matching a visible series are rendered. */
    exemplars?: ExemplarChartData[];
    annotations?: TimeSeriesAnnotation[];
    timeScale?: TimeScale;
    yAxis?: YAXisComponentOption | YAXisComponentOption[];
    format?: FormatOptions;
    /**
     * Map of series ID to format options, used for tooltip formatting when series have different units
     */
    seriesFormatMap?: Map<string, FormatOptions>;
    grid?: GridComponentOption;
    tooltipConfig?: TooltipConfig;
    noDataVariant?: 'chart' | 'message';
    syncGroup?: string;
    isStackedBar?: boolean;
    onDataZoom?: (e: ZoomEventData) => void;
    onDoubleClick?: (e: MouseEvent) => void;
    __experimentalEChartsOptionsOverride?: (options: EChartsCoreOption) => EChartsCoreOption;
}
export declare const TimeSeriesChartBase: import("react").ForwardRefExoticComponent<TimeChartProps & import("react").RefAttributes<ChartInstance>>;
//# sourceMappingURL=TimeSeriesChartBase.d.ts.map