import React from 'react';
import type { TimeSeriesChartProps } from './TimeSeriesChartPanel';
export declare const TimeSeriesExportAction: React.FC<TimeSeriesChartProps>;
//# sourceMappingURL=TimeSeriesExportAction.d.ts.map