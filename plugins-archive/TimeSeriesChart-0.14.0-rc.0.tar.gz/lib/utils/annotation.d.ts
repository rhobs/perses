import type { AnnotationSpecWithData } from '@perses-dev/dashboards';
import type { AnnotationData, AnnotationDisplay } from '@perses-dev/spec';
export type TimeSeriesAnnotation = AnnotationData & AnnotationDisplay;
export declare function convertAnnotationToTimeSeriesAnnotation(annotations: AnnotationSpecWithData[]): TimeSeriesAnnotation[];
//# sourceMappingURL=annotation.d.ts.map