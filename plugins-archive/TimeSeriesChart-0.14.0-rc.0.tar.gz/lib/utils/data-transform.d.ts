import type { LegacyTimeSeries, EChartsDataFormat, TimeSeriesOption, StepOptions } from '@perses-dev/components';
import type { useTimeSeriesQueries, PanelData } from '@perses-dev/plugin-system';
import type { Exemplar, Labels, TimeScale, TimeSeries, TimeSeriesData } from '@perses-dev/spec';
import type { YAXisComponentOption } from 'echarts';
import type { LineSeriesOption, ScatterSeriesOption } from 'echarts/charts';
import type { TimeSeriesChartVisualOptions, TimeSeriesChartYAxisOptions, LineStyleType } from '../time-series-chart-model';
export type RunningQueriesState = ReturnType<typeof useTimeSeriesQueries>;
export declare const EMPTY_GRAPH_DATA: EChartsDataFormat;
export declare const HIDE_DATAPOINTS_LIMIT = 70;
export declare const BLUR_FADEOUT_OPACITY = 0.5;
export declare const EXEMPLAR_SERIES_ID_PREFIX = "exemplar-";
export declare const EXEMPLAR_SYMBOL_SIZE = 14;
/**
 * The exemplars of one series, converted to a chart-friendly shape with the
 * rendering attributes (color, y axis) of the matching time series.
 */
export interface ExemplarChartData {
    seriesId: string;
    seriesName: string;
    color: string;
    seriesLabels?: Labels;
    yAxisIndex?: number;
    /**
     * When the matching series is rendered with `querySettings.negativeY`, its values are
     * visually negated so it renders below the X axis. The same transform is applied to
     * the exemplar markers' plotted Y values so they stay next to their series. The
     * original (positive) values remain on each `exemplar` for metadata display.
     */
    negativeY?: boolean;
    exemplars: Exemplar[];
}
/**
 * Given a list of running queries, calculates a common time scale for use on
 * the x axis (i.e. start/end dates and a step that is divisible into all of
 * the queries' steps).
 */
export declare function getCommonTimeScaleForQueries(queries: Array<PanelData<TimeSeriesData>>): TimeScale | undefined;
/**
 * Gets ECharts line series option properties for regular trends
 */
export declare function getTimeSeries(id: string, datasetIndex: number, formattedName: string, visual: TimeSeriesChartVisualOptions, timeScale: TimeScale, paletteColor: string, querySettings?: {
    lineStyle?: LineStyleType;
    areaOpacity?: number;
    stack?: boolean;
}, yAxisIndex?: number, visibleSeriesCount?: number): TimeSeriesOption;
/**
 * Gets an ECharts scatter series rendering exemplar markers for a single series.
 * Each data item embeds its exemplar (and series labels) so the metadata dialog
 * can be populated when a marker is clicked.
 */
export declare function getExemplarSeries(data: ExemplarChartData): ScatterSeriesOption;
/**
 * Gets threshold-specific line series styles
 * markLine cannot be used since it does not update yAxis max / min
 * and threshold data needs to show in the tooltip
 */
export declare function getThresholdSeries(name: string, threshold: StepOptions, seriesIndex: number): LineSeriesOption;
/**
 * Converts percent threshold into absolute step value
 * If max is undefined, use the max value from time series data as default
 */
export declare function convertPercentThreshold(percent: number, data: LegacyTimeSeries[] | TimeSeries[], max?: number, min?: number): number;
/**
 * Converts Perses panel yAxis from dashboard spec to ECharts supported yAxis options.
 * Handles both linear and logarithmic scales with appropriate min/max calculations.
 */
export declare function convertPanelYAxis(inputAxis?: TimeSeriesChartYAxisOptions): YAXisComponentOption;
/**
 * Rounds down to nearest number with one significant digit.
 *
 * Examples:
 * 1. 675 --> 600
 * 2. 0.567 --> 0.5
 * 3. -12 --> -20
 */
export declare function roundDown(num: number): number;
//# sourceMappingURL=data-transform.d.ts.map