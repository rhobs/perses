// Copyright The Perses Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package model

import (
	"github.com/perses/shared/cue/common"
	"github.com/perses/spec/cue/datasource"
)

#kind: "GreptimeDBDatasource"

kind: #kind
spec: {
	datasource.#HTTPDatasourceSpec

	// headers are forwarded on GreptimeDB SQL API requests (e.g. Authorization).
	// Used with directUrl when the Perses server is not proxying traffic; the host app may inject
	// headers at datasource init instead of storing credentials in dashboard JSON.
	// When using proxy, prefer proxy.spec.headers or proxy.spec.secret for sensitive values.
	headers?: {[string]: string}
}

#selector: common.#datasourceSelector & {_kind: #kind}
