import { ReactCodeMirrorProps } from '@uiw/react-codemirror';
import { ReactElement } from 'react';
export declare function GreptimeDBQLEditor(props: ReactCodeMirrorProps): ReactElement;
//# sourceMappingURL=GreptimeDBQLEditor.d.ts.map