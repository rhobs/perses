import { RequestHeaders } from '@perses-dev/client';
import { GreptimeDBDatasourceResponse, GreptimeDBQueryRequestParameters } from '../datasources/greptimedb-datasource';
import { GreptimeDBResponseData } from './greptimedb-data-types';
export interface GreptimeDBQueryOptions {
    datasourceUrl: string;
    headers?: RequestHeaders;
}
export interface GreptimeDBQueryResponse {
    status: 'success' | 'error';
    data: GreptimeDBResponseData;
    error?: string;
}
export interface GreptimeDBClient {
    query: (params: GreptimeDBQueryRequestParameters) => Promise<GreptimeDBQueryResponse>;
}
export declare function greptimedbQuery(params: GreptimeDBQueryRequestParameters, queryOptions: GreptimeDBQueryOptions): Promise<GreptimeDBDatasourceResponse>;
//# sourceMappingURL=greptimedb-client.d.ts.map