export interface GreptimeDBColumnSchema {
    name: string;
    data_type?: string;
    semantic_type?: string;
}
export interface GreptimeDBRecords {
    schema?: {
        column_schemas?: GreptimeDBColumnSchema[];
    };
    rows?: unknown[][];
    total_rows?: number;
}
export interface GreptimeDBOutputRecord {
    records?: GreptimeDBRecords;
    affectedrows?: number;
}
export interface GreptimeDBResponseData {
    output?: GreptimeDBOutputRecord[];
    execution_time_ms?: number;
}
//# sourceMappingURL=greptimedb-data-types.d.ts.map