import { VariableStateMap } from '@perses-dev/plugin-system';
import { AbsoluteTimeRange } from '@perses-dev/spec';
import { GreptimeDBColumnSchema, GreptimeDBRecords, GreptimeDBResponseData } from '../model/greptimedb-data-types';
export type { GreptimeDBColumnSchema, GreptimeDBRecords, GreptimeDBResponseData };
/**
 * Supplement a variableState map with Perses builtin time-range variables
 * (__from, __to, __range, __range_s, __range_ms).
 *
 * Background: the LogQuery runtime passes context.variableState via
 * useVariableValues() which does NOT include builtin variables, unlike
 * TimeSeriesQuery which uses useAllVariableValues(). This helper bridges
 * that gap so both query types can rely on replaceVariables() uniformly.
 */
export declare function replaceQueryVariables(query: string, variableState: VariableStateMap, timeRange: AbsoluteTimeRange): string;
export declare function toTimestampMs(value: unknown, dataType: string | undefined): number | null;
export declare function normalizeRecords(payload: GreptimeDBResponseData): GreptimeDBRecords | undefined;
export declare function findTimeColumnIndex(columnSchemas: GreptimeDBColumnSchema[]): number;
//# sourceMappingURL=greptimedb-query-data-model.d.ts.map