import { OptionsEditorProps } from '@perses-dev/plugin-system';
import { ReactElement } from 'react';
import { GreptimeDBTimeSeriesQuerySpec } from './greptimedb-query-types';
type GreptimeDBTimeSeriesQueryEditorProps = OptionsEditorProps<GreptimeDBTimeSeriesQuerySpec>;
export declare function GreptimeDBTimeSeriesQueryEditor(props: GreptimeDBTimeSeriesQueryEditorProps): ReactElement;
export {};
//# sourceMappingURL=GreptimeDBQueryEditor.d.ts.map