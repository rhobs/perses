import { TimeSeriesQueryPlugin } from '@perses-dev/plugin-system';
import { GreptimeDBTimeSeriesQuerySpec } from './greptimedb-query-types';
export declare const getTimeSeriesData: TimeSeriesQueryPlugin<GreptimeDBTimeSeriesQuerySpec>['getTimeSeriesData'];
//# sourceMappingURL=get-greptimedb-data.d.ts.map