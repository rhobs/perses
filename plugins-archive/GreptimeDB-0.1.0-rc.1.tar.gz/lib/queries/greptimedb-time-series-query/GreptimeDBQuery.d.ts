import { TimeSeriesQueryPlugin } from '@perses-dev/plugin-system';
import { GreptimeDBTimeSeriesQuerySpec } from './greptimedb-query-types';
export declare const GreptimeDBTimeSeriesQuery: TimeSeriesQueryPlugin<GreptimeDBTimeSeriesQuerySpec>;
//# sourceMappingURL=GreptimeDBQuery.d.ts.map