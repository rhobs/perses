import { DatasourceSelector } from '@perses-dev/spec';
export interface GreptimeDBTimeSeriesQuerySpec {
    query: string;
    datasource?: DatasourceSelector;
    timeColumn?: string;
}
//# sourceMappingURL=greptimedb-query-types.d.ts.map