export declare const DATASOURCE_KIND = "GreptimeDBDatasource";
export declare const DEFAULT_DATASOURCE: {
    kind: string;
};
//# sourceMappingURL=constants.d.ts.map