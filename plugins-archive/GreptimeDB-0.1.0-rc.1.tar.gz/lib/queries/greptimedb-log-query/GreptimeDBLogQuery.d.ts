import { GreptimeDBLogQuerySpec } from './greptimedb-log-query-types';
import { LogQueryPlugin } from './log-query-plugin-interface';
export declare const GreptimeDBLogQuery: LogQueryPlugin<GreptimeDBLogQuerySpec>;
//# sourceMappingURL=GreptimeDBLogQuery.d.ts.map