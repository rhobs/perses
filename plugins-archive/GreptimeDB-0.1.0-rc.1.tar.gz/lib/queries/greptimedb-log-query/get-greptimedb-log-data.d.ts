import { GreptimeDBLogQuerySpec } from './greptimedb-log-query-types';
import { LogQueryPlugin } from './log-query-plugin-interface';
export declare const getGreptimeDBLogData: LogQueryPlugin<GreptimeDBLogQuerySpec>['getLogData'];
//# sourceMappingURL=get-greptimedb-log-data.d.ts.map