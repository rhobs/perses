import { DatasourceSelector } from '@perses-dev/spec';
export interface GreptimeDBLogQuerySpec {
    query: string;
    datasource?: DatasourceSelector;
}
//# sourceMappingURL=greptimedb-log-query-types.d.ts.map