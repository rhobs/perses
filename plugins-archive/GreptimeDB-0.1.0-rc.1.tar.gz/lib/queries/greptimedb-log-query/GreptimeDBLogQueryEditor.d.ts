import { OptionsEditorProps } from '@perses-dev/plugin-system';
import { ReactElement } from 'react';
import { GreptimeDBLogQuerySpec } from './greptimedb-log-query-types';
type GreptimeDBLogQueryEditorProps = OptionsEditorProps<GreptimeDBLogQuerySpec>;
export declare function GreptimeDBLogQueryEditor(props: GreptimeDBLogQueryEditorProps): ReactElement;
export {};
//# sourceMappingURL=GreptimeDBLogQueryEditor.d.ts.map