import { TraceQueryPlugin } from '@perses-dev/plugin-system';
import { GreptimeDBTraceQuerySpec } from './greptimedb-trace-query-types';
export declare const GreptimeDBTraceQuery: TraceQueryPlugin<GreptimeDBTraceQuerySpec>;
//# sourceMappingURL=GreptimeDBTraceQuery.d.ts.map