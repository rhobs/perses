export declare function isLikelyTraceDetailSQL(query: string): boolean;
//# sourceMappingURL=trace-query-sql.d.ts.map