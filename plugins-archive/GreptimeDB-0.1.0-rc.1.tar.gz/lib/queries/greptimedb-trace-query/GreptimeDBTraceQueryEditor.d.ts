import { OptionsEditorProps } from '@perses-dev/plugin-system';
import { ReactElement } from 'react';
import { GreptimeDBTraceQuerySpec } from './greptimedb-trace-query-types';
type GreptimeDBTraceQueryEditorProps = OptionsEditorProps<GreptimeDBTraceQuerySpec>;
export declare function GreptimeDBTraceQueryEditor(props: GreptimeDBTraceQueryEditorProps): ReactElement;
export {};
//# sourceMappingURL=GreptimeDBTraceQueryEditor.d.ts.map