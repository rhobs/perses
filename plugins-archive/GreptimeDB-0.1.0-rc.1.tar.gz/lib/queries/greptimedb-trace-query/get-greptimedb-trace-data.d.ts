import { TraceQueryPlugin } from '@perses-dev/plugin-system';
import { GreptimeDBTraceQuerySpec } from './greptimedb-trace-query-types';
export declare const getGreptimeDBTraceData: TraceQueryPlugin<GreptimeDBTraceQuerySpec>['getTraceData'];
/**
 * SQL column values only (timestamp, timestamp_end, duration_nano, …).
 * Requires data_type from getColumnDataType. GreptimeDB /v1/sql returns numeric cells (and numeric strings).
 * - Timestamp* (TIMESTAMP(9) on opentelemetry_traces) → scale to nanoseconds.
 * - Int64/UInt64 (duration_nano) → already nanoseconds, no scaling.
 */
export declare function toNanoString(value: unknown, dataType: string): string | undefined;
//# sourceMappingURL=get-greptimedb-trace-data.d.ts.map