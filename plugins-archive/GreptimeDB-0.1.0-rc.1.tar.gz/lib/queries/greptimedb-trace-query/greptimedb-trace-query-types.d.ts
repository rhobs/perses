import { DatasourceSelector } from '@perses-dev/spec';
export interface GreptimeDBTraceQuerySpec {
    query: string;
    datasource?: DatasourceSelector;
}
//# sourceMappingURL=greptimedb-trace-query-types.d.ts.map