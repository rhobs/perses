import { ReactElement } from 'react';
import { GreptimeDBDatasourceSpec } from './greptimedb-datasource-types';
export interface GreptimeDBDatasourceEditorProps {
    value: GreptimeDBDatasourceSpec;
    onChange: (next: GreptimeDBDatasourceSpec) => void;
    isReadonly?: boolean;
}
export declare function GreptimeDBDatasourceEditor(props: GreptimeDBDatasourceEditorProps): ReactElement;
//# sourceMappingURL=GreptimeDBDatasourceEditor.d.ts.map