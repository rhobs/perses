import { DatasourceClient } from '@perses-dev/plugin-system';
import { RequestHeaders } from '@perses-dev/client';
import { HTTPProxy } from '@perses-dev/spec';
import { GreptimeDBResponseData } from '../../model/greptimedb-data-types';
export interface GreptimeDBDatasourceSpec {
    directUrl?: string;
    headers?: RequestHeaders;
    proxy?: HTTPProxy;
}
export interface GreptimeDBQueryRequestParameters {
    query: string;
    start?: string;
    end?: string;
}
interface GreptimeDBDatasourceClientOptions {
    datasourceUrl: string;
    headers?: RequestHeaders;
}
export interface GreptimeDBDatasourceResponse {
    status: 'success' | 'error';
    data: GreptimeDBResponseData;
    error?: string;
}
export interface GreptimeDBDatasourceClient extends DatasourceClient {
    options: GreptimeDBDatasourceClientOptions;
    query(params: GreptimeDBQueryRequestParameters, headers?: RequestHeaders): Promise<GreptimeDBDatasourceResponse>;
}
export {};
//# sourceMappingURL=greptimedb-datasource-types.d.ts.map