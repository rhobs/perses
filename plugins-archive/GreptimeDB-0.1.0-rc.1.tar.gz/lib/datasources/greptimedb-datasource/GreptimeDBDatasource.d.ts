import { DatasourcePlugin } from '@perses-dev/plugin-system';
import { GreptimeDBDatasourceClient, GreptimeDBDatasourceSpec } from './greptimedb-datasource-types';
export declare const GreptimeDBDatasource: DatasourcePlugin<GreptimeDBDatasourceSpec, GreptimeDBDatasourceClient>;
//# sourceMappingURL=GreptimeDBDatasource.d.ts.map