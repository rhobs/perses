import { ReactElement } from 'react';
export interface BaseColumnDefinition {
    name: string;
    header?: string;
    enableSorting?: boolean;
    sort?: 'asc' | 'desc';
    sortMode?: string;
}
export type ColumnUpdater<C> = (index: number, updater: (draft: C) => void) => void;
export interface ColumnsEditorProps<C extends BaseColumnDefinition> {
    columns: C[];
    description: string;
    sortModeLabels: Record<string, string>;
    defaultSortMode: string;
    getDisplayName: (column: C) => string;
    getHeaderPlaceholder: (column: C) => string;
    onAdd: () => void;
    onRemove: (index: number) => void;
    onUpdate: ColumnUpdater<C>;
    onMoveUp: (index: number) => void;
    onMoveDown: (index: number) => void;
    renderNameField: (column: C, index: number, onUpdate: ColumnUpdater<C>) => ReactElement;
}
export declare function ColumnsEditor<C extends BaseColumnDefinition>(props: ColumnsEditorProps<C>): ReactElement;
//# sourceMappingURL=ColumnsEditor.d.ts.map