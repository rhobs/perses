import { SilenceMatcher } from '@perses-dev/spec';
import { ReactElement } from 'react';
export interface MatchersListProps {
    matchers: SilenceMatcher[];
}
/**
 * Renders a list of matchers as MUI Chips.
 */
export declare function MatchersList({ matchers }: MatchersListProps): ReactElement;
//# sourceMappingURL=MatchersList.d.ts.map