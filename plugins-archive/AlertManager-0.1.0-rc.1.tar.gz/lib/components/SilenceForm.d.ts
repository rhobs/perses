import { ReactElement } from 'react';
import { PostableSilence } from '../model/api-types';
export interface SilenceFormProps {
    open: boolean;
    onClose: () => void;
    onSubmit: (silence: PostableSilence) => void;
    initialSilence?: Partial<PostableSilence>;
}
/**
 * Form dialog for creating or editing silences.
 */
export declare function SilenceForm({ open, onClose, onSubmit, initialSilence }: SilenceFormProps): ReactElement;
//# sourceMappingURL=SilenceForm.d.ts.map