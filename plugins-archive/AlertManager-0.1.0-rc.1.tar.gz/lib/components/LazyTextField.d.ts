import { ReactElement } from 'react';
export interface LazyTextFieldProps {
    label: string;
    value?: string;
    onCommit: (nextValue: string) => void;
    placeholder?: string;
    helperText?: string;
    multiline?: boolean;
    minRows?: number;
}
export declare function LazyTextField(props: LazyTextFieldProps): ReactElement;
//# sourceMappingURL=LazyTextField.d.ts.map