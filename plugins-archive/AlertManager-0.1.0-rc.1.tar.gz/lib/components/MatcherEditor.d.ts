import { ReactElement } from 'react';
export interface MatcherValue {
    name: string;
    value: string;
    isEqual: boolean;
    isRegex: boolean;
}
export interface MatcherEditorProps {
    matcher: MatcherValue;
    onChange: (matcher: MatcherValue) => void;
    onRemove: () => void;
}
/**
 * A form for editing a single matcher with fields for name, value, and match type.
 */
export declare function MatcherEditor({ matcher, onChange, onRemove }: MatcherEditorProps): ReactElement;
//# sourceMappingURL=MatcherEditor.d.ts.map