import { ReactElement } from 'react';
export interface StatusBadgeProps {
    status: string;
    variant?: 'alert' | 'silence';
}
/**
 * Renders a colored badge/chip based on alert or silence status.
 */
export declare function StatusBadge({ status, variant }: StatusBadgeProps): ReactElement;
//# sourceMappingURL=StatusBadge.d.ts.map