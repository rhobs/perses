import { ReactElement } from 'react';
import { AlertManagerDatasourceSpec } from './types';
export interface AlertManagerDatasourceEditorProps {
    value: AlertManagerDatasourceSpec;
    onChange: (next: AlertManagerDatasourceSpec) => void;
    isReadonly?: boolean;
}
export declare function AlertManagerDatasourceEditor(props: AlertManagerDatasourceEditorProps): ReactElement;
//# sourceMappingURL=AlertManagerDatasourceEditor.d.ts.map