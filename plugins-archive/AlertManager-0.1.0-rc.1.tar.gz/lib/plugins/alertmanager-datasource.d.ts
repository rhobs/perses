import { DatasourcePlugin } from '@perses-dev/plugin-system';
import { AlertManagerClient } from '../model';
import { AlertManagerDatasourceSpec } from './types';
export declare const AlertManagerDatasource: DatasourcePlugin<AlertManagerDatasourceSpec, AlertManagerClient>;
//# sourceMappingURL=alertmanager-datasource.d.ts.map