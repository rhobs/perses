import { AlertsQueryPlugin } from '@perses-dev/plugin-system';
import { AlertManagerAlertsQuerySpec } from '../types';
export declare const AlertManagerAlertsQuery: AlertsQueryPlugin<AlertManagerAlertsQuerySpec>;
//# sourceMappingURL=AlertManagerAlertsQuery.d.ts.map