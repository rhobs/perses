import { AlertsQueryContext } from '@perses-dev/plugin-system';
import { AlertsData } from '@perses-dev/spec';
import { AlertManagerAlertsQuerySpec } from '../types';
/**
 * Get alerts data from Alert Manager, transforming the API response into the plugin-system AlertsData format.
 */
export declare function getAlertsData(spec: AlertManagerAlertsQuerySpec, context: AlertsQueryContext): Promise<AlertsData>;
//# sourceMappingURL=get-alerts-data.d.ts.map