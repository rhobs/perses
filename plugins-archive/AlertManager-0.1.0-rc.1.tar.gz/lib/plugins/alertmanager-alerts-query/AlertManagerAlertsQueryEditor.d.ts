import { ReactElement } from 'react';
import { AlertManagerAlertsQuerySpec } from '../types';
interface AlertManagerAlertsQueryEditorProps {
    value: AlertManagerAlertsQuerySpec;
    onChange: (next: AlertManagerAlertsQuerySpec) => void;
}
export declare function AlertManagerAlertsQueryEditor(props: AlertManagerAlertsQueryEditorProps): ReactElement;
export {};
//# sourceMappingURL=AlertManagerAlertsQueryEditor.d.ts.map