import { ReactElement } from 'react';
import { AlertManagerSilencesQuerySpec } from '../types';
interface AlertManagerSilencesQueryEditorProps {
    value: AlertManagerSilencesQuerySpec;
    onChange: (next: AlertManagerSilencesQuerySpec) => void;
}
export declare function AlertManagerSilencesQueryEditor(props: AlertManagerSilencesQueryEditorProps): ReactElement;
export {};
//# sourceMappingURL=AlertManagerSilencesQueryEditor.d.ts.map