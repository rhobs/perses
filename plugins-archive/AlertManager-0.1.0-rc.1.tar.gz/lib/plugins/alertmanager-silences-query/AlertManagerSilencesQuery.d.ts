import { SilencesQueryPlugin } from '@perses-dev/plugin-system';
import { AlertManagerSilencesQuerySpec } from '../types';
export declare const AlertManagerSilencesQuery: SilencesQueryPlugin<AlertManagerSilencesQuerySpec>;
//# sourceMappingURL=AlertManagerSilencesQuery.d.ts.map