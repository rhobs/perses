import { SilencesQueryContext } from '@perses-dev/plugin-system';
import { SilencesData } from '@perses-dev/spec';
import { AlertManagerSilencesQuerySpec } from '../types';
/**
 * Get silences data from Alert Manager, transforming the API response into the plugin-system SilencesData format.
 */
export declare function getSilencesData(spec: AlertManagerSilencesQuerySpec, context: SilencesQueryContext): Promise<SilencesData>;
//# sourceMappingURL=get-silences-data.d.ts.map