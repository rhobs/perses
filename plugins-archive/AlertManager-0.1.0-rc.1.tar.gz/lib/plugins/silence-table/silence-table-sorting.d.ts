import { Silence } from '@perses-dev/spec';
import { SilenceColumnSortMode, SilenceFieldName, SortDirection } from './silence-table-model';
export interface SilenceSortState {
    fieldName: SilenceFieldName;
    direction: SortDirection;
    mode: SilenceColumnSortMode;
}
export declare function compareSilencesByColumn(a: Silence, b: Silence, sort: SilenceSortState): number;
//# sourceMappingURL=silence-table-sorting.d.ts.map