import { PanelPlugin } from '@perses-dev/plugin-system';
import { SilenceTableOptions } from './silence-table-model';
/**
 * Panel plugin for displaying Alert Manager silences in a table.
 */
export declare const SilenceTable: PanelPlugin<SilenceTableOptions>;
//# sourceMappingURL=SilenceTable.d.ts.map