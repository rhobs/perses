import { PanelProps } from '@perses-dev/plugin-system';
import { SilencesData } from '@perses-dev/spec';
import { ReactElement } from 'react';
import { SilenceTableOptions } from './silence-table-model';
export type SilenceTablePanelProps = PanelProps<SilenceTableOptions, SilencesData>;
/**
 * Silence table panel component.
 * Displays silences with matchers, status, creator, duration, and actions.
 */
export declare function SilenceTablePanel({ spec, queryResults, contentDimensions }: SilenceTablePanelProps): ReactElement;
//# sourceMappingURL=SilenceTablePanel.d.ts.map