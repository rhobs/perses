import { Silence } from '@perses-dev/spec';
export type SilenceAction = 'expire';
export declare const ALL_SILENCE_ACTIONS: SilenceAction[];
export type SortDirection = 'asc' | 'desc';
export type SilenceColumnSortMode = 'alphabetical' | 'date' | 'status';
export type SilenceFieldName = 'status' | 'matchers' | 'createdBy' | 'startsAt' | 'endsAt' | 'duration' | 'comment' | 'updatedAt';
export interface SilenceColumnDefinition {
    name: SilenceFieldName;
    header?: string;
    enableSorting?: boolean;
    sort?: SortDirection;
    sortMode?: SilenceColumnSortMode;
}
export declare const DEFAULT_COLUMN_HEADERS: Record<SilenceFieldName, string>;
export declare const DEFAULT_SILENCE_COLUMNS: SilenceColumnDefinition[];
export declare function inferSortMode(field: SilenceFieldName): SilenceColumnSortMode;
export declare function getSilenceFieldValue(silence: Silence, field: SilenceFieldName): string;
/**
 * Options for the SilenceTable panel plugin.
 */
export interface SilenceTableOptions {
    columns?: SilenceColumnDefinition[];
    allowedActions?: SilenceAction[];
}
/**
 * Calculate a human-readable duration string from a silence's start and end times.
 */
export declare function getSilenceDuration(silence: Silence): string;
//# sourceMappingURL=silence-table-model.d.ts.map