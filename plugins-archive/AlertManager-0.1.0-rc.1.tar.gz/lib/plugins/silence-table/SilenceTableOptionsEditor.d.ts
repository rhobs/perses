import { OptionsEditorProps } from '@perses-dev/plugin-system';
import { ReactElement } from 'react';
import { SilenceTableOptions } from './silence-table-model';
export declare function SilenceTableOptionsEditor(props: OptionsEditorProps<SilenceTableOptions>): ReactElement;
//# sourceMappingURL=SilenceTableOptionsEditor.d.ts.map