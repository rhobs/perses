import { OptionsEditorProps } from '@perses-dev/plugin-system';
import { ReactElement } from 'react';
import { SilenceTableOptions } from './silence-table-model';
export declare function SilenceTableColumnsEditor(props: OptionsEditorProps<SilenceTableOptions>): ReactElement;
//# sourceMappingURL=SilenceTableColumnsEditor.d.ts.map