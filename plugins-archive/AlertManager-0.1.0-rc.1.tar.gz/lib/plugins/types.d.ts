import { HTTPProxy } from '@perses-dev/spec';
import { DatasourceSelectValue } from '@perses-dev/plugin-system';
import { AlertManagerDatasourceSelector } from '../model/alertmanager-selectors';
/**
 * Datasource spec for the Alert Manager datasource plugin.
 */
export interface AlertManagerDatasourceSpec {
    directUrl?: string;
    proxy?: HTTPProxy;
}
/**
 * Query spec for the Alert Manager alerts query plugin.
 */
export interface AlertManagerAlertsQuerySpec {
    datasource?: DatasourceSelectValue<AlertManagerDatasourceSelector>;
    filters?: string[];
    active?: boolean;
    silenced?: boolean;
    inhibited?: boolean;
    unprocessed?: boolean;
    receiver?: string;
}
/**
 * Query spec for the Alert Manager silences query plugin.
 */
export interface AlertManagerSilencesQuerySpec {
    datasource?: DatasourceSelectValue<AlertManagerDatasourceSelector>;
    filters?: string[];
}
//# sourceMappingURL=types.d.ts.map