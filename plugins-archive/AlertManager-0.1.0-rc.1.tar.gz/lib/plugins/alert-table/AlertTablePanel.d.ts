import { PanelProps } from '@perses-dev/plugin-system';
import { AlertsData } from '@perses-dev/spec';
import { ReactElement } from 'react';
import { AlertTableOptions } from './alert-table-model';
export type AlertTablePanelProps = PanelProps<AlertTableOptions, AlertsData>;
/**
 * Alert hierarchical table panel component.
 * Displays alerts grouped by configurable labels with deduplication.
 */
export declare function AlertTablePanel({ spec, queryResults, contentDimensions }: AlertTablePanelProps): ReactElement;
//# sourceMappingURL=AlertTablePanel.d.ts.map