import { OptionsEditorProps } from '@perses-dev/plugin-system';
import { ReactElement } from 'react';
import { AlertTableOptions } from './alert-table-model';
export declare function AlertTableDeduplicationEditor(props: OptionsEditorProps<AlertTableOptions>): ReactElement;
//# sourceMappingURL=AlertTableDeduplicationEditor.d.ts.map