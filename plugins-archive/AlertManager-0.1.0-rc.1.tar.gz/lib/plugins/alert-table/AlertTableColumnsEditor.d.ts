import { OptionsEditorProps } from '@perses-dev/plugin-system';
import { ReactElement } from 'react';
import { AlertTableOptions } from './alert-table-model';
export declare function AlertTableColumnsEditor(props: OptionsEditorProps<AlertTableOptions>): ReactElement;
//# sourceMappingURL=AlertTableColumnsEditor.d.ts.map