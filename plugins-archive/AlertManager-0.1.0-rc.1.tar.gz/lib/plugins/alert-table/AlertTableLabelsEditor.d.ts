import { OptionsEditorProps } from '@perses-dev/plugin-system';
import { ReactElement } from 'react';
import { AlertTableOptions } from './alert-table-model';
export declare function AlertTableLabelsEditor(props: OptionsEditorProps<AlertTableOptions>): ReactElement;
//# sourceMappingURL=AlertTableLabelsEditor.d.ts.map