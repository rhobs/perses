import { PanelPlugin } from '@perses-dev/plugin-system';
import { AlertTablePanelProps } from './AlertTablePanel';
import { AlertTableOptions } from './alert-table-model';
/**
 * Panel plugin for displaying Alert Manager alerts in a hierarchical table.
 */
export declare const AlertTable: PanelPlugin<AlertTableOptions, AlertTablePanelProps>;
//# sourceMappingURL=AlertTable.d.ts.map