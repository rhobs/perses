import { Alert } from '@perses-dev/spec';
/**
 * Configuration for how alerts should be deduplicated across datasources.
 */
export interface AlertDeduplicationConfig {
    mode: 'none' | 'fingerprint' | 'labels';
    labels?: string[];
}
export interface DeduplicationResult {
    alerts: Alert[];
    duplicateCounts: Map<Alert, number>;
}
export type AlertAction = 'silence' | 'runbook';
export declare const ALL_ALERT_ACTIONS: AlertAction[];
export interface LabelColorOverride {
    value: string;
    isRegex: boolean;
    color: string;
}
export interface LabelColorMapping {
    labelKey: string;
    mode: 'auto' | 'severity' | 'manual';
    overrides?: LabelColorOverride[];
}
export type SortDirection = 'asc' | 'desc';
export type ColumnSortMode = 'alphabetical' | 'numeric' | 'severity' | 'status';
export interface ColumnDefinition {
    name: string;
    header?: string;
    enableSorting?: boolean;
    sort?: SortDirection;
    sortMode?: ColumnSortMode;
}
/**
 * Options for the AlertTable panel plugin.
 */
export interface AlertTableOptions {
    defaultGroupBy?: string[];
    columns?: ColumnDefinition[];
    deduplication?: AlertDeduplicationConfig;
    allowedActions?: AlertAction[];
    runbookAnnotationKey?: string;
    labelColorMappings?: LabelColorMapping[];
}
/**
 * Summary of alert counts by state within a group.
 */
export interface GroupSummary {
    total: number;
    firing: number;
    suppressed: number;
    pending: number;
    labelCounts?: Record<string, Record<string, number>>;
}
/**
 * Deduplicate alerts based on the configured deduplication mode.
 * - 'fingerprint' (default): Uses the alert's fingerprint field.
 * - 'labels': Uses a combination of specified label values.
 */
export declare function deduplicateAlerts(alerts: Alert[], config: AlertDeduplicationConfig): DeduplicationResult;
/**
 * Extract all unique label keys from a list of alerts.
 */
export declare function extractLabelKeys(alerts: Alert[]): string[];
/**
 * Build a group key string from an alert's labels and the specified group-by labels.
 */
export declare function getGroupKey(alert: Alert, groupBy: string[]): string;
/**
 * Compute a summary of alert counts by state for a group of alerts.
 */
export declare function getGroupSummary(alerts: Alert[], labelKeys?: string[]): GroupSummary;
//# sourceMappingURL=alert-table-model.d.ts.map