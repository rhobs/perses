import { Alert } from '@perses-dev/spec';
import { ColumnSortMode, SortDirection } from './alert-table-model';
export declare const SORT_COL_STATUS = "__status__";
export declare const SORT_COL_ALERTNAME = "__alertname__";
export interface SortState {
    columnName: string;
    direction: SortDirection;
    mode: ColumnSortMode;
}
export declare function getEffectiveStatus(alert: Alert): string;
export declare function compareAlertsByColumn(a: Alert, b: Alert, sort: SortState): number;
export declare function compareGroupsByColumn(aCounts: Record<string, number> | undefined, bCounts: Record<string, number> | undefined, sort: SortState): number;
//# sourceMappingURL=alert-table-sorting.d.ts.map