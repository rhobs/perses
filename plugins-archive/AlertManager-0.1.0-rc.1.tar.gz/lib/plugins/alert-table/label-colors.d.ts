import { LabelColorMapping } from './alert-table-model';
export declare const SEVERITY_ORDER: string[];
export declare function getSeverityWeight(value: string): number;
export declare function hashStringToColor(value: string): string;
export declare function getLabelColor(value: string, mapping: LabelColorMapping): string;
//# sourceMappingURL=label-colors.d.ts.map