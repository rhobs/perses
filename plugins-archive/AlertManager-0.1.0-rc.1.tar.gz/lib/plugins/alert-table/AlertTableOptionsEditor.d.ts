import { OptionsEditorProps } from '@perses-dev/plugin-system';
import { ReactElement } from 'react';
import { AlertTableOptions } from './alert-table-model';
export declare function AlertTableOptionsEditor(props: OptionsEditorProps<AlertTableOptions>): ReactElement;
//# sourceMappingURL=AlertTableOptionsEditor.d.ts.map