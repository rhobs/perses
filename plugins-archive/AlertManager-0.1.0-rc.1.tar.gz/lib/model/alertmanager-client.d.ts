import { RequestHeaders } from '@perses-dev/client';
import { DatasourceClient } from '@perses-dev/plugin-system';
import { AlertManagerStatus, AlertsQueryParams, GettableAlert, GettableSilence, PostableSilence, SilencesQueryParams } from './api-types';
export interface AlertManagerQueryOptions {
    datasourceUrl: string;
    headers?: RequestHeaders;
}
export interface AlertManagerClient extends DatasourceClient {
    options: AlertManagerQueryOptions;
    getAlerts(params?: AlertsQueryParams, headers?: RequestHeaders): Promise<GettableAlert[]>;
    getSilences(params?: SilencesQueryParams, headers?: RequestHeaders): Promise<GettableSilence[]>;
    getSilence(id: string, headers?: RequestHeaders): Promise<GettableSilence>;
    createSilence(silence: PostableSilence, headers?: RequestHeaders): Promise<{
        silenceID: string;
    }>;
    deleteSilence(id: string, headers?: RequestHeaders): Promise<void>;
    getStatus(headers?: RequestHeaders): Promise<AlertManagerStatus>;
}
export declare function getAlerts(params?: AlertsQueryParams, queryOptions?: AlertManagerQueryOptions): Promise<GettableAlert[]>;
export declare function getSilences(params?: SilencesQueryParams, queryOptions?: AlertManagerQueryOptions): Promise<GettableSilence[]>;
export declare function getSilence(id: string, queryOptions: AlertManagerQueryOptions): Promise<GettableSilence>;
export declare function createSilence(silence: PostableSilence, queryOptions: AlertManagerQueryOptions): Promise<{
    silenceID: string;
}>;
export declare function deleteSilence(id: string, queryOptions: AlertManagerQueryOptions): Promise<void>;
export declare function getStatus(queryOptions: AlertManagerQueryOptions): Promise<AlertManagerStatus>;
//# sourceMappingURL=alertmanager-client.d.ts.map