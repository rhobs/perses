import { DatasourceSelector, QueryDefinition } from '@perses-dev/spec';
import { DatasourceSelectValue } from '@perses-dev/plugin-system';
export declare const ALERTMANAGER_DATASOURCE_KIND: "AlertManagerDatasource";
export interface AlertManagerDatasourceSelector extends DatasourceSelector {
    kind: typeof ALERTMANAGER_DATASOURCE_KIND;
}
export declare const DEFAULT_ALERTMANAGER: AlertManagerDatasourceSelector;
export declare function isDefaultAlertManagerSelector(datasourceSelectValue: DatasourceSelectValue): boolean;
export declare function isAlertManagerDatasourceSelector(datasourceSelectValue: DatasourceSelectValue): datasourceSelectValue is AlertManagerDatasourceSelector;
export declare function extractDatasourceSelector(queryResults: Array<{
    definition: QueryDefinition;
}>): DatasourceSelector;
//# sourceMappingURL=alertmanager-selectors.d.ts.map