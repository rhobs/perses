import { PluginModuleResource } from '@perses-dev/plugin-system';
export declare function getPluginModule(): PluginModuleResource;
//# sourceMappingURL=getPluginModule.d.ts.map