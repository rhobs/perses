import { ReactElement } from 'react';
export declare function AlertManagerSilencesExplorer(): ReactElement;
//# sourceMappingURL=AlertManagerSilencesExplorer.d.ts.map