import type { OptionsEditorProps } from '@perses-dev/plugin-system';
import type { ReactElement } from 'react';
import type { SilenceTableOptions } from './silence-table-model';
export declare function SilenceTableOptionsEditor(props: OptionsEditorProps<SilenceTableOptions>): ReactElement;
//# sourceMappingURL=SilenceTableOptionsEditor.d.ts.map