import type { OptionsEditorProps } from '@perses-dev/plugin-system';
import type { ReactElement } from 'react';
import type { SilenceTableOptions } from './silence-table-model';
export declare function SilenceTableColumnsEditor(props: OptionsEditorProps<SilenceTableOptions>): ReactElement;
//# sourceMappingURL=SilenceTableColumnsEditor.d.ts.map