import type { ReactElement } from 'react';
import type { AlertManagerSilencesQuerySpec } from '../types';
interface AlertManagerSilencesQueryEditorProps {
    value: AlertManagerSilencesQuerySpec;
    onChange: (next: AlertManagerSilencesQuerySpec) => void;
}
export declare function AlertManagerSilencesQueryEditor(props: AlertManagerSilencesQueryEditorProps): ReactElement;
export {};
//# sourceMappingURL=AlertManagerSilencesQueryEditor.d.ts.map