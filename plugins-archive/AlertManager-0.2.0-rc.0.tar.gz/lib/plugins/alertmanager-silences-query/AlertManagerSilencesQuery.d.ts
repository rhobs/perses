import type { SilencesQueryPlugin } from '@perses-dev/plugin-system';
import type { AlertManagerSilencesQuerySpec } from '../types';
export declare const AlertManagerSilencesQuery: SilencesQueryPlugin<AlertManagerSilencesQuerySpec>;
//# sourceMappingURL=AlertManagerSilencesQuery.d.ts.map