import type { DatasourcePlugin } from '@perses-dev/plugin-system';
import type { AlertManagerClient } from '../model';
import type { AlertManagerDatasourceSpec } from './types';
export declare const AlertManagerDatasource: DatasourcePlugin<AlertManagerDatasourceSpec, AlertManagerClient>;
//# sourceMappingURL=alertmanager-datasource.d.ts.map