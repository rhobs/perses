import type { DatasourceEditorProps } from '@perses-dev/plugin-system';
import type { ReactElement } from 'react';
import type { AlertManagerDatasourceSpec } from './types';
export type AlertManagerDatasourceEditorProps = DatasourceEditorProps<AlertManagerDatasourceSpec>;
export declare function AlertManagerDatasourceEditor(props: AlertManagerDatasourceEditorProps): ReactElement;
//# sourceMappingURL=AlertManagerDatasourceEditor.d.ts.map