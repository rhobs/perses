import type { OptionsEditorProps } from '@perses-dev/plugin-system';
import type { ReactElement } from 'react';
import type { AlertTableOptions } from './alert-table-model';
export declare function AlertTableLabelsEditor(props: OptionsEditorProps<AlertTableOptions>): ReactElement;
//# sourceMappingURL=AlertTableLabelsEditor.d.ts.map