import type { OptionsEditorProps } from '@perses-dev/plugin-system';
import type { ReactElement } from 'react';
import type { AlertTableOptions } from './alert-table-model';
export declare function AlertTableColumnsEditor(props: OptionsEditorProps<AlertTableOptions>): ReactElement;
//# sourceMappingURL=AlertTableColumnsEditor.d.ts.map