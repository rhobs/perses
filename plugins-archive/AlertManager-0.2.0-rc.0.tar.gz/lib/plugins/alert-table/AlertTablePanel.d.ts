import type { PanelProps } from '@perses-dev/plugin-system';
import type { AlertsData } from '@perses-dev/spec';
import type { ReactElement } from 'react';
import type { AlertTableOptions } from './alert-table-model';
export type AlertTablePanelProps = PanelProps<AlertTableOptions, AlertsData>;
/**
 * Alert hierarchical table panel component.
 * Displays alerts grouped by configurable labels with deduplication.
 */
export declare function AlertTablePanel({ spec, queryResults, contentDimensions }: AlertTablePanelProps): ReactElement;
//# sourceMappingURL=AlertTablePanel.d.ts.map