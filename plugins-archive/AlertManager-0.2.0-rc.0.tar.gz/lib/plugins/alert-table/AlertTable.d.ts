import type { PanelPlugin } from '@perses-dev/plugin-system';
import type { AlertTableOptions } from './alert-table-model';
import type { AlertTablePanelProps } from './AlertTablePanel';
/**
 * Panel plugin for displaying Alert Manager alerts in a hierarchical table.
 */
export declare const AlertTable: PanelPlugin<AlertTableOptions, AlertTablePanelProps>;
//# sourceMappingURL=AlertTable.d.ts.map