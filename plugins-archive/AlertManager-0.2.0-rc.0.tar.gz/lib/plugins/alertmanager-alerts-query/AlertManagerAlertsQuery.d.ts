import type { AlertsQueryPlugin } from '@perses-dev/plugin-system';
import type { AlertManagerAlertsQuerySpec } from '../types';
export declare const AlertManagerAlertsQuery: AlertsQueryPlugin<AlertManagerAlertsQuerySpec>;
//# sourceMappingURL=AlertManagerAlertsQuery.d.ts.map