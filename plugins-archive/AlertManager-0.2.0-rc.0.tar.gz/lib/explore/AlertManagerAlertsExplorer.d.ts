import type { ReactElement } from 'react';
export declare function AlertManagerAlertsExplorer(): ReactElement;
//# sourceMappingURL=AlertManagerAlertsExplorer.d.ts.map