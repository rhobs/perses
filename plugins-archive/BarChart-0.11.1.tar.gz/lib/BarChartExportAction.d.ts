import React from 'react';
import { BarChartPanelProps } from './BarChartPanel';
export declare const BarChartExportAction: React.FC<BarChartPanelProps>;
//# sourceMappingURL=BarChartExportAction.d.ts.map