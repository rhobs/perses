import { ReactElement } from 'react';
import { TimeSeriesChartOptionsEditorProps } from './time-series-chart-model';
export declare function TimeSeriesChartGeneralSettings(props: TimeSeriesChartOptionsEditorProps): ReactElement;
//# sourceMappingURL=GeneralSettingsEditor.d.ts.map