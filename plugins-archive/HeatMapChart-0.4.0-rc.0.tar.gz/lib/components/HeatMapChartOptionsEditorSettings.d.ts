import { ReactElement } from 'react';
import { HeatMapChartOptionsEditorProps } from '../heat-map-chart-model';
export declare function HeatMapChartOptionsEditorSettings(props: HeatMapChartOptionsEditorProps): ReactElement;
//# sourceMappingURL=HeatMapChartOptionsEditorSettings.d.ts.map