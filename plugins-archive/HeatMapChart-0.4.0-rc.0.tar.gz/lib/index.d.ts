export { getPluginModule } from './getPluginModule';
export { HeatMapChartPanel } from './components';
export * from './heat-map-chart-model';
export * from './HeatMapChart';
//# sourceMappingURL=index.d.ts.map