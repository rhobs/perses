import { ReactElement } from 'react';
import { TraceQueryEditorProps } from './query-editor-model';
export declare function TempoTraceQueryEditor(props: TraceQueryEditorProps): ReactElement;
//# sourceMappingURL=TempoTraceQueryEditor.d.ts.map