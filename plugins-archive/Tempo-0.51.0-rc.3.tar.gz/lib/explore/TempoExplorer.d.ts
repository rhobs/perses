import { ReactElement } from 'react';
export declare function TempoExplorer(): ReactElement;
//# sourceMappingURL=TempoExplorer.d.ts.map