import { PanelProps } from '@perses-dev/plugin-system';
import { ReactElement } from 'react';
import { TimeSeriesData } from '@perses-dev/spec';
import { HistogramChartOptions } from '../histogram-chart-model';
export type HistogramChartPanelProps = PanelProps<HistogramChartOptions, TimeSeriesData>;
export declare function HistogramChartPanel(props: HistogramChartPanelProps): ReactElement | null;
//# sourceMappingURL=HistogramChartPanel.d.ts.map