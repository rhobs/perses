import { PersesChartsTheme, ThresholdOptions } from '@perses-dev/components';
export declare function getColorFromThresholds(value: number, thresholds: ThresholdOptions | undefined, chartsTheme: PersesChartsTheme, defaultColor: string): string | null;
//# sourceMappingURL=thresholds.d.ts.map