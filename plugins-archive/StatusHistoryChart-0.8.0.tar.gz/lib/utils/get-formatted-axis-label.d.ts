export declare function getFormattedStatusHistoryAxisLabel(rangeMs: number, timezone: string): (value: number) => string;
//# sourceMappingURL=get-formatted-axis-label.d.ts.map