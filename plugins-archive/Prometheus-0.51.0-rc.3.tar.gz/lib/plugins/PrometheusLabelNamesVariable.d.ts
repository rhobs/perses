import { VariablePlugin } from '@perses-dev/plugin-system';
import { PrometheusLabelNamesVariableOptions } from './types';
export declare const PrometheusLabelNamesVariable: VariablePlugin<PrometheusLabelNamesVariableOptions>;
//# sourceMappingURL=PrometheusLabelNamesVariable.d.ts.map