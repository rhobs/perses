import ASTNode from './ast';
declare const serializeNode: (node: ASTNode, indent?: number, pretty?: boolean, initialIndent?: boolean) => string;
export default serializeNode;
//# sourceMappingURL=serialize.d.ts.map