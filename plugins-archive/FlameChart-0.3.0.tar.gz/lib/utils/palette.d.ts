/**
 * Return a consistent color for (name, error) tuple
 */
export declare function getConsistentColor(name: string, error: boolean): string;
//# sourceMappingURL=palette.d.ts.map