import type { PanelData } from '@perses-dev/plugin-system';
import type { HistogramValue, TimeSeriesData } from '@perses-dev/spec';
import type { ReactElement, ReactNode } from 'react';
import type { TimeSeriesTableOptions } from '../model';
export interface DataTableProps {
    queryResults: Array<PanelData<TimeSeriesData>>;
    spec: TimeSeriesTableOptions;
}
/**
 * Designed to display timeseries data in a prometheus like table format.
 * The first column will contain the metric name and label combination, and the second column will contain the values.
 * This is inspired by prometheus DataTable.
 * https://github.com/prometheus/prometheus/blob/2524a915915d7eb1b1207152d2e0ce5771193404/web/ui/react-app/src/pages/graph/DataTable.tsx
 * @param result timeseries query result
 * @constructor
 */
export declare const DataTable: ({ queryResults, spec }: DataTableProps) => ReactElement | null;
export declare const bucketRangeString: ([boundaryRule, leftBoundary, rightBoundary]: [number, string, string, string]) => string;
export declare const histogramTable: (h: HistogramValue) => ReactNode;
//# sourceMappingURL=DataTable.d.ts.map