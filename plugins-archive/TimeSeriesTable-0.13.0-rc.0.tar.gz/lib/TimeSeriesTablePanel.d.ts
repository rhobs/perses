import type { PanelProps } from '@perses-dev/plugin-system';
import type { TimeSeriesData } from '@perses-dev/spec';
import type { ReactElement } from 'react';
import type { TimeSeriesTableOptions } from './model';
export type TimeSeriesTableProps = PanelProps<TimeSeriesTableOptions, TimeSeriesData>;
export declare function TimeSeriesTablePanel(props: TimeSeriesTableProps): ReactElement;
//# sourceMappingURL=TimeSeriesTablePanel.d.ts.map