import type { PanelPlugin } from '@perses-dev/plugin-system';
import type { TimeSeriesTableOptions } from './model';
import type { TimeSeriesTableProps } from './TimeSeriesTablePanel';
/**
 * The core TimeSeriesTable panel plugin for Perses.
 */
export declare const TimeSeriesTable: PanelPlugin<TimeSeriesTableOptions, TimeSeriesTableProps>;
//# sourceMappingURL=TimeSeriesTable.d.ts.map