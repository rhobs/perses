import { FormatOptions, ThresholdOptions } from '@perses-dev/components';
import { CalculationType, OptionsEditorProps } from '@perses-dev/plugin-system';
import { Definition } from '@perses-dev/spec';
export declare const DEFAULT_FORMAT: FormatOptions;
export declare const DEFAULT_MAX_PERCENT = 100;
export declare const DEFAULT_MAX_PERCENT_DECIMAL = 1;
/**
 * The schema for a GaugeChart panel.
 */
export interface GaugeChartDefinition extends Definition<GaugeChartOptions> {
    kind: 'GaugeChart';
}
/**
 * The Options object type supported by the GaugeChart panel plugin.
 */
export interface GaugeChartOptions {
    calculation: CalculationType;
    format?: FormatOptions;
    thresholds?: ThresholdOptions;
    max?: number;
    legend?: {
        show?: boolean;
    };
}
export type GaugeChartOptionsEditorProps = OptionsEditorProps<GaugeChartOptions>;
/**
 * Creates the initial/empty options for a GaugeChart panel.
 */
export declare function createInitialGaugeChartOptions(): GaugeChartOptions;
//# sourceMappingURL=gauge-chart-model.d.ts.map