import type { TraceData } from '@perses-dev/spec';
import type { QueryResponse, SearchResponse } from '../model/api-types';
export declare const MOCK_TRACE_RESPONSE: QueryResponse;
export declare const MOCK_TRACE_RESPONSE_SMALL: QueryResponse;
export declare const MOCK_SEARCH_RESPONSE_VPARQUET3: SearchResponse;
export declare const MOCK_SEARCH_RESPONSE_VPARQUET4: SearchResponse;
export declare const MOCK_SEARCH_RESPONSE_MIXED_VPARQUET3_AND_4: SearchResponse;
export declare const MOCK_TRACE_DATA_SEARCHRESULT: TraceData;
//# sourceMappingURL=mock-data.d.ts.map