import type { AlertProps } from '@mui/material';
import type { ReactElement } from 'react';
export declare function ClosableAlert(props: AlertProps): ReactElement | null;
//# sourceMappingURL=ClosableAlert.d.ts.map