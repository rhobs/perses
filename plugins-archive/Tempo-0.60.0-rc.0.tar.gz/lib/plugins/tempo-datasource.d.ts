import type { DatasourcePlugin } from '@perses-dev/plugin-system';
import type { TempoClient } from '../model/tempo-client';
import type { TempoDatasourceSpec } from './tempo-datasource-types';
export declare const TempoDatasource: DatasourcePlugin<TempoDatasourceSpec, TempoClient>;
//# sourceMappingURL=tempo-datasource.d.ts.map