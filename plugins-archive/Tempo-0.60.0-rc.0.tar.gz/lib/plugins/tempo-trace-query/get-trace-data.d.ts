import type { TraceQueryPlugin } from '@perses-dev/plugin-system';
import type { AbsoluteTimeRange } from '@perses-dev/spec';
import type { TempoTraceQuerySpec } from '../../model';
export declare function getUnixTimeRange(timeRange: AbsoluteTimeRange): {
    start: number;
    end: number;
};
export declare const getTraceData: TraceQueryPlugin<TempoTraceQuerySpec>['getTraceData'];
//# sourceMappingURL=get-trace-data.d.ts.map