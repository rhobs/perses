import type { ReactElement } from 'react';
import type { TraceQueryEditorProps } from './query-editor-model';
export declare function TempoTraceQueryEditor(props: TraceQueryEditorProps): ReactElement;
interface LimitSelectProps {
    value: number;
    setValue: (x: number) => void;
}
export declare function LimitSelect(props: LimitSelectProps): ReactElement;
export {};
//# sourceMappingURL=TempoTraceQueryEditor.d.ts.map