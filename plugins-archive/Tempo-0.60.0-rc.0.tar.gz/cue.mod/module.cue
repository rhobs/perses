{
	module: "github.com/perses/plugins/tempo@v0"
	language: {
		version: "v0.17.1"
	}
	source: {
		kind: "git"
	}
}