import { ReactElement } from 'react';
import { GaugeChartOptionsEditorProps } from './gauge-chart-model';
export declare function GaugeChartOptionsEditorSettings(props: GaugeChartOptionsEditorProps): ReactElement;
//# sourceMappingURL=GaugeChartOptionsEditorSettings.d.ts.map