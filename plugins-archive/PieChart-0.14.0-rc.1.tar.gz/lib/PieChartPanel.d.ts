import { PanelProps } from '@perses-dev/plugin-system';
import { ReactElement } from 'react';
import { TimeSeriesData } from '@perses-dev/spec';
import { PieChartOptions } from './pie-chart-model';
export type PieChartPanelProps = PanelProps<PieChartOptions, TimeSeriesData>;
export declare function PieChartPanel(props: PieChartPanelProps): ReactElement | null;
//# sourceMappingURL=PieChartPanel.d.ts.map