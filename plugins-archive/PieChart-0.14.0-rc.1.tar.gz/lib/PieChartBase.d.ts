import { ReactElement } from 'react';
import { FormatOptions, ModeOption } from '@perses-dev/components';
export interface PieChartData {
    id?: string;
    name: string;
    value: number | null;
    itemStyle?: {
        color: string;
    };
}
export interface PieChartBaseProps {
    width: number;
    height: number;
    data: PieChartData[] | null;
    mode?: ModeOption;
    showLabels?: boolean;
    formatOptions?: FormatOptions;
}
export declare function PieChartBase(props: PieChartBaseProps): ReactElement;
//# sourceMappingURL=PieChartBase.d.ts.map