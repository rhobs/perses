import { FormatOptions, LegendItem, ModeOption, SortOption, TableColumnConfig } from '@perses-dev/components';
import { ComparisonValues, LegendValue } from '@perses-dev/plugin-system';
import { PieChartData } from './PieChartBase';
export declare function sortSeriesData<T extends PieChartData>(data: T[], sortOrder?: SortOption): T[];
type formatterProps = {
    name: string;
    value: number | unknown[] | object;
    percent: number;
};
export declare const getTooltipFormatter: (formatOptions?: FormatOptions) => ((props: formatterProps) => string);
export declare const getLabelFormatter: (mode?: ModeOption, formatOptions?: FormatOptions) => ((props: formatterProps) => string);
export interface PieChartLegendMapper {
    mapToLegendItems: (pieChartData: Array<Required<PieChartData>>, selectedValues?: Array<LegendValue | ComparisonValues>) => LegendItem[];
    mapToLegendColumns: (selectedValues?: Array<LegendValue | ComparisonValues>, formatOptions?: FormatOptions) => Array<TableColumnConfig<LegendItem>>;
}
export declare class PieChartListLegendMapper implements PieChartLegendMapper {
    mapToLegendItems(pieChartData: Array<Required<PieChartData>>): LegendItem[];
    mapToLegendColumns(): Array<TableColumnConfig<LegendItem>>;
}
export declare class PieChartTableLegendMapper implements PieChartLegendMapper {
    mapToLegendItems(pieChartData: Array<Required<PieChartData>>, selectedValues?: Array<LegendValue | ComparisonValues>): LegendItem[];
    mapToLegendColumns(selectedValues?: Array<LegendValue | ComparisonValues>, formatOptions?: FormatOptions): Array<TableColumnConfig<LegendItem>>;
}
export {};
//# sourceMappingURL=utils.d.ts.map