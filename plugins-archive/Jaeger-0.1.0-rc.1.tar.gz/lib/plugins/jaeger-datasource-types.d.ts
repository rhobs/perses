import { HTTPProxy } from '@perses-dev/spec';
export interface JaegerDatasourceSpec {
    directUrl?: string;
    proxy?: HTTPProxy;
}
//# sourceMappingURL=jaeger-datasource-types.d.ts.map