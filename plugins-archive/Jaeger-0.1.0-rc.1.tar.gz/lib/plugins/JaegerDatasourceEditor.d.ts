import { ReactElement } from 'react';
import { JaegerDatasourceSpec } from './jaeger-datasource-types';
export interface JaegerDatasourceEditorProps {
    value: JaegerDatasourceSpec;
    onChange: (next: JaegerDatasourceSpec) => void;
    isReadonly?: boolean;
}
export declare function JaegerDatasourceEditor(props: JaegerDatasourceEditorProps): ReactElement;
//# sourceMappingURL=JaegerDatasourceEditor.d.ts.map