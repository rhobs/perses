import { TraceQueryPlugin } from '@perses-dev/plugin-system';
import { JaegerTraceQuerySpec } from '../model';
export declare const JaegerTraceQuery: TraceQueryPlugin<JaegerTraceQuerySpec>;
//# sourceMappingURL=JaegerTraceQuery.d.ts.map