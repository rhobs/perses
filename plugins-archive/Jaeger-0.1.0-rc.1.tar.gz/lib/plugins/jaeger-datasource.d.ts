import { DatasourcePlugin } from '@perses-dev/plugin-system';
import { JaegerClient } from '../model';
import { JaegerDatasourceSpec } from './jaeger-datasource-types';
export declare const JaegerDatasource: DatasourcePlugin<JaegerDatasourceSpec, JaegerClient>;
//# sourceMappingURL=jaeger-datasource.d.ts.map