import { ReactElement } from 'react';
import { JaegerTraceQuerySpec } from '../model';
interface JaegerTraceQueryEditorProps {
    value: JaegerTraceQuerySpec;
    onChange: (next: JaegerTraceQuerySpec) => void;
}
export declare function JaegerTraceQueryEditor(props: JaegerTraceQueryEditorProps): ReactElement;
export {};
//# sourceMappingURL=JaegerTraceQueryEditor.d.ts.map