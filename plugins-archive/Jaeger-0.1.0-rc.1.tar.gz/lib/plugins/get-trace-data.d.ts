import { TraceQueryPlugin } from '@perses-dev/plugin-system';
import { AbsoluteTimeRange } from '@perses-dev/spec';
import * as otlptracev1 from '@perses-dev/spec/dist/dashboard/query-type/otlp/trace/v1/trace';
import { JaegerTrace, JaegerTraceQuerySpec } from '../model';
export declare function getTraceDataTimeRange(timeRange: AbsoluteTimeRange): {
    start: number;
    end: number;
};
export declare const getTraceData: TraceQueryPlugin<JaegerTraceQuerySpec>['getTraceData'];
export declare function jaegerTraceToOTLP(trace: JaegerTrace): otlptracev1.TracesData;
//# sourceMappingURL=get-trace-data.d.ts.map