import { DatasourceClient } from '@perses-dev/plugin-system';
import { RequestHeaders } from '@perses-dev/client';
import { JaegerApiResponse, JaegerOperation, JaegerSearchRequestParameters, JaegerTrace } from './api-types';
interface JaegerClientOptions {
    datasourceUrl: string;
    headers?: RequestHeaders;
}
export interface JaegerClient extends DatasourceClient {
    options: JaegerClientOptions;
    getTrace(traceId: string, headers?: RequestHeaders): Promise<JaegerApiResponse<JaegerTrace[]>>;
    searchTraces(params: JaegerSearchRequestParameters, headers?: RequestHeaders): Promise<JaegerApiResponse<JaegerTrace[]>>;
    searchServices(headers?: RequestHeaders): Promise<JaegerApiResponse<string[]>>;
    searchOperations(service: string, headers?: RequestHeaders): Promise<JaegerApiResponse<JaegerOperation[]>>;
}
export interface QueryOptions {
    datasourceUrl: string;
    headers?: RequestHeaders;
}
export declare const executeRequest: <T>(...args: Parameters<typeof global.fetch>) => Promise<T>;
export declare function getTrace(traceId: string, queryOptions: QueryOptions): Promise<JaegerApiResponse<JaegerTrace[]>>;
export declare function searchTraces(params: JaegerSearchRequestParameters, queryOptions: QueryOptions): Promise<JaegerApiResponse<JaegerTrace[]>>;
export declare function searchServices(queryOptions: QueryOptions): Promise<JaegerApiResponse<string[]>>;
export declare function searchOperations(service: string, queryOptions: QueryOptions): Promise<JaegerApiResponse<JaegerOperation[]>>;
export {};
//# sourceMappingURL=jaeger-client.d.ts.map