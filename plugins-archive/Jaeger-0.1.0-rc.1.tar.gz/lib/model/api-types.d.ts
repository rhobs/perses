export interface JaegerApiResponse<T> {
    data: T;
    total?: number;
    limit?: number;
    offset?: number;
    errors?: JaegerApiError[];
}
export interface JaegerApiError {
    code?: number;
    msg: string;
    traceID?: string;
}
export interface JaegerTrace {
    traceID: string;
    spans: JaegerSpan[];
    processes?: Record<string, JaegerProcess>;
    warnings?: string[] | null;
}
export interface JaegerSpan {
    traceID: string;
    spanID: string;
    operationName: string;
    references?: JaegerReference[];
    startTime: number;
    duration: number;
    tags?: JaegerTag[];
    logs?: JaegerLog[];
    processID?: string;
    process?: JaegerProcess;
    warnings?: string[] | null;
}
export interface JaegerReference {
    refType: 'CHILD_OF' | 'FOLLOWS_FROM' | string;
    traceID: string;
    spanID: string;
}
export interface JaegerProcess {
    serviceName: string;
    tags?: JaegerTag[];
}
export type JaegerTag = {
    key: string;
    type: 'string';
    value: string;
} | {
    key: string;
    type: 'bool';
    value: boolean;
} | {
    key: string;
    type: 'int64';
    value: number;
} | {
    key: string;
    type: 'float64';
    value: number;
} | {
    key: string;
    type: 'binary';
    value: string;
};
export interface JaegerLog {
    timestamp: number;
    fields?: JaegerTag[];
}
export interface JaegerOperation {
    name: string;
    spanKind?: string;
}
export interface JaegerSearchRequestParameters {
    traceID?: string[];
    service?: string;
    operation?: string;
    spanKind?: string;
    tags?: string;
    minDuration?: string;
    maxDuration?: string;
    limit?: number;
    start?: number;
    end?: number;
}
export declare const DEFAULT_SEARCH_LIMIT = 20;
//# sourceMappingURL=api-types.d.ts.map