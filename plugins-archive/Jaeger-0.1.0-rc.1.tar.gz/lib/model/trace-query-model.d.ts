import { DatasourceSelectValue } from '@perses-dev/plugin-system';
import { JaegerDatasourceSelector } from './jaeger-selectors';
export interface JaegerTraceQuerySpec {
    datasource?: DatasourceSelectValue<JaegerDatasourceSelector>;
    traceId?: string;
    service?: string;
    operation?: string;
    spanKind?: string;
    tags?: string;
    minDuration?: string;
    maxDuration?: string;
    limit?: number;
}
//# sourceMappingURL=trace-query-model.d.ts.map