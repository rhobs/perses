import { DatasourceSelectValue } from '@perses-dev/plugin-system';
import { DatasourceSelector } from '@perses-dev/spec';
export declare const JAEGER_DATASOURCE_KIND: "JaegerDatasource";
export interface JaegerDatasourceSelector extends DatasourceSelector {
    kind: typeof JAEGER_DATASOURCE_KIND;
}
export declare const DEFAULT_JAEGER: JaegerDatasourceSelector;
export declare function isDefaultJaegerSelector(datasourceSelectValue: DatasourceSelectValue): boolean;
export declare function isJaegerDatasourceSelector(datasourceSelectValue: DatasourceSelectValue): datasourceSelectValue is JaegerDatasourceSelector;
//# sourceMappingURL=jaeger-selectors.d.ts.map