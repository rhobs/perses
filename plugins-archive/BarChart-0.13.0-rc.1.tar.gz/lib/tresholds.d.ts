import { FormatOptions, ThresholdColorPalette, ThresholdOptions } from '@perses-dev/components';
export type GaugeColorStop = [number, string];
export type EChartsAxisLineColors = GaugeColorStop[];
export declare const defaultThresholdInput: ThresholdOptions;
export declare function convertThresholds(thresholds: ThresholdOptions, unit: FormatOptions, max: number, palette: ThresholdColorPalette): EChartsAxisLineColors;
//# sourceMappingURL=tresholds.d.ts.map