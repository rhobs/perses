import { FormatOptions, ModeOption, SortOption } from '@perses-dev/components';
import { CalculationType, OptionsEditorProps } from '@perses-dev/plugin-system';
import { Definition } from '@perses-dev/spec';
export declare const DEFAULT_FORMAT: FormatOptions;
export declare const DEFAULT_SORT: SortOption;
export declare const DEFAULT_MODE: ModeOption;
export declare const DEFAULT_ORIENTATION: 'horizontal' | 'vertical';
export declare const DEFAULT_GROUP_BY: string[];
export declare const DEFAULT_IS_STACKED = false;
/**
 * The schema for a BarChart panel.
 */
export interface BarChartDefinition extends Definition<BarChartOptions> {
    kind: 'BarChart';
}
/**
 * The Options object type supported by the BarChart panel plugin.
 */
export interface BarChartOptions {
    calculation: CalculationType;
    format?: FormatOptions;
    sort?: SortOption;
    mode?: ModeOption;
    orientation?: 'horizontal' | 'vertical';
    groupBy?: string[];
    isStacked?: boolean;
}
export type BarChartOptionsEditorProps = OptionsEditorProps<BarChartOptions>;
/**
 * Creates the initial/empty options for a BarChart panel.
 */
export declare function createInitialBarChartOptions(): BarChartOptions;
//# sourceMappingURL=bar-chart-model.d.ts.map