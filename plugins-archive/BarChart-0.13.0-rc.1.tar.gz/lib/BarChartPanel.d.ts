import { ReactElement } from 'react';
import { PanelProps } from '@perses-dev/plugin-system';
import { TimeSeriesData } from '@perses-dev/spec';
import { BarChartOptions } from './bar-chart-model';
export type BarChartPanelProps = PanelProps<BarChartOptions, TimeSeriesData>;
export declare function BarChartPanel(props: BarChartPanelProps): ReactElement | null;
//# sourceMappingURL=BarChartPanel.d.ts.map