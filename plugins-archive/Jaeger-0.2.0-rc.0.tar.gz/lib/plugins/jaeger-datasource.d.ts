import type { DatasourcePlugin } from '@perses-dev/plugin-system';
import type { JaegerClient } from '../model';
import type { JaegerDatasourceSpec } from './jaeger-datasource-types';
export declare const JaegerDatasource: DatasourcePlugin<JaegerDatasourceSpec, JaegerClient>;
//# sourceMappingURL=jaeger-datasource.d.ts.map