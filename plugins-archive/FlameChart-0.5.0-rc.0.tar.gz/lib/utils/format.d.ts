export declare function formatNanoDuration(value: number): string;
export declare function formatItemValue(unit: string | undefined, value: number): string;
//# sourceMappingURL=format.d.ts.map