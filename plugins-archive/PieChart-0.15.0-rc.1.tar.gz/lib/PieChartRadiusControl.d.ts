import type { ReactElement } from 'react';
export interface PieChartRadiusValues {
    innerRadius?: number;
    outerRadius: number;
}
export interface PieChartRadiusControlProps extends PieChartRadiusValues {
    onChange: (radius: PieChartRadiusValues) => void;
}
export declare function PieChartRadiusControl({ innerRadius, outerRadius, onChange, }: PieChartRadiusControlProps): ReactElement;
//# sourceMappingURL=PieChartRadiusControl.d.ts.map