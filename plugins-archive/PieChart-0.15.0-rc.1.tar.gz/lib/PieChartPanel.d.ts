import type { PanelProps } from '@perses-dev/plugin-system';
import type { TimeSeriesData } from '@perses-dev/spec';
import type { ReactElement } from 'react';
import type { PieChartOptions } from './pie-chart-model';
export type PieChartPanelProps = PanelProps<PieChartOptions, TimeSeriesData>;
export declare function PieChartPanel(props: PieChartPanelProps): ReactElement | null;
//# sourceMappingURL=PieChartPanel.d.ts.map