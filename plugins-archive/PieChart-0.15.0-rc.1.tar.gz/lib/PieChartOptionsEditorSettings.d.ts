import type { ReactElement } from 'react';
import type { PieChartOptionsEditorProps } from './pie-chart-model';
export declare function PieChartOptionsEditorSettings(props: PieChartOptionsEditorProps): ReactElement;
//# sourceMappingURL=PieChartOptionsEditorSettings.d.ts.map