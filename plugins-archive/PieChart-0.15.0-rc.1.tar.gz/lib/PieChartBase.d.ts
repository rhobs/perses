import type { FormatOptions, ModeOption } from '@perses-dev/components';
import type { ReactElement } from 'react';
export interface PieChartData {
    id?: string;
    name: string;
    value: number | null;
    itemStyle?: {
        color: string;
    };
}
export interface PieChartBaseProps {
    width: number;
    height: number;
    data: PieChartData[] | null;
    mode?: ModeOption;
    showLabels?: boolean;
    formatOptions?: FormatOptions;
    innerRadius?: number;
    outerRadius?: number;
}
export declare function PieChartBase(props: PieChartBaseProps): ReactElement;
//# sourceMappingURL=PieChartBase.d.ts.map