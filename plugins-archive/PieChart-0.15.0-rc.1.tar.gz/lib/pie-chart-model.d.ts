import type { FormatOptions, ModeOption, SortOption } from '@perses-dev/components';
import type { CalculationType, LegendSpecOptions, OptionsEditorProps } from '@perses-dev/plugin-system';
import type { Definition } from '@perses-dev/spec';
export declare const DEFAULT_FORMAT: FormatOptions;
export declare const DEFAULT_SORT: SortOption;
export declare const DEFAULT_MODE: ModeOption;
export declare const DEFAULT_OUTER_RADIUS = 100;
/** Visual settings that control the pie chart's size and colors. */
export interface PieChartVisualOptions {
    /** Inner radius as a whole percentage from 0 to 100. When omitted, the chart renders as a pie. */
    innerRadius?: number;
    /** Outer radius as a whole percentage from 0 to 100. */
    outerRadius: number;
    /** Colors used for the pie chart segments. */
    colorPalette?: string[];
}
export declare const DEFAULT_VISUAL: PieChartVisualOptions;
export interface BarChartDefinition extends Definition<PieChartOptions> {
    kind: 'PieChart';
}
export interface PieChartOptions {
    calculation: CalculationType;
    format?: FormatOptions;
    legend?: LegendSpecOptions;
    mode?: ModeOption;
    showLabels?: boolean;
    sort?: SortOption;
    visual?: PieChartVisualOptions;
    /** @deprecated Use visual.colorPalette. */
    colorPalette?: string[];
    /** @deprecated Retained when reading persisted charts; visual.outerRadius controls the rendered radius. */
    radius?: number;
}
export type PieChartOptionsEditorProps = OptionsEditorProps<PieChartOptions>;
export declare function createInitialPieChartOptions(): PieChartOptions;
export declare function resolvePieChartVisualOptions(options: PieChartOptions): PieChartVisualOptions;
//# sourceMappingURL=pie-chart-model.d.ts.map