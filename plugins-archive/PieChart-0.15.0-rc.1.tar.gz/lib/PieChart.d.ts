import type { PanelPlugin } from '@perses-dev/plugin-system';
import type { PieChartOptions } from './pie-chart-model';
import type { PieChartPanelProps } from './PieChartPanel';
/**
 * The core PieChart panel plugin for Perses.
 */
export declare const PieChart: PanelPlugin<PieChartOptions, PieChartPanelProps>;
//# sourceMappingURL=PieChart.d.ts.map