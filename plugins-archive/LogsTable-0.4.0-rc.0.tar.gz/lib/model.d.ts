import type { ThresholdOptions } from '@perses-dev/components';
import type { PanelProps, LegendSpecOptions, SelectionOptions, OptionsEditorProps, ActionOptions } from '@perses-dev/plugin-system';
import type { LogData } from '@perses-dev/spec';
export type LogsTableProps = PanelProps<LogsTableOptions, LogsQueryData>;
export interface LogsQueryData {
    logs?: LogData;
}
export interface LogsTableOptions {
    legend?: LegendSpecOptions;
    thresholds?: ThresholdOptions;
    allowWrap?: boolean;
    enableDetails?: boolean;
    showTime?: boolean;
    showAll?: boolean;
    selection?: SelectionOptions;
    actions?: ActionOptions;
}
export type LogsTableSettingsEditorProps = OptionsEditorProps<LogsTableOptions>;
//# sourceMappingURL=model.d.ts.map