import type { ReactElement } from 'react';
import type { LogsTableSettingsEditorProps } from './model';
export declare function LogsTableItemSelectionActionsEditor({ value, onChange }: LogsTableSettingsEditorProps): ReactElement;
//# sourceMappingURL=LogsTableItemSelectionActionsEditor.d.ts.map