import type { ReactElement } from 'react';
import type { LogsTableProps } from './model';
export declare function LogsTableComponent(props: LogsTableProps): ReactElement | null;
//# sourceMappingURL=LogsTableComponent.d.ts.map