import type { OptionsEditorProps } from '@perses-dev/plugin-system';
import type { ReactElement } from 'react';
import type { LogsTableOptions } from './model';
type LogsTableSettingsEditorProps = OptionsEditorProps<LogsTableOptions>;
export declare function LogsTableSettingsEditor(props: LogsTableSettingsEditorProps): ReactElement;
export {};
//# sourceMappingURL=LogsTableSettingsEditor.d.ts.map