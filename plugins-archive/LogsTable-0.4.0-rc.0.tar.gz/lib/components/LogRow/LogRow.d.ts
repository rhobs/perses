import type { LogEntry } from '@perses-dev/spec';
import type { ReactNode } from 'react';
import React from 'react';
import './ansiColors.css';
interface LogRowProps {
    log?: LogEntry;
    index: number;
    isExpanded: boolean;
    onToggle: (index: number) => void;
    isExpandable?: boolean;
    showTime?: boolean;
    allowWrap?: boolean;
    isSelected?: boolean;
    onSelect?: (index: number, event: React.MouseEvent) => void;
    itemActionButtons?: ReactNode[];
}
export declare const LogRow: React.NamedExoticComponent<LogRowProps>;
export {};
//# sourceMappingURL=LogRow.d.ts.map