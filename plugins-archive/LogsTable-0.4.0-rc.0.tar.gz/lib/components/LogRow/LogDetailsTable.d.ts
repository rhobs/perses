import type { Labels } from '@perses-dev/spec';
import './ansiColors.css';
import React from 'react';
interface LogDetailsTableProps {
    log: Labels;
}
export declare const LogDetailsTable: React.FC<LogDetailsTableProps>;
export {};
//# sourceMappingURL=LogDetailsTable.d.ts.map