import type { LogEntry } from '@perses-dev/spec';
import React from 'react';
import type { LogsTableOptions } from '../model';
interface VirtualizedLogsListProps {
    logs: LogEntry[];
    spec: LogsTableOptions;
    expandedRows: Set<number>;
    onToggleExpand: (index: number) => void;
}
export declare const VirtualizedLogsList: React.FC<VirtualizedLogsListProps>;
export {};
//# sourceMappingURL=VirtualizedLogsList.d.ts.map