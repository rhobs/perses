import type { LogEntry } from '@perses-dev/spec';
import React from 'react';
import type { LogsTableOptions } from '../model';
interface LogsListProps {
    logs: LogEntry[];
    spec: LogsTableOptions;
}
export declare const LogsList: React.FC<LogsListProps>;
export {};
//# sourceMappingURL=LogsList.d.ts.map