import type { PanelPlugin } from '@perses-dev/plugin-system';
import type { LogsTableOptions, LogsTableProps } from './model';
export declare const LogsTable: PanelPlugin<LogsTableOptions, LogsTableProps>;
//# sourceMappingURL=LogsTable.d.ts.map