import { ReactElement } from 'react';
import { Trace, Span } from '../trace';
export interface SpanEventListProps {
    trace: Trace;
    span: Span;
}
export declare function SpanEventList(props: SpanEventListProps): ReactElement;
//# sourceMappingURL=SpanEvents.d.ts.map