export declare const linkToTrace: string;
export declare const linkToSpan: string;
//# sourceMappingURL=links.d.ts.map