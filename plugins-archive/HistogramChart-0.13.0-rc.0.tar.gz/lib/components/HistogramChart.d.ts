import type { FormatOptions, ThresholdOptions } from '@perses-dev/components';
import type { BucketTuple } from '@perses-dev/spec';
import type { ReactElement } from 'react';
import type { LOG_BASE } from '../histogram-chart-model';
export interface HistogramChartData {
    buckets: BucketTuple[];
}
export interface HistogramChartProps {
    width: number;
    height: number;
    data: HistogramChartData;
    format?: FormatOptions;
    min?: number;
    max?: number;
    thresholds?: ThresholdOptions;
    logBase?: LOG_BASE;
}
export declare function HistogramChart({ width, height, data, format, min, max, thresholds, logBase, }: HistogramChartProps): ReactElement | null;
//# sourceMappingURL=HistogramChart.d.ts.map