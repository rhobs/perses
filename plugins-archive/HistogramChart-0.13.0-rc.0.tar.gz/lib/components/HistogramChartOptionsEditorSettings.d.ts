import type { ReactElement } from 'react';
import type { HistogramChartOptionsEditorProps } from '../histogram-chart-model';
export declare function HistogramChartOptionsEditorSettings(props: HistogramChartOptionsEditorProps): ReactElement;
//# sourceMappingURL=HistogramChartOptionsEditorSettings.d.ts.map