import type { PanelProps } from '@perses-dev/plugin-system';
import type { TimeSeriesData } from '@perses-dev/spec';
import type { ReactElement } from 'react';
import type { HistogramChartOptions } from '../histogram-chart-model';
export type HistogramChartPanelProps = PanelProps<HistogramChartOptions, TimeSeriesData>;
export declare function HistogramChartPanel(props: HistogramChartPanelProps): ReactElement | null;
//# sourceMappingURL=HistogramChartPanel.d.ts.map