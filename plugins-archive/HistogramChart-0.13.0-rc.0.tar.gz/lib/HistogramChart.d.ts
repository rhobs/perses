import type { PanelPlugin } from '@perses-dev/plugin-system';
import type { HistogramChartPanelProps } from './components';
import type { HistogramChartOptions } from './histogram-chart-model';
/**
 * The core HistogramChart panel plugin for Perses.
 */
export declare const HistogramChart: PanelPlugin<HistogramChartOptions, HistogramChartPanelProps>;
//# sourceMappingURL=HistogramChart.d.ts.map