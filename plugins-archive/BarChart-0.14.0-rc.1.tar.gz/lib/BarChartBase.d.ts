import type { FormatOptions, ModeOption } from '@perses-dev/components';
import type { ReactElement } from 'react';
import type { ColorOverride } from './bar-chart-model';
export interface BarChartData {
    label: string;
    value: number | null;
}
export interface StackedBarChartSeries {
    name: string;
    values: Array<number | null>;
}
export interface StackedBarChartData {
    categories: string[];
    series: StackedBarChartSeries[];
}
export interface BarChartBaseProps {
    width: number;
    height: number;
    data: BarChartData[] | null;
    format?: FormatOptions;
    mode?: ModeOption;
    groupedData?: StackedBarChartData | null;
    isStacked?: boolean;
    orientation?: 'horizontal' | 'vertical';
    colorOverrides?: ColorOverride[];
}
export declare function BarChartBase(props: BarChartBaseProps): ReactElement;
//# sourceMappingURL=BarChartBase.d.ts.map