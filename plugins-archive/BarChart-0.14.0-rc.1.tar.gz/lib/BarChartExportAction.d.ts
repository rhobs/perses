import React from 'react';
import type { BarChartPanelProps } from './BarChartPanel';
export declare const BarChartExportAction: React.FC<BarChartPanelProps>;
//# sourceMappingURL=BarChartExportAction.d.ts.map