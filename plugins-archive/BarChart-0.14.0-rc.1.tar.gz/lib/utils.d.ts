import type { SortOption } from '@perses-dev/components';
import type { ColorOverride } from './bar-chart-model';
import type { BarChartData } from './BarChartBase';
export declare function calculatePercentages(data: BarChartData[]): Array<{
    label: string;
    value: number;
}>;
export declare function sortSeriesData(data: BarChartData[], sortOrder?: SortOption): BarChartData[];
/**
 * Returns the color of the first override whose regex matches the given name.
 * Invalid regex patterns are skipped. Returns undefined if no override matches.
 */
export declare function getOverrideColor(name: string, overrides?: ColorOverride[]): string | undefined;
//# sourceMappingURL=utils.d.ts.map