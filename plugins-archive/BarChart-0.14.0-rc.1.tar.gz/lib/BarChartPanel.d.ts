import type { PanelProps } from '@perses-dev/plugin-system';
import type { TimeSeriesData } from '@perses-dev/spec';
import type { ReactElement } from 'react';
import type { BarChartOptions } from './bar-chart-model';
export type BarChartPanelProps = PanelProps<BarChartOptions, TimeSeriesData>;
export declare function BarChartPanel(props: BarChartPanelProps): ReactElement | null;
//# sourceMappingURL=BarChartPanel.d.ts.map