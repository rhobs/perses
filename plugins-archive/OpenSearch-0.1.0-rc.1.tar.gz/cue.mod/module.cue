{
	module: "github.com/perses/plugins/opensearch@v0"
	language: {
		version: "v0.15.1"
	}
	source: {
		kind: "git"
	}
}