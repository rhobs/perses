import { DatasourcePlugin } from '@perses-dev/plugin-system';
import { OpenSearchClient } from '../../model/opensearch-client';
import { OpenSearchDatasourceSpec } from './opensearch-datasource-types';
export declare const OpenSearchDatasource: DatasourcePlugin<OpenSearchDatasourceSpec, OpenSearchClient>;
//# sourceMappingURL=OpenSearchDatasource.d.ts.map