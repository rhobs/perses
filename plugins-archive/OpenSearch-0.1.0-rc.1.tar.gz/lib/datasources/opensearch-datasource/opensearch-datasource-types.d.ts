import { HTTPProxy } from '@perses-dev/spec';
export interface OpenSearchDatasourceSpec {
    directUrl?: string;
    proxy?: HTTPProxy;
}
//# sourceMappingURL=opensearch-datasource-types.d.ts.map