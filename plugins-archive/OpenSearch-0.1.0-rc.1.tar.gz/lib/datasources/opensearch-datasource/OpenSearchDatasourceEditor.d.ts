import { ReactElement } from 'react';
import { OpenSearchDatasourceSpec } from './opensearch-datasource-types';
export interface OpenSearchDatasourceEditorProps {
    value: OpenSearchDatasourceSpec;
    onChange: (next: OpenSearchDatasourceSpec) => void;
    isReadonly?: boolean;
}
export declare function OpenSearchDatasourceEditor(props: OpenSearchDatasourceEditorProps): ReactElement;
//# sourceMappingURL=OpenSearchDatasourceEditor.d.ts.map