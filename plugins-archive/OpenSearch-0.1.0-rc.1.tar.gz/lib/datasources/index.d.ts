export * from './opensearch-datasource';
//# sourceMappingURL=index.d.ts.map