import { DatasourceSelector } from '@perses-dev/spec';
import { DatasourceSelectValue } from '@perses-dev/plugin-system';
export declare const OPENSEARCH_DATASOURCE_KIND: "OpenSearchDatasource";
export interface OpenSearchDatasourceSelector extends DatasourceSelector {
    kind: typeof OPENSEARCH_DATASOURCE_KIND;
}
export declare const DEFAULT_OPENSEARCH: OpenSearchDatasourceSelector;
export declare function isDefaultOpenSearchSelector(datasourceSelectValue: DatasourceSelectValue): boolean;
export declare function isOpenSearchDatasourceSelector(datasourceSelectValue: DatasourceSelectValue): datasourceSelectValue is OpenSearchDatasourceSelector;
//# sourceMappingURL=opensearch-selectors.d.ts.map