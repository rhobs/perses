export type OpenSearchRequestHeaders = Record<string, string>;
export interface OpenSearchPPLColumn {
    name: string;
    type: string;
}
export interface OpenSearchPPLResponse {
    schema: OpenSearchPPLColumn[];
    datarows: Array<Array<string | number | boolean | null>>;
    total?: number;
    size?: number;
}
export interface OpenSearchErrorResponse {
    error?: {
        type?: string;
        reason?: string;
        details?: string;
    };
    status?: number;
}
//# sourceMappingURL=opensearch-client-types.d.ts.map