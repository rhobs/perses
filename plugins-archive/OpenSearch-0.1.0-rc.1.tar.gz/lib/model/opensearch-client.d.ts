import { OpenSearchPPLResponse, OpenSearchRequestHeaders } from './opensearch-client-types';
export interface OpenSearchPPLParams {
    query: string;
}
export interface OpenSearchApiOptions {
    datasourceUrl: string;
    headers?: OpenSearchRequestHeaders;
}
export interface OpenSearchClient {
    options: {
        datasourceUrl: string;
    };
    ppl: (params: OpenSearchPPLParams, headers?: OpenSearchRequestHeaders, signal?: AbortSignal) => Promise<OpenSearchPPLResponse>;
}
export declare class OpenSearchPPLError extends Error {
    readonly status: number;
    readonly body: string;
    constructor(status: number, body: string, message?: string);
}
export declare function ppl(params: OpenSearchPPLParams, options: OpenSearchApiOptions, signal?: AbortSignal): Promise<OpenSearchPPLResponse>;
//# sourceMappingURL=opensearch-client.d.ts.map