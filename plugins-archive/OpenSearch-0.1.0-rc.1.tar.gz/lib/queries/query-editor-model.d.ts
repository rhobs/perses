import { OptionsEditorProps } from '@perses-dev/plugin-system';
type OpenSearchQuerySpec = {
    query: string;
};
/**
 * Keep a local copy of the query input so we don't re-run the panel preview on every keystroke.
 * Changes are propagated to the spec on blur.
 */
export declare function useQueryState<T extends OpenSearchQuerySpec>(props: OptionsEditorProps<T>): {
    query: string;
    handleQueryChange: (e: string) => void;
    handleQueryBlur: () => void;
};
export {};
//# sourceMappingURL=query-editor-model.d.ts.map