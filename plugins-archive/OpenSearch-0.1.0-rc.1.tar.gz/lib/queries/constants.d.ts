export declare const DATASOURCE_KIND = "OpenSearchDatasource";
export declare const DEFAULT_DATASOURCE: {
    kind: string;
};
export declare const DEFAULT_TIMESTAMP_FIELDS: string[];
export declare const DEFAULT_MESSAGE_FIELDS: string[];
export declare const PPL_DOCS_URL = "https://opensearch.org/docs/latest/search-plugins/sql/ppl/index/";
export declare const PPL_QUERY_EXAMPLES = "source=logs-* | where level=\"error\" | head 20\nsource=logs-* | fields @timestamp, service, message | head 50\nsource=logs-* | stats count() by service\nsource=logs-* | where traceId='$traceId'";
//# sourceMappingURL=constants.d.ts.map