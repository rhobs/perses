import { OptionsEditorProps } from '@perses-dev/plugin-system';
import { ReactElement } from 'react';
import { OpenSearchLogQuerySpec } from './opensearch-log-query-types';
type OpenSearchQueryEditorProps = OptionsEditorProps<OpenSearchLogQuerySpec>;
export declare function OpenSearchLogQueryEditor(props: OpenSearchQueryEditorProps): ReactElement;
export {};
//# sourceMappingURL=OpenSearchLogQueryEditor.d.ts.map