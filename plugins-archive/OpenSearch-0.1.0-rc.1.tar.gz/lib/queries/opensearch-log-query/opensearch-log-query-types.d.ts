import { DatasourceSelector } from '@perses-dev/spec';
import { OpenSearchPPLResponse } from '../../model/opensearch-client-types';
export interface OpenSearchLogQuerySpec {
    query: string;
    datasource?: DatasourceSelector;
    index?: string;
    timestampField?: string;
    messageField?: string;
    /** When true, the panel time range is NOT injected as a `where` clause on the timestamp field. */
    disableTimeFilter?: boolean;
}
export type OpenSearchLogQueryResponse = OpenSearchPPLResponse;
//# sourceMappingURL=opensearch-log-query-types.d.ts.map