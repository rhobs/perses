import { LogQueryPlugin } from '@perses-dev/plugin-system';
import { LogData } from '@perses-dev/spec';
import { OpenSearchPPLResponse } from '../../model/opensearch-client-types';
import { OpenSearchLogQuerySpec } from './opensearch-log-query-types';
/**
 * Bound the query to the panel time range using a PPL `where` clause on the
 * configured timestamp field (`@timestamp` by default).
 * The bound is injected immediately after the source clause so it runs before any
 * pipe that drops the timestamp column from the schema (stats, fields, top, etc.).
 * If the user already filters on the timestamp field themselves, PPL ANDs the two clauses.
 */
interface BoundedPPLOptions {
    index?: string;
    timestampField?: string;
    disableTimeFilter?: boolean;
}
export declare function buildBoundedPPL(userQuery: string, start: Date, end: Date, { index, timestampField, disableTimeFilter }?: BoundedPPLOptions): string;
interface ConvertOptions {
    timestampField?: string;
    messageField?: string;
}
export declare function convertPPLToLogs(response: OpenSearchPPLResponse, options?: ConvertOptions): LogData;
export declare function parseTimestamp(v: unknown): number;
export declare const getOpenSearchLogData: LogQueryPlugin<OpenSearchLogQuerySpec>['getLogData'];
export {};
//# sourceMappingURL=get-opensearch-log-data.d.ts.map