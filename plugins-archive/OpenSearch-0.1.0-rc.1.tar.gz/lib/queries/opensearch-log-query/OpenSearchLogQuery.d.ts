import { LogQueryPlugin } from '@perses-dev/plugin-system';
import { OpenSearchLogQuerySpec } from './opensearch-log-query-types';
export declare const OpenSearchLogQuery: LogQueryPlugin<OpenSearchLogQuerySpec>;
//# sourceMappingURL=OpenSearchLogQuery.d.ts.map