export * from './opensearch-log-query';
//# sourceMappingURL=index.d.ts.map