import { UnknownSpec } from '@perses-dev/spec';
import { ReactElement } from 'react';
export interface EmbeddedPanelOptionsEditorProps {
    kind: string;
    spec: UnknownSpec;
    onChange: (next: UnknownSpec) => void;
}
/**
 * Renders a panel plugin's settings tabs (thresholds, units, colors, …).
 * Used for embedded GaugeChart columns only; other embedded panel kinds use defaults.
 */
export declare function EmbeddedPanelOptionsEditor({ kind, spec, onChange }: EmbeddedPanelOptionsEditorProps): ReactElement;
//# sourceMappingURL=EmbeddedPanelOptionsEditor.d.ts.map