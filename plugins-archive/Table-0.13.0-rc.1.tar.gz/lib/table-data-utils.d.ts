import { PanelData } from '@perses-dev/plugin-system';
import { TimeSeriesData } from '@perses-dev/spec';
import { TableOptions } from './models';
/**
 * Options for building raw table data.
 */
export interface BuildRawTableDataOptions {
    /**
     * When true, always use raw scalar values for cell data (for export).
     * When false, plugin columns will contain embedded PanelData objects (for rendering).
     */
    forExport?: boolean;
}
/**
 * Determines the query mode based on table options.
 * If any column has a plugin (embedded panel), use range mode; otherwise instant.
 */
export declare function getTablePanelQueryMode(spec: TableOptions): 'instant' | 'range';
/**
 * Converts raw query results into a tabular format.
 *
 * This is the shared data-building logic used by both TablePanel (for rendering)
 * and TableExportAction (for CSV export). Extracting this ensures both use the
 * same transformation logic, reducing drift.
 *
 * @param queryResults - The panel query results containing time series data
 * @param spec - The table options specification
 * @param options - Build options (e.g., forExport mode)
 * @returns Array of row objects with column keys and values
 */
export declare function buildRawTableData(queryResults: Array<PanelData<TimeSeriesData>>, spec: TableOptions, options?: BuildRawTableDataOptions): Array<Record<string, unknown>>;
//# sourceMappingURL=table-data-utils.d.ts.map