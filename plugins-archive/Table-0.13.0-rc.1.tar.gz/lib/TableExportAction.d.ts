import React from 'react';
import { PanelData } from '@perses-dev/plugin-system';
import { TimeSeriesData } from '@perses-dev/spec';
import { TableProps } from './components';
import type { TableOptions } from './models';
export interface ExportColumn {
    key: string;
    header: string;
}
/**
 * Converts raw query results into the same tabular structure that TablePanel
 * renders, applying indexed column naming and configured transforms so the
 * CSV output matches the visual table.
 */
export declare function buildTableData(queryResults: Array<PanelData<TimeSeriesData>>, spec: TableOptions): {
    data: Array<Record<string, unknown>>;
    columns: ExportColumn[];
};
export declare const TableExportAction: React.FC<TableProps>;
//# sourceMappingURL=TableExportAction.d.ts.map