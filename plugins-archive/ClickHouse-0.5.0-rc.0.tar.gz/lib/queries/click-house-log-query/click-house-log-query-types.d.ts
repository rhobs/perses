import { DatasourceSelector } from '@perses-dev/core';
export interface ClickHouseLogQuerySpec {
    query: string;
    datasource?: DatasourceSelector;
}
//# sourceMappingURL=click-house-log-query-types.d.ts.map