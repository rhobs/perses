import { TimeSeriesQueryPlugin } from '@perses-dev/plugin-system';
import { ClickHouseTimeSeriesQuerySpec } from './click-house-query-types';
export declare const getTimeSeriesData: TimeSeriesQueryPlugin<ClickHouseTimeSeriesQuerySpec>['getTimeSeriesData'];
//# sourceMappingURL=get-click-house-data.d.ts.map