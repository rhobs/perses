import { TimeSeriesQueryPlugin } from '@perses-dev/plugin-system';
import { ClickHouseTimeSeriesQuerySpec } from './click-house-query-types';
export declare const ClickHouseTimeSeriesQuery: TimeSeriesQueryPlugin<ClickHouseTimeSeriesQuerySpec>;
//# sourceMappingURL=ClickHouseQuery.d.ts.map