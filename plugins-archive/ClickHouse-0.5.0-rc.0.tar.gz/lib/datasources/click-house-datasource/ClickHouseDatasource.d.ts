import { DatasourcePlugin } from '@perses-dev/plugin-system';
import { ClickHouseDatasourceSpec, ClickHouseDatasourceClient } from './click-house-datasource-types';
export declare const ClickHouseDatasource: DatasourcePlugin<ClickHouseDatasourceSpec, ClickHouseDatasourceClient>;
//# sourceMappingURL=ClickHouseDatasource.d.ts.map