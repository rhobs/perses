import { ReactCodeMirrorProps } from '@uiw/react-codemirror';
import { ReactElement } from 'react';
export type ClickQLEditorProps = Omit<ReactCodeMirrorProps, 'theme' | 'extensions'>;
export declare function ClickQLEditor(props: ClickQLEditorProps): ReactElement;
//# sourceMappingURL=ClickQLEditor.d.ts.map