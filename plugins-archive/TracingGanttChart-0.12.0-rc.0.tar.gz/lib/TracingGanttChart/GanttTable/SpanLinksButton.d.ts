import { Span } from '../trace';
import { CustomLinks } from '../../gantt-chart-model';
export interface SpanLinksButtonProps {
    customLinks: CustomLinks;
    span: Span;
}
export declare function SpanLinksButton(props: SpanLinksButtonProps): import("react/jsx-runtime").JSX.Element | null;
//# sourceMappingURL=SpanLinksButton.d.ts.map