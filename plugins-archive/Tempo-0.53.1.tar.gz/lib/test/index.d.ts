export * from './mock-data';
//# sourceMappingURL=index.d.ts.map