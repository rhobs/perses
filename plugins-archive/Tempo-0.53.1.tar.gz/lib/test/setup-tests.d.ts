import '@testing-library/jest-dom/extend-expect';
//# sourceMappingURL=setup-tests.d.ts.map