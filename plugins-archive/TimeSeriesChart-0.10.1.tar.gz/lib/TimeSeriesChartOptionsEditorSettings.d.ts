import { ReactElement } from 'react';
import { TimeSeriesChartOptionsEditorProps } from './time-series-chart-model';
export declare function TimeSeriesChartOptionsEditorSettings(props: TimeSeriesChartOptionsEditorProps): ReactElement;
//# sourceMappingURL=TimeSeriesChartOptionsEditorSettings.d.ts.map