import React from 'react';
import { LogEntry } from '@perses-dev/spec';
import { LogsTableOptions } from '../model';
interface LogsListProps {
    logs: LogEntry[];
    spec: LogsTableOptions;
}
export declare const LogsList: React.FC<LogsListProps>;
export {};
//# sourceMappingURL=LogsList.d.ts.map