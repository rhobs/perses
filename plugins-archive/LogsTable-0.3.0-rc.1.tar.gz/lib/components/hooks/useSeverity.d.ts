import { LogEntry } from '@perses-dev/spec';
export declare const useSeverityColor: (log?: LogEntry) => string;
//# sourceMappingURL=useSeverity.d.ts.map