import React from 'react';
import './ansiColors.css';
import { Labels } from '@perses-dev/spec';
interface LogDetailsTableProps {
    log: Labels;
}
export declare const LogDetailsTable: React.FC<LogDetailsTableProps>;
export {};
//# sourceMappingURL=LogDetailsTable.d.ts.map