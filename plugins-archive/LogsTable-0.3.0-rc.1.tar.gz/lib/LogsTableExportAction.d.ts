import { LogsTableProps } from './model';
export declare const LogsTableExportAction: React.FC<LogsTableProps>;
//# sourceMappingURL=LogsTableExportAction.d.ts.map