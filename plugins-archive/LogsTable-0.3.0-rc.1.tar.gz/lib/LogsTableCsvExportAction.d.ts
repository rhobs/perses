import { LogEntry } from '@perses-dev/spec';
import { LogsTableProps } from './model';
export declare function collectLabelKeys(entries: LogEntry[]): string[];
export declare function buildLogsCsvString(entries: LogEntry[]): string;
export declare const LogsTableCsvExportAction: React.FC<LogsTableProps>;
//# sourceMappingURL=LogsTableCsvExportAction.d.ts.map