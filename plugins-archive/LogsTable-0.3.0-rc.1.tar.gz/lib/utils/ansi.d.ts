export declare function ansiToSanitizedHtml(text: string): string | null;
export declare function stripAnsi(text: string): string;
//# sourceMappingURL=ansi.d.ts.map