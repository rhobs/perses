import type { PanelPlugin } from '@perses-dev/plugin-system';
import type { ScatterChartOptions } from './scatter-chart-model';
import type { ScatterChartPanelProps } from './ScatterChartPanel';
/**
 * The core ScatterChart panel plugin for Perses.
 */
export declare const ScatterChart: PanelPlugin<ScatterChartOptions, ScatterChartPanelProps>;
//# sourceMappingURL=ScatterChart.d.ts.map