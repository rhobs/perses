import type { EChartsOption } from 'echarts';
import type { ReactElement } from 'react';
export interface ScatterplotProps {
    width: number;
    height: number;
    options: EChartsOption;
    link?: string;
}
export declare function Scatterplot(props: ScatterplotProps): ReactElement;
//# sourceMappingURL=Scatterplot.d.ts.map