import { CalculationsMap, CalculationType, TimeSeries } from '@perses-dev/core';
export declare const calculateValue: (calculation: CalculationType, seriesData: TimeSeries) => ReturnType<(typeof CalculationsMap)[CalculationType]>;
//# sourceMappingURL=calculate-value.d.ts.map