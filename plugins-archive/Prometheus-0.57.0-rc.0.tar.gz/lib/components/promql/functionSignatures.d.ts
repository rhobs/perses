import { Func } from './ast';
export declare const functionSignatures: Record<string, Func>;
//# sourceMappingURL=functionSignatures.d.ts.map