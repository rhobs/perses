export declare function replacePromBuiltinVariables(query: string, minStepMs: number, intervalMs: number): string;
//# sourceMappingURL=replace-prom-builtin-variables.d.ts.map