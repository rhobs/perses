import { PanelPlugin } from '@perses-dev/plugin-system';
import { MarkdownPanelOptions } from './markdown-panel-model';
/**
 * The core Markdown panel plugin in Perses.
 */
export declare const Markdown: PanelPlugin<MarkdownPanelOptions>;
//# sourceMappingURL=Markdown.d.ts.map