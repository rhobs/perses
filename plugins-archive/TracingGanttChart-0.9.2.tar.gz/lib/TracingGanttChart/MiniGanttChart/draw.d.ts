import { Span, Trace } from '../trace';
export declare function drawSpans(ctx: CanvasRenderingContext2D, width: number, height: number, trace: Trace, spanColorGenerator: (span: Span) => string): void;
//# sourceMappingURL=draw.d.ts.map