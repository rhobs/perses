import type { DatasourcePlugin } from '@perses-dev/plugin-system';
import type { VictoriaLogsClient } from '../../model/client';
import type { VictoriaLogsDatasourceSpec } from './types';
export declare const VictoriaLogsDatasource: DatasourcePlugin<VictoriaLogsDatasourceSpec, VictoriaLogsClient>;
//# sourceMappingURL=VictoriaLogsDatasource.d.ts.map