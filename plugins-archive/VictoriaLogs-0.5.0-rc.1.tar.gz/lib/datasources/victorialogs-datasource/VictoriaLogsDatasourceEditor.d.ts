import type { ReactElement } from 'react';
import type { VictoriaLogsDatasourceSpec } from './types';
export interface VictoriaLogsDatasourceEditorProps {
    value: VictoriaLogsDatasourceSpec;
    onChange: (next: VictoriaLogsDatasourceSpec) => void;
    isReadonly?: boolean;
}
export declare function VictoriaLogsDatasourceEditor(props: VictoriaLogsDatasourceEditorProps): ReactElement;
//# sourceMappingURL=VictoriaLogsDatasourceEditor.d.ts.map