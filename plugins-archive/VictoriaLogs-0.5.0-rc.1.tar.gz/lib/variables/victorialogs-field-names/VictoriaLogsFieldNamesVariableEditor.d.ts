import type { OptionsEditorProps } from '@perses-dev/plugin-system';
import type { ReactElement } from 'react';
import type { VictoriaLogsFieldNamesVariableOptions } from '../types';
export declare function VictoriaLogsFieldNamesVariableEditor(props: OptionsEditorProps<VictoriaLogsFieldNamesVariableOptions>): ReactElement;
//# sourceMappingURL=VictoriaLogsFieldNamesVariableEditor.d.ts.map