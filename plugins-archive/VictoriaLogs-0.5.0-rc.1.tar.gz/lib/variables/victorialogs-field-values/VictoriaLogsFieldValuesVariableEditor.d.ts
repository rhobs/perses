import type { OptionsEditorProps } from '@perses-dev/plugin-system';
import type { ReactElement } from 'react';
import type { VictoriaLogsFieldValuesVariableOptions } from '../types';
export declare function VictoriaLogsFieldValuesVariableEditor(props: OptionsEditorProps<VictoriaLogsFieldValuesVariableOptions>): ReactElement;
//# sourceMappingURL=VictoriaLogsFieldValuesVariableEditor.d.ts.map