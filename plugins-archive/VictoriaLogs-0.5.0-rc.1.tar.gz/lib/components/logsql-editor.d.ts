import type { ReactCodeMirrorProps } from '@uiw/react-codemirror';
import type { ReactElement } from 'react';
export type LogsQLEditorProps = Omit<ReactCodeMirrorProps, 'theme' | 'extensions'>;
export declare function LogsQLEditor(props: LogsQLEditorProps): ReactElement;
//# sourceMappingURL=logsql-editor.d.ts.map