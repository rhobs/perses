import { LRLanguage } from '@codemirror/language';
import type { Extension } from '@uiw/react-codemirror';
export declare function createLogsQLExtension(): Array<LRLanguage | Extension>;
//# sourceMappingURL=logsql-extension.d.ts.map