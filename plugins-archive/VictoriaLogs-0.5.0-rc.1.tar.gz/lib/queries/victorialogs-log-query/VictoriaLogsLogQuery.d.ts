import type { LogQueryPlugin } from '@perses-dev/plugin-system';
import type { VictoriaLogsLogQuerySpec } from './types';
export declare const VictoriaLogsLogQuery: LogQueryPlugin<VictoriaLogsLogQuerySpec>;
//# sourceMappingURL=VictoriaLogsLogQuery.d.ts.map