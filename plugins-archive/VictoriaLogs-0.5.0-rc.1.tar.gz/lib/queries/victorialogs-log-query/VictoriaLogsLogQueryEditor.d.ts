import type { OptionsEditorProps } from '@perses-dev/plugin-system';
import type { ReactElement } from 'react';
import type { VictoriaLogsLogQuerySpec } from './types';
type VictoriaLogsQueryEditorProps = OptionsEditorProps<VictoriaLogsLogQuerySpec>;
export declare function VictoriaLogsLogQueryEditor(props: VictoriaLogsQueryEditorProps): ReactElement;
export {};
//# sourceMappingURL=VictoriaLogsLogQueryEditor.d.ts.map