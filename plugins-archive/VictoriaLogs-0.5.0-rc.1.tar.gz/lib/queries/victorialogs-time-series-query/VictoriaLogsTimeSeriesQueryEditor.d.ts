import type { OptionsEditorProps } from '@perses-dev/plugin-system';
import type { ReactElement } from 'react';
import type { VictoriaLogsTimeSeriesQuerySpec } from './types';
type VictoriaLogsQueryEditorProps = OptionsEditorProps<VictoriaLogsTimeSeriesQuerySpec>;
export declare function VictoriaLogsQueryEditor(props: VictoriaLogsQueryEditorProps): ReactElement;
export {};
//# sourceMappingURL=VictoriaLogsTimeSeriesQueryEditor.d.ts.map