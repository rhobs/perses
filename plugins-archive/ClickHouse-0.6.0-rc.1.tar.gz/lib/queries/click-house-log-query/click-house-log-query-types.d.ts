import { DatasourceSelector } from '@perses-dev/spec';
export interface ClickHouseLogQuerySpec {
    query: string;
    datasource?: DatasourceSelector;
}
//# sourceMappingURL=click-house-log-query-types.d.ts.map