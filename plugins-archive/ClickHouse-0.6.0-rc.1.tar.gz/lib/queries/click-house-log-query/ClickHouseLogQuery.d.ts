import { LogQueryPlugin } from '@perses-dev/plugin-system';
import { ClickHouseLogQuerySpec } from './click-house-log-query-types';
export declare const ClickHouseLogQuery: LogQueryPlugin<ClickHouseLogQuerySpec>;
//# sourceMappingURL=ClickHouseLogQuery.d.ts.map