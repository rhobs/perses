import { LogQueryPlugin } from '@perses-dev/plugin-system';
import { ClickHouseLogQuerySpec } from './click-house-log-query-types';
export declare const getClickHouseLogData: LogQueryPlugin<ClickHouseLogQuerySpec>['getLogData'];
//# sourceMappingURL=get-click-house-log-data.d.ts.map