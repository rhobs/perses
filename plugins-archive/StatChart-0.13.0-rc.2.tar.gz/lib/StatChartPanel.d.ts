import { FC } from 'react';
import { PanelProps } from '@perses-dev/plugin-system';
import { TimeSeriesData } from '@perses-dev/spec';
import { StatChartOptions } from './stat-chart-model';
export type StatChartPanelProps = PanelProps<StatChartOptions, TimeSeriesData>;
export declare const StatChartPanel: FC<StatChartPanelProps>;
//# sourceMappingURL=StatChartPanel.d.ts.map