import { CalculationsMap, CalculationType } from '@perses-dev/plugin-system';
import { TimeSeries } from '@perses-dev/spec';
export declare const calculateValue: (calculation: CalculationType, seriesData: TimeSeries) => ReturnType<(typeof CalculationsMap)[CalculationType]>;
//# sourceMappingURL=calculate-value.d.ts.map