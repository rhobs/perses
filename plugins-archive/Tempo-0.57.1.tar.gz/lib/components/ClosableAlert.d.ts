import { ReactElement } from 'react';
import { AlertProps } from '@mui/material';
export declare function ClosableAlert(props: AlertProps): ReactElement | null;
//# sourceMappingURL=ClosableAlert.d.ts.map