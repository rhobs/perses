{
	module: "github.com/perses/plugins/table@v0"
	language: {
		version: "v0.17.1"
	}
	source: {
		kind: "git"
	}
}