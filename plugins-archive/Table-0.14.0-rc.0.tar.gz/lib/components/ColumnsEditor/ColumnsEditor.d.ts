import type { ReactElement } from 'react';
import type { ColumnSettings } from '../../models';
export interface ColumnsEditorProps {
    columnSettings: ColumnSettings[];
    onChange: (columnOptions: ColumnSettings[]) => void;
    defaultEnableSorting?: boolean;
}
export declare function ColumnsEditor({ columnSettings, onChange, defaultEnableSorting }: ColumnsEditorProps): ReactElement;
//# sourceMappingURL=ColumnsEditor.d.ts.map