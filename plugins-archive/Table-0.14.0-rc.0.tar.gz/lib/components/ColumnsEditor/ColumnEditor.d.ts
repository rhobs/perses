import type { StackProps } from '@mui/material';
import type { ReactElement } from 'react';
import type { ColumnSettings } from '../../models';
type OmittedMuiProps = 'children' | 'value' | 'onChange';
export interface ColumnEditorProps extends Omit<StackProps, OmittedMuiProps> {
    column: ColumnSettings;
    onChange: (column: ColumnSettings) => void;
    defaultEnableSorting?: boolean;
}
export declare function ColumnEditor({ column, onChange, defaultEnableSorting, ...others }: ColumnEditorProps): ReactElement;
export {};
//# sourceMappingURL=ColumnEditor.d.ts.map