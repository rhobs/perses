import type { OptionsEditorProps } from '@perses-dev/plugin-system';
import type { ReactElement } from 'react';
import type { TableOptions } from '../models';
export type TableColumnsEditorProps = OptionsEditorProps<TableOptions>;
export declare function TableColumnsEditor({ onChange, value }: TableColumnsEditorProps): ReactElement;
//# sourceMappingURL=TableColumnsEditor.d.ts.map