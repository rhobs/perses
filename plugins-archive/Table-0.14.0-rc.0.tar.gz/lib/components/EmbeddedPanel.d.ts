import type { PanelData } from '@perses-dev/plugin-system';
import type { QueryDataType, UnknownSpec } from '@perses-dev/spec';
import type { ReactElement } from 'react';
interface EmbeddedPanelProps {
    kind: string;
    spec: UnknownSpec;
    queryResults: Array<PanelData<QueryDataType>>;
}
export declare function EmbeddedPanel({ kind, spec, queryResults }: EmbeddedPanelProps): ReactElement;
export {};
//# sourceMappingURL=EmbeddedPanel.d.ts.map