import type { OptionsEditorProps } from '@perses-dev/plugin-system';
import type { ReactElement } from 'react';
import type { TableOptions } from '../models';
export type TableCellsEditorProps = OptionsEditorProps<TableOptions>;
export declare function TableCellsEditor({ onChange, value }: TableCellsEditorProps): ReactElement;
//# sourceMappingURL=TableCellsEditor.d.ts.map