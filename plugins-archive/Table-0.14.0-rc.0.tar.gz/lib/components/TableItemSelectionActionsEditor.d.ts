import type { ReactElement } from 'react';
import type { TableSettingsEditorProps } from '../models';
export declare function TableItemSelectionActionsEditor({ value, onChange }: TableSettingsEditorProps): ReactElement;
//# sourceMappingURL=TableItemSelectionActionsEditor.d.ts.map