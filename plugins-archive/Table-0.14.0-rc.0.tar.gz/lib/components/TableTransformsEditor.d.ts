import type { ReactElement } from 'react';
import type { TableSettingsEditorProps } from '../models';
export declare function TableTransformsEditor({ value, onChange }: TableSettingsEditorProps): ReactElement;
//# sourceMappingURL=TableTransformsEditor.d.ts.map