import type { ReactElement } from 'react';
import type { TableSettingsEditorProps } from '../models';
export declare function TableSettingsEditor({ onChange, value }: TableSettingsEditorProps): ReactElement;
//# sourceMappingURL=TableSettingsEditor.d.ts.map