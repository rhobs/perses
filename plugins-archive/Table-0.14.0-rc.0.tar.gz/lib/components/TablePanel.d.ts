import type { PanelProps } from '@perses-dev/plugin-system';
import type { JsonData, TimeSeriesData } from '@perses-dev/spec';
import type { ReactElement } from 'react';
import type { TableOptions } from '../models';
export declare function getTablePanelQueryOptions(spec: TableOptions): {
    mode: 'instant' | 'range';
};
export type TableProps = PanelProps<TableOptions, TimeSeriesData | JsonData>;
export declare function TablePanel({ contentDimensions, spec, queryResults }: TableProps): ReactElement | null;
//# sourceMappingURL=TablePanel.d.ts.map