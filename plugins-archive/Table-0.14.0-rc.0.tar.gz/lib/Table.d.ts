import type { PanelPlugin } from '@perses-dev/plugin-system';
import type { TableProps } from './components';
import type { TableOptions } from './models';
/**
 * The core TimeSeriesTable panel plugin for Perses.
 */
export declare const Table: PanelPlugin<TableOptions, TableProps>;
//# sourceMappingURL=Table.d.ts.map