import type { TimeSeriesData } from '@perses-dev/spec';
export declare const MOCK_TIME_SERIES_QUERY_RESULT_MULTIVALUE: {
    status: string;
    fetchStatus: string;
    isLoading: boolean;
    isSuccess: boolean;
    isError: boolean;
    data: {
        timeRange: {
            start: Date;
            end: Date;
        };
        stepMs: number;
        series: {
            name: string;
            values: number[][];
            labels: {
                device: string;
                env: string;
                fstype: string;
                instance: string;
                job: string;
                mountpoint: string;
            };
        }[];
    };
    dataUpdatedAt: number;
    error: null;
    errorUpdatedAt: number;
    failureCount: number;
    errorUpdateCount: number;
    isFetched: boolean;
    isFetchedAfterMount: boolean;
    isFetching: boolean;
    isRefetching: boolean;
    isLoadingError: boolean;
    isPaused: boolean;
    isPlaceholderData: boolean;
    isPreviousData: boolean;
    isRefetchError: boolean;
    isStale: boolean;
}[];
export declare const MOCK_TIME_SERIES_QUERY_RESULT_SINGLEVALUE: {
    status: string;
    fetchStatus: string;
    isLoading: boolean;
    isSuccess: boolean;
    isError: boolean;
    data: {
        timeRange: {
            start: Date;
            end: Date;
        };
        stepMs: number;
        series: {
            name: string;
            values: number[][];
            labels: {
                device: string;
                env: string;
                fstype: string;
                instance: string;
                job: string;
                mountpoint: string;
            };
        }[];
    };
    dataUpdatedAt: number;
    error: null;
    errorUpdatedAt: number;
    failureCount: number;
    errorUpdateCount: number;
    isFetched: boolean;
    isFetchedAfterMount: boolean;
    isFetching: boolean;
    isRefetching: boolean;
    isLoadingError: boolean;
    isPaused: boolean;
    isPlaceholderData: boolean;
    isPreviousData: boolean;
    isRefetchError: boolean;
    isStale: boolean;
}[];
export declare const MOCK_TIME_SERIES_DATA_MULTIVALUE: TimeSeriesData;
export declare const MOCK_TIME_SERIES_DATA_SINGLEVALUE: TimeSeriesData;
export declare const MOCK_NULL_QUERY_RESULT: {
    status: string;
    fetchStatus: string;
    isLoading: boolean;
    isSuccess: boolean;
    isError: boolean;
    data: {
        timeRange: {
            start: Date;
            end: Date;
        };
        stepMs: number;
        series: {
            name: string;
            values: (number | null)[][];
            formattedName: string;
            labels: {
                env: string;
                instance: string;
                job: string;
            };
        }[];
    };
    dataUpdatedAt: number;
    error: null;
    errorUpdatedAt: number;
    failureCount: number;
    errorUpdateCount: number;
    isFetched: boolean;
    isFetchedAfterMount: boolean;
    isFetching: boolean;
    isRefetching: boolean;
    isLoadingError: boolean;
    isPaused: boolean;
    isPlaceholderData: boolean;
    isPreviousData: boolean;
    isRefetchError: boolean;
    isStale: boolean;
}[];
export declare const MOCK_MULTI_QUERY_DATA_Q1: TimeSeriesData;
export declare const MOCK_MULTI_QUERY_DATA_Q2: TimeSeriesData;
export declare const MOCK_MULTI_QUERY_DATA_WITH_ZERO: TimeSeriesData;
export declare const MOCK_MULTI_QUERY_DATA_EMPTY: TimeSeriesData;
export declare const MOCK_TIME_SERIES_QUERY_DEFINITION: {
    kind: string;
    spec: {
        plugin: {
            kind: string;
            spec: {
                query: string;
            };
        };
    };
};
//# sourceMappingURL=mock-query-results.d.ts.map