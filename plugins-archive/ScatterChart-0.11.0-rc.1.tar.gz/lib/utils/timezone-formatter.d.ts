/**
 * Creates a timezone-aware axis formatter function for different time ranges
 */
export declare function createTimezoneAwareAxisFormatter(rangeMs: number, timeZone: string): (value: number) => string;
//# sourceMappingURL=timezone-formatter.d.ts.map