{
	module: "github.com/perses/plugins/prometheus@v0"
	language: {
		version: "v0.17.1"
	}
	source: {
		kind: "git"
	}
}