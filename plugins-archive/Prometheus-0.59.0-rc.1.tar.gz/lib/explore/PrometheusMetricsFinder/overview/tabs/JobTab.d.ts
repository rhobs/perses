import type { StackProps } from '@mui/material';
import type { DatasourceSelector } from '@perses-dev/spec';
import type { ReactElement } from 'react';
import type { LabelFilter } from '../../types';
export interface JobList extends StackProps {
    job: string;
    filters: LabelFilter[];
    datasource: DatasourceSelector;
    isMetadataEnabled?: boolean;
    onExplore: (metricName: string) => void;
}
export declare function JobList({ job, filters, datasource, isMetadataEnabled, onExplore, ...props }: JobList): ReactElement;
export interface JobSection extends StackProps {
    jobs: string[];
    filters: LabelFilter[];
    datasource: DatasourceSelector;
    isMetadataEnabled?: boolean;
    onExplore: (metricName: string) => void;
}
export declare function JobSection({ jobs, filters, datasource, isMetadataEnabled, onExplore, ...props }: JobSection): ReactElement;
export interface JobTabProps extends StackProps {
    filters: LabelFilter[];
    datasource: DatasourceSelector;
    isMetadataEnabled?: boolean;
    onExplore: (metricName: string) => void;
}
export declare function JobTab({ filters, datasource, isMetadataEnabled, onExplore, ...props }: JobTabProps): ReactElement;
//# sourceMappingURL=JobTab.d.ts.map