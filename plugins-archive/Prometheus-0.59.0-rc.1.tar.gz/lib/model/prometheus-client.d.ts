import { fetch, fetchJson } from '@perses-dev/client';
import type { RequestHeaders } from '@perses-dev/client';
import type { QueryParamValues } from '@perses-dev/components';
import type { DatasourceClient } from '@perses-dev/plugin-system';
import type { InstantQueryRequestParameters, InstantQueryResponse, LabelNamesRequestParameters, LabelNamesResponse, LabelValuesRequestParameters, LabelValuesResponse, MetricMetadataRequestParameters, MetricMetadataResponse, ParseQueryRequestParameters, ParseQueryResponse, QueryExemplarsRequestParameters, QueryExemplarsResponse, RangeQueryRequestParameters, RangeQueryResponse, SeriesRequestParameters, SeriesResponse } from './api-types';
interface PrometheusClientOptions {
    datasourceUrl: string;
    headers?: RequestHeaders;
}
export interface ClientRequestOptions {
    headers?: RequestHeaders;
    signal?: AbortSignal;
    queryParams?: QueryParamValues;
    fetch?: typeof fetch;
    fetchJson?: typeof fetchJson;
}
export interface PrometheusClient extends DatasourceClient {
    options: PrometheusClientOptions;
    instantQuery(params: InstantQueryRequestParameters, options?: ClientRequestOptions): Promise<InstantQueryResponse>;
    rangeQuery(params: RangeQueryRequestParameters, options?: ClientRequestOptions): Promise<RangeQueryResponse>;
    queryExemplars(params: QueryExemplarsRequestParameters, options?: ClientRequestOptions): Promise<QueryExemplarsResponse>;
    labelNames(params: LabelNamesRequestParameters, options?: ClientRequestOptions): Promise<LabelNamesResponse>;
    labelValues(params: LabelValuesRequestParameters, options?: ClientRequestOptions): Promise<LabelValuesResponse>;
    metricMetadata(params: MetricMetadataRequestParameters, options?: ClientRequestOptions): Promise<MetricMetadataResponse>;
    series(params: SeriesRequestParameters, options?: ClientRequestOptions): Promise<SeriesResponse>;
    parseQuery(params: ParseQueryRequestParameters, options?: ClientRequestOptions): Promise<ParseQueryResponse>;
}
export interface QueryOptions {
    datasourceUrl: string;
    headers?: RequestHeaders;
    signal?: AbortSignal;
    queryParams?: QueryParamValues;
    fetch?: typeof fetch;
    fetchJson?: typeof fetchJson;
}
export declare function mergeQueryParams(defaults?: QueryParamValues, overrides?: QueryParamValues): QueryParamValues | undefined;
/**
 * Calls the `/-/healthy` endpoint to check if the datasource is healthy.
 */
export declare function healthCheck(queryOptions: QueryOptions): () => Promise<boolean>;
/**
 * Calls the `/api/v1/query` endpoint to get metrics data.
 */
export declare function instantQuery(params: InstantQueryRequestParameters, queryOptions: QueryOptions): Promise<InstantQueryResponse>;
/**
 * Calls the `/api/v1/query_range` endpoint to get metrics data.
 */
export declare function rangeQuery(params: RangeQueryRequestParameters, queryOptions: QueryOptions): Promise<RangeQueryResponse>;
/**
 * Calls the `/api/v1/query_exemplars` endpoint to get exemplar data for a query.
 */
export declare function queryExemplars(params: QueryExemplarsRequestParameters, queryOptions: QueryOptions): Promise<QueryExemplarsResponse>;
/**
 * Calls the `/api/v1/labels` endpoint to get a list of label names.
 */
export declare function labelNames(params: LabelNamesRequestParameters, queryOptions: QueryOptions): Promise<LabelNamesResponse>;
/**
 * Calls the `/api/v1/label/{labelName}/values` endpoint to get a list of values for a label.
 */
export declare function labelValues(params: LabelValuesRequestParameters, queryOptions: QueryOptions): Promise<LabelValuesResponse>;
/**
 * Calls the `/api/v1/label/{labelName}/values` endpoint to get a list of values for a label.
 */
export declare function metricMetadata(params: MetricMetadataRequestParameters, queryOptions: QueryOptions): Promise<MetricMetadataResponse>;
/**
 * Calls the `/api/v1/series` endpoint to finding series by label matchers.
 */
export declare function series(params: SeriesRequestParameters, queryOptions: QueryOptions): Promise<SeriesResponse>;
/**
 * Calls the `/api/v1/parse_query` to parse the given promQL expresion into an abstract syntax tree (AST).
 */
export declare function parseQuery(params: ParseQueryRequestParameters, queryOptions: QueryOptions): Promise<ParseQueryResponse>;
export {};
//# sourceMappingURL=prometheus-client.d.ts.map