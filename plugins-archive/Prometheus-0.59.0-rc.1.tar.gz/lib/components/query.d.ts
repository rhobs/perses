import type { StatusError } from '@perses-dev/client';
import type { DatasourceSelector } from '@perses-dev/spec';
import type { UseQueryResult } from '@tanstack/react-query';
import type { MonitoredInstantQueryResponse, ParseQueryResponse } from '../model';
export declare function useParseQuery(content: string, datasource: DatasourceSelector, enabled?: boolean): UseQueryResult<ParseQueryResponse, StatusError>;
export declare function useInstantQuery(content: string, datasource: DatasourceSelector, enabled?: boolean): UseQueryResult<MonitoredInstantQueryResponse, StatusError>;
//# sourceMappingURL=query.d.ts.map