import type { VariablePlugin } from '@perses-dev/plugin-system';
import type { PrometheusPromQLVariableOptions } from './types';
export declare const PrometheusPromQLVariable: VariablePlugin<PrometheusPromQLVariableOptions>;
//# sourceMappingURL=PrometheusPromQLVariable.d.ts.map