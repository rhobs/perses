import type { VariablePlugin } from '@perses-dev/plugin-system';
import type { PrometheusLabelValuesVariableOptions } from './types';
export declare const PrometheusLabelValuesVariable: VariablePlugin<PrometheusLabelValuesVariableOptions>;
//# sourceMappingURL=PrometheusLabelValuesVariable.d.ts.map