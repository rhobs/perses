import type { VariablePlugin } from '@perses-dev/plugin-system';
import type { PrometheusLabelNamesVariableOptions } from './types';
export declare const PrometheusLabelNamesVariable: VariablePlugin<PrometheusLabelNamesVariableOptions>;
//# sourceMappingURL=PrometheusLabelNamesVariable.d.ts.map