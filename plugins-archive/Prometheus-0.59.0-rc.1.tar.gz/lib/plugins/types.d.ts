import type { QueryParamValues } from '@perses-dev/components';
import type { DatasourceSelectValue } from '@perses-dev/plugin-system';
import type { DurationString, HTTPProxy } from '@perses-dev/spec';
import type { PrometheusDatasourceSelector } from '../model';
export declare const DEFAULT_SCRAPE_INTERVAL: DurationString;
/**
 * Optional section enabling the exemplars feature for this datasource.
 * When enabled, the PrometheusTimeSeriesQuery plugin also queries the
 * `/api/v1/query_exemplars` endpoint and returns exemplar data.
 */
export interface PrometheusExemplarsSpec {
    enable: boolean;
}
export interface PrometheusDatasourceSpec {
    directUrl?: string;
    proxy?: HTTPProxy;
    scrapeInterval?: DurationString;
    queryParams?: QueryParamValues;
    exemplars?: PrometheusExemplarsSpec;
}
export interface PrometheusVariableOptionsBase {
    datasource?: DatasourceSelectValue<PrometheusDatasourceSelector>;
}
export type PrometheusLabelNamesVariableOptions = PrometheusVariableOptionsBase & {
    matchers?: string[];
};
export type PrometheusLabelValuesVariableOptions = PrometheusVariableOptionsBase & {
    labelName: string;
    matchers?: string[];
};
export type PrometheusPromQLVariableOptions = PrometheusVariableOptionsBase & {
    expr: string;
    labelName: string;
};
export interface PrometheusPromQLAnnotationOptions {
    datasource?: DatasourceSelectValue<PrometheusDatasourceSelector>;
    expr: string;
    title?: string;
    legend?: string;
    tags?: string[];
}
//# sourceMappingURL=types.d.ts.map