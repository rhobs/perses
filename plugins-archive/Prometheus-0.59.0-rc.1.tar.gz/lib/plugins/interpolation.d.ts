import type { VariableStateMap } from '@perses-dev/components';
import type { DatasourceStore } from '@perses-dev/plugin-system';
import type { DatasourceSelector, DatasourceSpec } from '@perses-dev/spec';
import type { ClientRequestOptions, PrometheusClient } from '../model';
import type { PrometheusDatasourceSpec } from './types';
export interface ResolvedPrometheusDatasource {
    client: PrometheusClient;
    requestOptions: ClientRequestOptions;
}
export declare function resolvePrometheusDatasource(datasourceStore: DatasourceStore, selector: DatasourceSelector, variableState: VariableStateMap): Promise<ResolvedPrometheusDatasource>;
export declare function interpolateDatasourceProxyParams(datasource: DatasourceSpec<PrometheusDatasourceSpec>, variableState: VariableStateMap): ClientRequestOptions;
/**
 * Interpolates the series selectors of a label names or label values variable into `match[]` values. Selectors that
 * are empty or only whitespace after interpolation, like the one added by "Add Series Selector" before it is filled,
 * are left out: Prometheus rejects an empty `match[]` ("parse error: unexpected end of input"), and sending no
 * `match[]` at all means no filter.
 */
export declare function interpolateMatchers(matchers: string[] | undefined, variableState: VariableStateMap): string[] | undefined;
export declare function getInterpolatedRequestOptions(datasourceStore: DatasourceStore, datasource: DatasourceSelector, variableState: VariableStateMap): Promise<ClientRequestOptions>;
//# sourceMappingURL=interpolation.d.ts.map