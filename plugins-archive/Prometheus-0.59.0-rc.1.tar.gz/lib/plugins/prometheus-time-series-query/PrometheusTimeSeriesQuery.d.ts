import type { TimeSeriesQueryPlugin } from '@perses-dev/plugin-system';
import type { PrometheusTimeSeriesQuerySpec } from './time-series-query-model';
/**
 * The core Prometheus TimeSeriesQuery plugin for Perses.
 */
export declare const PrometheusTimeSeriesQuery: TimeSeriesQueryPlugin<PrometheusTimeSeriesQuerySpec>;
//# sourceMappingURL=PrometheusTimeSeriesQuery.d.ts.map