import type { VariableStateMap } from '@perses-dev/components';
/**
 * Resolves the variables used in the Min Step of a query and converts it to seconds, rounding down.
 * Returns undefined when no Min Step is set, so that the caller can fall back to the scrape interval of the datasource.
 * Throws an error that explains the problem when the Min Step is not a valid duration.
 */
export declare function getMinStepSeconds(minStep: string | undefined, variableState: VariableStateMap): number | undefined;
//# sourceMappingURL=min-step.d.ts.map