import type { TimeSeriesQueryPlugin } from '@perses-dev/plugin-system';
import type { PrometheusTimeSeriesQuerySpec } from './time-series-query-model';
export declare const getTimeSeriesData: TimeSeriesQueryPlugin<PrometheusTimeSeriesQuerySpec>['getTimeSeriesData'];
//# sourceMappingURL=get-time-series-data.d.ts.map