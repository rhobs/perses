import type { DatasourceSelectValue } from '@perses-dev/plugin-system';
import type { DurationString } from '@perses-dev/spec';
import type { PrometheusDatasourceSelector } from '../../model';
/**
 * The spec/options for the PrometheusTimeSeriesQuery plugin.
 */
export interface PrometheusTimeSeriesQuerySpec {
    query: string;
    seriesNameFormat?: string;
    minStep?: DurationString;
    resolution?: number;
    instant?: boolean;
    datasource?: DatasourceSelectValue<PrometheusDatasourceSelector>;
}
//# sourceMappingURL=time-series-query-model.d.ts.map