import type { DatasourcePlugin } from '@perses-dev/plugin-system';
import type { PrometheusClient } from '../model';
import type { PrometheusDatasourceSpec } from './types';
export declare const PrometheusDatasource: DatasourcePlugin<PrometheusDatasourceSpec, PrometheusClient>;
//# sourceMappingURL=prometheus-datasource.d.ts.map