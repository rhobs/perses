import type { DatasourceEditorProps } from '@perses-dev/plugin-system';
import type { ReactElement } from 'react';
import type { PrometheusDatasourceSpec } from './types';
export type PrometheusDatasourceEditorProps = DatasourceEditorProps<PrometheusDatasourceSpec>;
export declare function PrometheusDatasourceEditor(props: PrometheusDatasourceEditorProps): ReactElement;
//# sourceMappingURL=PrometheusDatasourceEditor.d.ts.map