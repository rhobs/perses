import type { VariablePlugin, VariableOption } from '@perses-dev/plugin-system';
type StaticListOption = string | VariableOption;
type StaticListVariableOptions = {
    values: StaticListOption[];
};
export declare const StaticListVariable: VariablePlugin<StaticListVariableOptions>;
export {};
//# sourceMappingURL=variable.d.ts.map