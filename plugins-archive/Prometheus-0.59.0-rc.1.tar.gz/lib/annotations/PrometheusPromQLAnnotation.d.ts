import type { AnnotationPlugin } from '@perses-dev/plugin-system';
import type { PrometheusPromQLAnnotationOptions } from '../plugins';
export declare const PrometheusPromQLAnnotation: AnnotationPlugin<PrometheusPromQLAnnotationOptions>;
//# sourceMappingURL=PrometheusPromQLAnnotation.d.ts.map