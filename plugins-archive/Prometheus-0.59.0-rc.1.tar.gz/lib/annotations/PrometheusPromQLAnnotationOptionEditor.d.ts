import type { DatasourceSelectValue, OptionsEditorProps } from '@perses-dev/plugin-system';
import type { ReactElement } from 'react';
import type { PrometheusDatasourceSelector } from '../model';
export interface PrometheusAnnotationsQuerySpec {
    expr: string;
    datasource?: DatasourceSelectValue<PrometheusDatasourceSelector>;
    title?: string;
    legend?: string;
    tags?: string[];
}
export type PrometheusAnnotationsQueryEditorProps = OptionsEditorProps<PrometheusAnnotationsQuerySpec>;
export declare function PrometheusPromQLAnnotationOptionEditor(props: PrometheusAnnotationsQueryEditorProps): ReactElement;
//# sourceMappingURL=PrometheusPromQLAnnotationOptionEditor.d.ts.map