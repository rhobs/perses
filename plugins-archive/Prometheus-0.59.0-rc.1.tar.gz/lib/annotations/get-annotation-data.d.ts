import type { AnnotationContext } from '@perses-dev/plugin-system';
import type { AnnotationData } from '@perses-dev/spec';
import type { PrometheusPromQLAnnotationOptions } from '../plugins';
export declare const getAnnotationData: (spec: PrometheusPromQLAnnotationOptions, context: AnnotationContext, abortSignal?: AbortSignal) => Promise<AnnotationData[]>;
//# sourceMappingURL=get-annotation-data.d.ts.map