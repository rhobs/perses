import { OptionsEditorProps } from '@perses-dev/plugin-system';
import { FC } from 'react';
import { StatChartOptions } from './stat-chart-model';
export type StatChartValueMappingEditorProps = OptionsEditorProps<StatChartOptions>;
export declare const StatChartValueMappingEditor: FC<StatChartValueMappingEditorProps>;
//# sourceMappingURL=StatChartValueMappingEditor.d.ts.map