import { FC } from 'react';
import { PanelProps } from '@perses-dev/plugin-system';
import { ProfileData } from '@perses-dev/spec';
import { FlameChartOptions } from '../flame-chart-model';
export type FlameChartPanelProps = PanelProps<FlameChartOptions, ProfileData>;
export declare const FlameChartPanel: FC<FlameChartPanelProps>;
//# sourceMappingURL=FlameChartPanel.d.ts.map