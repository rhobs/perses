import { DatasourceSelector } from '@perses-dev/spec';
import { SplunkTimeSeriesResults } from '../../model/splunk-client-types';
export interface SplunkTimeSeriesQuerySpec {
    query: string;
    datasource?: DatasourceSelector;
    earliest?: string;
    latest?: string;
}
export type SplunkTimeSeriesQueryResponse = SplunkTimeSeriesResults;
//# sourceMappingURL=splunk-time-series-query-types.d.ts.map