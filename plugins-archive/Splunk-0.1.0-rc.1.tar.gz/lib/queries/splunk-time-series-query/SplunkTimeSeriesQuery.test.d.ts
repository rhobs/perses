export {};
//# sourceMappingURL=SplunkTimeSeriesQuery.test.d.ts.map