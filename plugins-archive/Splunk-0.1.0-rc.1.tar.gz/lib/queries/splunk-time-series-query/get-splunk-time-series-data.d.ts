import { TimeSeriesQueryPlugin } from '@perses-dev/plugin-system';
import { SplunkTimeSeriesQuerySpec } from './splunk-time-series-query-types';
export declare const getSplunkTimeSeriesData: TimeSeriesQueryPlugin<SplunkTimeSeriesQuerySpec>['getTimeSeriesData'];
//# sourceMappingURL=get-splunk-time-series-data.d.ts.map