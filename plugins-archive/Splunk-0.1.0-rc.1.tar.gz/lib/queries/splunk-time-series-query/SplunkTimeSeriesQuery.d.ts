import { TimeSeriesQueryPlugin } from '@perses-dev/plugin-system';
import { SplunkTimeSeriesQuerySpec } from './splunk-time-series-query-types';
export declare const SplunkTimeSeriesQuery: TimeSeriesQueryPlugin<SplunkTimeSeriesQuerySpec>;
//# sourceMappingURL=SplunkTimeSeriesQuery.d.ts.map