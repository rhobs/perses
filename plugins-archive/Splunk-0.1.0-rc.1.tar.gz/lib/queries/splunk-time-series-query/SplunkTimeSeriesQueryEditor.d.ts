import { OptionsEditorProps } from '@perses-dev/plugin-system';
import { ReactElement } from 'react';
import { SplunkTimeSeriesQuerySpec } from './splunk-time-series-query-types';
type SplunkQueryEditorProps = OptionsEditorProps<SplunkTimeSeriesQuerySpec>;
export declare function SplunkTimeSeriesQueryEditor(props: SplunkQueryEditorProps): ReactElement;
export {};
//# sourceMappingURL=SplunkTimeSeriesQueryEditor.d.ts.map