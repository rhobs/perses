export {};
//# sourceMappingURL=SplunkLogQuery.test.d.ts.map