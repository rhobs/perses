import { SplunkLogQuerySpec } from './splunk-log-query-types';
import { LogQueryPlugin } from './log-query-plugin-interface';
export declare const getSplunkLogData: LogQueryPlugin<SplunkLogQuerySpec>['getLogData'];
//# sourceMappingURL=get-splunk-log-data.d.ts.map