import { SplunkLogQuerySpec } from './splunk-log-query-types';
import { LogQueryPlugin } from './log-query-plugin-interface';
export declare const SplunkLogQuery: LogQueryPlugin<SplunkLogQuerySpec>;
//# sourceMappingURL=SplunkLogQuery.d.ts.map