import { DatasourceSelector } from '@perses-dev/spec';
import { SplunkLogResults } from '../../model/splunk-client-types';
export interface SplunkLogQuerySpec {
    query: string;
    datasource?: DatasourceSelector;
    earliest?: string;
    latest?: string;
    maxResults?: number;
}
export type SplunkLogQueryResponse = SplunkLogResults;
//# sourceMappingURL=splunk-log-query-types.d.ts.map