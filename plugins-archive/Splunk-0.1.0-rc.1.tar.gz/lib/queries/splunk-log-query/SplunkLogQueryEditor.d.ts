import { OptionsEditorProps } from '@perses-dev/plugin-system';
import { ReactElement } from 'react';
import { SplunkLogQuerySpec } from './splunk-log-query-types';
type SplunkLogQueryEditorProps = OptionsEditorProps<SplunkLogQuerySpec>;
export declare function SplunkLogQueryEditor(props: SplunkLogQueryEditorProps): ReactElement;
export {};
//# sourceMappingURL=SplunkLogQueryEditor.d.ts.map