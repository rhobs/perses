export * from './splunk-time-series-query';
export * from './splunk-log-query';
//# sourceMappingURL=index.d.ts.map