export {};
//# sourceMappingURL=SplunkDatasource.test.d.ts.map