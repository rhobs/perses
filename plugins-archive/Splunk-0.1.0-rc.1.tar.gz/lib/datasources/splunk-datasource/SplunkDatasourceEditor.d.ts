import { ReactElement } from 'react';
import { SplunkDatasourceSpec } from './splunk-datasource-types';
export interface SplunkDatasourceEditorProps {
    value: SplunkDatasourceSpec;
    onChange: (next: SplunkDatasourceSpec) => void;
    isReadonly?: boolean;
}
export declare function SplunkDatasourceEditor(props: SplunkDatasourceEditorProps): ReactElement;
//# sourceMappingURL=SplunkDatasourceEditor.d.ts.map