import { DatasourcePlugin } from '@perses-dev/plugin-system';
import { SplunkClient } from '../../model/splunk-client';
import { SplunkDatasourceSpec } from './splunk-datasource-types';
export declare const SplunkDatasource: DatasourcePlugin<SplunkDatasourceSpec, SplunkClient>;
//# sourceMappingURL=SplunkDatasource.d.ts.map