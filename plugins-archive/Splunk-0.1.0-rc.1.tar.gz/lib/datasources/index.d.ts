export * from './splunk-datasource';
//# sourceMappingURL=index.d.ts.map