import { SplunkJobCreateResponse, SplunkJobStatusResponse, SplunkResultsResponse, SplunkEventsResponse, SplunkIndexResponse, SplunkRequestHeaders } from './splunk-client-types';
export interface SplunkJobCreateParams {
    search: string;
    earliest_time?: string;
    latest_time?: string;
    output_mode?: string;
}
export interface SplunkJobResultsParams {
    output_mode?: string;
    count?: number;
    offset?: number;
}
export interface SplunkExportSearchParams {
    search: string;
    earliest_time?: string;
    latest_time?: string;
    output_mode?: string;
}
export interface SplunkApiOptions {
    datasourceUrl: string;
    headers?: SplunkRequestHeaders;
}
export interface SplunkClient {
    options: {
        datasourceUrl: string;
    };
    createJob: (params: SplunkJobCreateParams, headers?: SplunkRequestHeaders) => Promise<SplunkJobCreateResponse>;
    getJobStatus: (jobId: string, headers?: SplunkRequestHeaders) => Promise<SplunkJobStatusResponse>;
    getJobResults: (jobId: string, params?: SplunkJobResultsParams, headers?: SplunkRequestHeaders) => Promise<SplunkResultsResponse>;
    getJobEvents: (jobId: string, params?: SplunkJobResultsParams, headers?: SplunkRequestHeaders) => Promise<SplunkEventsResponse>;
    exportSearch: (params: SplunkExportSearchParams, headers?: SplunkRequestHeaders) => Promise<SplunkResultsResponse>;
    getIndexes: (headers?: SplunkRequestHeaders) => Promise<SplunkIndexResponse>;
}
export declare function createJob(params: SplunkJobCreateParams, options: SplunkApiOptions): Promise<SplunkJobCreateResponse>;
export declare function getJobStatus(jobId: string, options: SplunkApiOptions): Promise<SplunkJobStatusResponse>;
export declare function getJobResults(jobId: string, params: SplunkJobResultsParams | undefined, options: SplunkApiOptions): Promise<SplunkResultsResponse>;
export declare function getJobEvents(jobId: string, params: SplunkJobResultsParams | undefined, options: SplunkApiOptions): Promise<SplunkEventsResponse>;
export declare function exportSearch(params: SplunkExportSearchParams, options: SplunkApiOptions): Promise<SplunkResultsResponse>;
export declare function getIndexes(options: SplunkApiOptions): Promise<SplunkIndexResponse>;
//# sourceMappingURL=splunk-client.d.ts.map