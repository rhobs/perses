export type SplunkRequestHeaders = Record<string, string>;
export interface SplunkJobCreateResponse {
    sid: string;
}
export interface SplunkJobStatusResponse {
    entry: Array<{
        content: {
            dispatchState: string;
            isDone: boolean;
            isFailed: boolean;
            isFinalized: boolean;
            resultCount: number;
            eventCount: number;
        };
    }>;
}
export interface SplunkResult {
    [key: string]: string | number;
}
export interface SplunkResultsResponse {
    results: SplunkResult[];
    preview: boolean;
    init_offset: number;
}
export interface SplunkEventsResponse {
    results: SplunkResult[];
}
export interface SplunkTimeSeriesResults {
    results: Array<{
        _time: string;
        [key: string]: string | number;
    }>;
}
export interface SplunkLogResults {
    results: Array<{
        _time: string;
        _raw: string;
        [key: string]: string | number;
    }>;
}
export interface SplunkIndexResponse {
    entry: Array<{
        name: string;
        content: {
            totalEventCount: number;
            currentDBSizeMB: number;
        };
    }>;
}
//# sourceMappingURL=splunk-client-types.d.ts.map