module: "github.com/perses/perses/cue@v0"
language: {
	version: "v0.17.1"
}
source: {
	kind: "git"
}
deps: {
	"github.com/perses/shared/cue@v0": {
		v:       "v0.55.0-rc.1"
		default: true
	}
	"github.com/perses/spec/cue@v0": {
		v:       "v0.3.0-rc.1"
		default: true
	}
}
