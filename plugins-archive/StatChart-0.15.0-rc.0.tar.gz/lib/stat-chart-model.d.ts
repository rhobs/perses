import type { FontSizeOption, FormatOptions, ThresholdOptions, ValueMapping } from '@perses-dev/components';
import type { CalculationType, OptionsEditorProps } from '@perses-dev/plugin-system';
import type { Definition } from '@perses-dev/spec';
/**
 * The schema for a StatChart panel.
 */
export interface StatChartDefinition extends Definition<StatChartOptions> {
    kind: 'StatChart';
}
export type ColorMode = 'none' | 'value' | 'background_solid';
export type ColorModeLabelItem = {
    id: ColorMode;
    label: string;
};
export declare const COLOR_MODE_LABELS: ColorModeLabelItem[];
export type legendMode = 'auto' | 'on' | 'off';
export type StatChartOrientation = 'auto' | 'horizontal' | 'vertical';
export type ShowLegendLabelItem = {
    id: legendMode;
    label: string;
    description?: string;
};
export declare const SHOW_LEGEND_LABELS: ShowLegendLabelItem[];
export declare const STAT_CHART_ORIENTATION_LABELS: Array<{
    id: StatChartOrientation;
    label: string;
}>;
export interface StatChartOptions {
    calculation: CalculationType;
    format: FormatOptions;
    metricLabel?: string;
    thresholds?: ThresholdOptions;
    sparkline?: StatChartSparklineOptions;
    valueFontSize?: FontSizeOption;
    legendFontSize?: FontSizeOption;
    mappings?: ValueMapping[];
    colorMode?: ColorMode;
    legendMode?: legendMode;
    orientation?: StatChartOrientation;
    seriesColumns?: number;
}
export declare const MAX_SERIES_COLUMNS = 12;
export type SeriesColumnsLabelItem = {
    id: string;
    label: string;
};
export declare const SERIES_COLUMNS_LABELS: SeriesColumnsLabelItem[];
export declare function computeIdealSeriesColumns(seriesCount: number): number;
export declare function resolveAutoOrientationColumnsCount(seriesCount: number, widthBasedColumnCount: number, seriesColumns?: number): number;
export declare function resolveAutoOrientationTileHeight(panelHeight: number, rowCount: number, spacing: number, minTileHeight: number): number;
export declare function resolveSparklineBandHeight(availableHeight: number): number;
export interface StatChartSparklineOptions {
    color?: string;
    width?: number;
}
export type StatChartOptionsEditorProps = OptionsEditorProps<StatChartOptions>;
export declare function createInitialStatChartOptions(): StatChartOptions;
//# sourceMappingURL=stat-chart-model.d.ts.map