import type { PersesChartsTheme } from '@perses-dev/components';
import type { LineSeriesOption } from 'echarts/charts';
import type { StatChartSparklineOptions } from '../stat-chart-model';
export declare function convertSparkline(chartsTheme: PersesChartsTheme, color: string, sparkline?: StatChartSparklineOptions): LineSeriesOption | undefined;
//# sourceMappingURL=data-transform.d.ts.map