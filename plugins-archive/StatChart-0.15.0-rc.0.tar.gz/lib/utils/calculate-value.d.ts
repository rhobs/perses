import type { CalculationType } from '@perses-dev/plugin-system';
import { CalculationsMap } from '@perses-dev/plugin-system';
import type { TimeSeries } from '@perses-dev/spec';
export declare const calculateValue: (calculation: CalculationType, seriesData: TimeSeries) => ReturnType<(typeof CalculationsMap)[CalculationType]>;
//# sourceMappingURL=calculate-value.d.ts.map