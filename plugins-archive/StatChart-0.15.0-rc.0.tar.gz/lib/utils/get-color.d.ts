import type { PersesChartsTheme } from '@perses-dev/components';
import type { StatChartOptions } from '../stat-chart-model';
type StatChartValue = number | string | null;
export declare function getStatChartColor(chartsTheme: PersesChartsTheme, spec?: StatChartOptions, value?: StatChartValue): string;
export {};
//# sourceMappingURL=get-color.d.ts.map