import type { PanelPlugin } from '@perses-dev/plugin-system';
import type { StatChartOptions } from './stat-chart-model';
import type { StatChartPanelProps } from './StatChartPanel';
/**
 * The core StatChart panel plugin for Perses.
 */
export declare const StatChart: PanelPlugin<StatChartOptions, StatChartPanelProps>;
//# sourceMappingURL=StatChart.d.ts.map