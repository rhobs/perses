import type { PanelProps } from '@perses-dev/plugin-system';
import type { TimeSeriesData } from '@perses-dev/spec';
import type { FC } from 'react';
import type { StatChartOptions } from './stat-chart-model';
export type StatChartPanelProps = PanelProps<StatChartOptions, TimeSeriesData>;
export declare const StatChartPanel: FC<StatChartPanelProps>;
//# sourceMappingURL=StatChartPanel.d.ts.map