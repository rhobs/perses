import type { FontSizeOption, FormatOptions, GraphSeries } from '@perses-dev/components';
import type { LineSeriesOption } from 'echarts/charts';
import type { FC } from 'react';
import type { ColorMode } from './stat-chart-model';
export interface StatChartData {
    color: string;
    calculatedValue?: string | number | null;
    seriesData?: GraphSeries;
}
export interface StatChartProps {
    width: number;
    height: number;
    data: StatChartData;
    format?: FormatOptions;
    sparkline?: LineSeriesOption;
    showSeriesName?: boolean;
    valueFontSize?: FontSizeOption;
    legendFontSize?: FontSizeOption;
    colorMode?: ColorMode;
    alignmentText?: string;
    alignmentSeriesName?: string;
    maxValueFontSize?: number;
}
export declare const StatChartBase: FC<StatChartProps>;
//# sourceMappingURL=StatChartBase.d.ts.map