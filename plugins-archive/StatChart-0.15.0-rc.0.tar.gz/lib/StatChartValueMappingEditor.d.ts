import type { OptionsEditorProps } from '@perses-dev/plugin-system';
import type { FC } from 'react';
import type { StatChartOptions } from './stat-chart-model';
export type StatChartValueMappingEditorProps = OptionsEditorProps<StatChartOptions>;
export declare const StatChartValueMappingEditor: FC<StatChartValueMappingEditorProps>;
//# sourceMappingURL=StatChartValueMappingEditor.d.ts.map