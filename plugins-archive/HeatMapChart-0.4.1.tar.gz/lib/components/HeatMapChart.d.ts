import { ReactElement } from 'react';
import { FormatOptions, TimeScale } from '@perses-dev/core';
import { LOG_BASE } from '../heat-map-chart-model';
export type HeatMapData = [number, number, number, number | undefined];
export interface HeatMapDataItem {
    value: HeatMapData;
    label: string;
    itemStyle?: {
        color?: string;
        borderColor?: string;
        borderWidth?: number;
    };
}
export interface HeatMapChartProps {
    width: number;
    height: number;
    data: HeatMapDataItem[];
    xAxisCategories: number[];
    yAxisFormat?: FormatOptions;
    countFormat?: FormatOptions;
    countMin?: number;
    countMax?: number;
    timeScale?: TimeScale;
    showVisualMap?: boolean;
    min?: number;
    max?: number;
    logBase?: LOG_BASE;
}
export declare function HeatMapChart({ width, height, data, xAxisCategories, yAxisFormat, countFormat, countMin, countMax, timeScale, showVisualMap, min, max, logBase, }: HeatMapChartProps): ReactElement | null;
//# sourceMappingURL=HeatMapChart.d.ts.map