export declare function linkToTrace(timeZone: string): string;
export declare function linkToSpan(timeZone: string): string;
//# sourceMappingURL=links.d.ts.map