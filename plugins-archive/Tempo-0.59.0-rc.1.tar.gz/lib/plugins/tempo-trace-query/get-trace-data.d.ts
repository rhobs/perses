import { TraceQueryPlugin } from '@perses-dev/plugin-system';
import { AbsoluteTimeRange } from '@perses-dev/spec';
import { TempoTraceQuerySpec } from '../../model';
export declare function getUnixTimeRange(timeRange: AbsoluteTimeRange): {
    start: number;
    end: number;
};
export declare const getTraceData: TraceQueryPlugin<TempoTraceQuerySpec>['getTraceData'];
//# sourceMappingURL=get-trace-data.d.ts.map