import { HTTPProxy } from '@perses-dev/spec';
export interface TempoDatasourceSpec {
    directUrl?: string;
    proxy?: HTTPProxy;
}
//# sourceMappingURL=tempo-datasource-types.d.ts.map