import { DatasourceClient } from '@perses-dev/plugin-system';
import { RequestHeaders } from '@perses-dev/client';
import { QueryRequestParameters, SearchRequestParameters, SearchTagsRequestParameters, SearchTagsResponse, QueryResponse, SearchResponse, SearchTagValuesRequestParameters, SearchTagValuesResponse } from './api-types';
interface TempoClientOptions {
    datasourceUrl: string;
    headers?: RequestHeaders;
}
export interface TempoClient extends DatasourceClient {
    options: TempoClientOptions;
    query(params: QueryRequestParameters, headers?: RequestHeaders): Promise<QueryResponse>;
    search(params: SearchRequestParameters, headers?: RequestHeaders): Promise<SearchResponse>;
    searchTags(params: SearchTagsRequestParameters, headers?: RequestHeaders): Promise<SearchTagsResponse>;
    searchTagValues(params: SearchTagValuesRequestParameters, headers?: RequestHeaders): Promise<SearchTagValuesResponse>;
}
export interface QueryOptions {
    datasourceUrl: string;
    headers?: RequestHeaders;
}
/**
 * Returns a summary report of traces that satisfy the query.
 */
export declare function search(params: SearchRequestParameters, queryOptions: QueryOptions): Promise<SearchResponse>;
/**
 * Returns an entire trace.
 * Throws an 404 if trace is not found.
 */
export declare function query(params: QueryRequestParameters, queryOptions: QueryOptions): Promise<QueryResponse>;
/**
 * Returns a list of all tag names for a given scope.
 */
export declare function searchTags(params: SearchTagsRequestParameters, queryOptions: QueryOptions): Promise<SearchTagsResponse>;
/**
 * Returns a list of all tag values for a given tag.
 */
export declare function searchTagValues(params: SearchTagValuesRequestParameters, queryOptions: QueryOptions): Promise<SearchTagValuesResponse>;
export {};
//# sourceMappingURL=tempo-client.d.ts.map