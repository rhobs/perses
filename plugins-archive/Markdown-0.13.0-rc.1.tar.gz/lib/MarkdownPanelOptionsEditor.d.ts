import type { OptionsEditorProps } from '@perses-dev/plugin-system';
import type { ReactElement } from 'react';
import type { MarkdownPanelOptions } from './markdown-panel-model';
export type MarkdownPanelOptionsEditorProps = OptionsEditorProps<MarkdownPanelOptions>;
export declare function MarkdownPanelOptionsEditor(props: MarkdownPanelOptionsEditorProps): ReactElement;
//# sourceMappingURL=MarkdownPanelOptionsEditor.d.ts.map