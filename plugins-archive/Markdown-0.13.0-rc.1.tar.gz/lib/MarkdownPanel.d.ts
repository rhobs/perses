import type { PanelProps } from '@perses-dev/plugin-system';
import type { ReactElement } from 'react';
import type { MarkdownPanelOptions } from './markdown-panel-model';
export type MarkdownPanelProps = PanelProps<MarkdownPanelOptions>;
export declare function sanitizeHTML(html: string): string;
export declare function MarkdownPanel(props: MarkdownPanelProps): ReactElement;
//# sourceMappingURL=MarkdownPanel.d.ts.map