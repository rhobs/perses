import { HTTPProxy } from '@perses-dev/spec';
export interface VictoriaLogsDatasourceSpec {
    directUrl?: string;
    proxy?: HTTPProxy;
}
//# sourceMappingURL=types.d.ts.map