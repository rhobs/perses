import { VariableOption } from '@perses-dev/plugin-system';
import { UseQueryResult } from '@tanstack/react-query';
import { AbsoluteTimeRange, DatasourceSelector } from '@perses-dev/spec';
import { StatusError } from '@perses-dev/client';
import { VictoriaLogsFieldItem, VictoriaLogsFieldNamesResponse, VictoriaLogsFieldValuesResponse } from '../model';
export declare const fieldItemsToVariableOptions: (values?: VictoriaLogsFieldItem[]) => VariableOption[];
export declare function getVictoriaLogsTimeRange(timeRange: AbsoluteTimeRange): {
    start: string;
    end: string;
};
export declare function useFieldNames(query: string, datasource: DatasourceSelector): UseQueryResult<VictoriaLogsFieldNamesResponse, StatusError>;
export declare function useFieldValues(field: string, query: string, datasource: DatasourceSelector): UseQueryResult<VictoriaLogsFieldValuesResponse, StatusError>;
//# sourceMappingURL=utils.d.ts.map