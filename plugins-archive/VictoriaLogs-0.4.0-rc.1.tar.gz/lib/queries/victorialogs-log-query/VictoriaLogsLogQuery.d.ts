import { LogQueryPlugin } from '@perses-dev/plugin-system';
import { VictoriaLogsLogQuerySpec } from './types';
export declare const VictoriaLogsLogQuery: LogQueryPlugin<VictoriaLogsLogQuerySpec>;
//# sourceMappingURL=VictoriaLogsLogQuery.d.ts.map