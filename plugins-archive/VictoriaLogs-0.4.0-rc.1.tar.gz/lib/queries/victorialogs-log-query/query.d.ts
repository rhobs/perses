import { LogQueryPlugin } from '@perses-dev/plugin-system';
import { VictoriaLogsLogQuerySpec } from './types';
export declare const getVictoriaLogsLogData: LogQueryPlugin<VictoriaLogsLogQuerySpec>['getLogData'];
//# sourceMappingURL=query.d.ts.map