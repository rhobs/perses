import { DatasourceSelector } from '@perses-dev/spec';
export interface VictoriaLogsLogQuerySpec {
    query: string;
    datasource?: DatasourceSelector;
}
//# sourceMappingURL=types.d.ts.map