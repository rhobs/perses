import { DatasourceSelector } from '@perses-dev/spec';
export interface VictoriaLogsTimeSeriesQuerySpec {
    query: string;
    datasource?: DatasourceSelector;
    step?: string;
}
//# sourceMappingURL=types.d.ts.map