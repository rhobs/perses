// Copyright The Perses Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import type { LabelFilter } from '../utils/types';
import type { PyroscopeDatasourceSelector } from './pyroscope-selectors';
/**
 * The spec/options for the PyroscopeProfileQuery plugin.
 */
export interface PyroscopeProfileQuerySpec {
  datasource?: PyroscopeDatasourceSelector;
  maxNodes?: number;
  profileType: string;
  filters?: LabelFilter[];
  service?: string;
}

/**
 * A Pyroscope profile query needs at least a service and a profile type to be executable.
 * When either is missing, the query is considered incomplete and should not be run.
 */
export function isProfileQueryComplete(
  spec: Partial<Pick<PyroscopeProfileQuerySpec, 'service' | 'profileType'>>,
): boolean {
  return !!spec.service && !!spec.profileType;
}
