// Copyright The Perses Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import type { TraceQueryPlugin } from '@perses-dev/plugin-system';
import { isVariableDatasource, parseVariables } from '@perses-dev/plugin-system';

import type { JaegerTraceQuerySpec } from '../model';
import { getTraceData } from './get-trace-data';
import { JaegerTraceQueryEditor } from './JaegerTraceQueryEditor';

export const JaegerTraceQuery: TraceQueryPlugin<JaegerTraceQuerySpec> = {
  getTraceData,
  OptionsEditorComponent: JaegerTraceQueryEditor,
  createInitialOptions: () => ({
    datasource: undefined,
    traceId: '',
    service: '',
    operation: '',
    spanKind: '',
    tags: '',
    minDuration: '',
    maxDuration: '',
    limit: 20,
  }),
  dependsOn: (spec) => {
    const datasourceVariables = isVariableDatasource(spec.datasource) ? parseVariables(spec.datasource ?? '') : [];
    const fieldVariables = [
      spec.traceId,
      spec.service,
      spec.operation,
      spec.spanKind,
      spec.tags,
      spec.minDuration,
      spec.maxDuration,
    ].flatMap((value) => parseVariables(value ?? ''));

    return {
      variables: [...new Set([...datasourceVariables, ...fieldVariables])],
    };
  },
};
