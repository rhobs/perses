// Copyright The Perses Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import type { VariableStateMap } from '@perses-dev/components';
import { interpolateHeaders, interpolateQueryParams } from '@perses-dev/components';
import type { DatasourceStore } from '@perses-dev/plugin-system';
import type { DatasourceSelector, DatasourceSpec } from '@perses-dev/spec';

import type { ClientRequestOptions, PrometheusClient } from '../model';
import type { PrometheusDatasourceSpec } from './types';

export interface ResolvedPrometheusDatasource {
  client: PrometheusClient;
  requestOptions: ClientRequestOptions;
}

export async function resolvePrometheusDatasource(
  datasourceStore: DatasourceStore,
  selector: DatasourceSelector,
  variableState: VariableStateMap,
): Promise<ResolvedPrometheusDatasource> {
  const [client, datasource] = await Promise.all([
    datasourceStore.getDatasourceClient<PrometheusClient>(selector),
    datasourceStore.getDatasource(selector) as Promise<DatasourceSpec<PrometheusDatasourceSpec>>,
  ]);
  const { headers, queryParams } = interpolateDatasourceProxyParams(datasource, variableState);
  return { client, requestOptions: { headers, queryParams } };
}

export function interpolateDatasourceProxyParams(
  datasource: DatasourceSpec<PrometheusDatasourceSpec>,
  variableState: VariableStateMap,
): ClientRequestOptions {
  const spec = datasource.plugin.spec;
  const rawHeaders = spec.proxy?.spec?.headers;
  const rawQueryParams = spec.queryParams;

  return {
    headers: rawHeaders ? interpolateHeaders(rawHeaders, variableState) : undefined,
    queryParams: rawQueryParams ? interpolateQueryParams(rawQueryParams, variableState) : undefined,
  };
}

export async function getInterpolatedRequestOptions(
  datasourceStore: DatasourceStore,
  datasource: DatasourceSelector,
  variableState: VariableStateMap,
): Promise<ClientRequestOptions> {
  const datasourceSpec = (await datasourceStore.getDatasource(datasource)) as DatasourceSpec<PrometheusDatasourceSpec>;
  return interpolateDatasourceProxyParams(datasourceSpec, variableState);
}
