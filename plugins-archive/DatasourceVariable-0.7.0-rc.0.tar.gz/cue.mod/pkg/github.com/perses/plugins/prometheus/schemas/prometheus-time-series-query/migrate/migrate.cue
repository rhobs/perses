// Copyright The Perses Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package migrate

import "github.com/perses/shared/cue/common"

#target: {
	datasource?: {
		type?: "prometheus"
		uid:   string
	}
	// /!\ Best-effort conversion logic that may wrongly convert not-prometheus queries to PrometheusTimeSeriesQuery:
	// Ideally we should only rely on datasource.type = "prometheus" to identify prometheus queries. But in some cases,
	// this information is not present. Thus, in addition to the check on the optional type above, the below condition
	// relies on the presence of the "expr" field, that likely indicates that this is a prometheus query.
	expr:          string
	legendFormat?: string
	interval?:     string
	instant?:      bool
	...
}

kind: "PrometheusTimeSeriesQuery"
spec: {
	if #target.datasource != _|_ {
		if #target.datasource.uid =~ common.#variableSyntaxRegex {
			datasource: #target.datasource.uid
		}
		if #target.datasource.uid !~ common.#variableSyntaxRegex {
			datasource: {
				kind: "PrometheusDatasource"
				name: #target.datasource.uid
			}
		}
	}
	query:         #target.expr
	#legendFormat: *#target.legendFormat | "__auto"
	if #legendFormat != "__auto" {
		seriesNameFormat: #legendFormat
	}
	if #target.interval != _|_ {
		minStep: #target.interval
	}
	if #target.instant != _|_ {
		instant: #target.instant
	}
}
