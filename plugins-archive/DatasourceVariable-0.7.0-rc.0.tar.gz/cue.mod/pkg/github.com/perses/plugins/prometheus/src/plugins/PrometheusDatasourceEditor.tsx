// Copyright The Perses Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import { Box, FormControlLabel, IconButton, Switch, TextField, Typography } from '@mui/material';
import type { QueryParamValues } from '@perses-dev/components';
import type { DatasourceEditorProps } from '@perses-dev/plugin-system';
import { HTTPSettingsEditor } from '@perses-dev/plugin-system';
import type { DurationString } from '@perses-dev/spec';
import MinusIcon from 'mdi-material-ui/Minus';
import PlusIcon from 'mdi-material-ui/Plus';
import type { ReactElement } from 'react';
import { useRef, useState } from 'react';

import type { PrometheusDatasourceSpec } from './types';
import { DEFAULT_SCRAPE_INTERVAL } from './types';

interface QueryParamEntry {
  // Unique identifier for the entry, added to avoid using array index as key
  id: string;
  key: string;
  value: string;
}

export type PrometheusDatasourceEditorProps = DatasourceEditorProps<PrometheusDatasourceSpec>;

export function PrometheusDatasourceEditor(props: PrometheusDatasourceEditorProps): ReactElement {
  const { value, onChange, isReadonly, testConnection } = props;

  // Counter for generating unique IDs
  const nextIdRef = useRef(0);

  // Use local state to maintain an array of entries during editing, instead of
  // manipulating a map directly which causes weird UX.
  const [entries, setEntries] = useState<QueryParamEntry[]>(() => {
    const queryParams: QueryParamValues = value.queryParams ?? {};
    return Object.entries(queryParams).map(([key, val]) => ({
      id: String(nextIdRef.current++),
      key,
      value: Array.isArray(val) ? val.join(',') : val,
    }));
  });

  // Check for duplicate keys
  const keyMap = new Map<string, number>();
  const duplicateKeys = new Set<string>();
  entries.forEach(({ key }) => {
    if (key !== '') {
      const count = (keyMap.get(key) || 0) + 1;
      keyMap.set(key, count);
      if (count > 1) {
        duplicateKeys.add(key);
      }
    }
  });
  const hasDuplicates = duplicateKeys.size > 0;

  // Convert entries array to object and trigger onChange.
  // Values containing commas are stored as arrays to preserve the round-trip
  // with the load-time join(',') in useState above.
  const syncToParent = (newEntries: QueryParamEntry[]): void => {
    const newParams: Record<string, string | string[]> = {};
    newEntries.forEach(({ key, value }) => {
      if (key !== '') {
        const parts = value.split(',');
        newParams[key] = parts.length > 1 ? parts : value;
      }
    });

    onChange({
      ...value,
      queryParams: Object.keys(newParams).length > 0 ? newParams : undefined,
    });
  };

  const handleQueryParamChange = (id: string, field: 'key' | 'value', newValue: string): void => {
    const newEntries = entries.map((entry) => {
      if (entry.id !== id) return entry;
      return field === 'key' ? { ...entry, key: newValue } : { ...entry, value: newValue };
    });
    setEntries(newEntries);
    syncToParent(newEntries);
  };

  const addQueryParam = (): void => {
    const newEntries = [...entries, { id: String(nextIdRef.current++), key: '', value: '' }];
    setEntries(newEntries);
    syncToParent(newEntries);
  };

  const removeQueryParam = (id: string): void => {
    const newEntries = entries.filter((entry) => entry.id !== id);
    setEntries(newEntries);
    syncToParent(newEntries);
  };

  const initialSpecDirect: PrometheusDatasourceSpec = {
    directUrl: '',
  };

  const initialSpecProxy: PrometheusDatasourceSpec = {
    proxy: {
      kind: 'HTTPProxy',
      spec: {
        allowedEndpoints: [
          // list of standard endpoints suggested by default
          {
            endpointPattern: '/api/v1/labels',
            method: 'POST',
          },
          {
            endpointPattern: '/api/v1/series',
            method: 'POST',
          },
          {
            endpointPattern: '/api/v1/metadata',
            method: 'GET',
          },
          {
            endpointPattern: '/api/v1/query',
            method: 'POST',
          },
          {
            endpointPattern: '/api/v1/query_range',
            method: 'POST',
          },
          {
            endpointPattern: '/api/v1/query_exemplars',
            method: 'GET',
          },
          {
            endpointPattern: '/api/v1/label/([a-zA-Z0-9_-]+)/values',
            method: 'GET',
          },
          {
            endpointPattern: '/api/v1/parse_query',
            method: 'POST',
          },
        ],
        url: '',
      },
    },
  };

  return (
    <>
      <Typography variant="h4" mb={2}>
        General Settings
      </Typography>
      <TextField
        size="small"
        fullWidth
        label="Scrape Interval"
        value={value.scrapeInterval || ''}
        placeholder={`Default: ${DEFAULT_SCRAPE_INTERVAL}`}
        InputProps={{
          readOnly: isReadonly,
        }}
        InputLabelProps={{ shrink: isReadonly ? true : undefined }}
        onChange={(e) => onChange({ ...value, scrapeInterval: e.target.value as DurationString })}
        helperText="Set it to match the typical scrape interval used in your Prometheus instance."
      />
      <Typography variant="h5" mt={2} mb={1}>
        Exemplars
      </Typography>
      <FormControlLabel
        control={
          <Switch
            checked={value.exemplars?.enable ?? false}
            disabled={isReadonly}
            onChange={(e) =>
              onChange({
                ...value,
                exemplars: e.target.checked ? { enable: true } : undefined,
              })
            }
          />
        }
        label="Enable exemplars"
      />
      <HTTPSettingsEditor
        value={value}
        onChange={onChange}
        isReadonly={isReadonly}
        initialSpecDirect={initialSpecDirect}
        initialSpecProxy={initialSpecProxy}
        testConnection={testConnection}
      />
      <Typography variant="h5" mt={2} mb={1}>
        Query Parameters
      </Typography>
      {entries.length > 0 && (
        <>
          {entries.map((entry) => (
            <Box key={entry.id} display="flex" alignItems="center" gap={2} mb={1}>
              <TextField
                size="small"
                label="Key"
                value={entry.key}
                placeholder="Parameter name"
                disabled={isReadonly}
                onChange={(e) => handleQueryParamChange(entry.id, 'key', e.target.value)}
                error={duplicateKeys.has(entry.key)}
                sx={{ minWidth: 150 }}
              />
              <TextField
                size="small"
                label="Value"
                value={entry.value}
                placeholder="Parameter value"
                disabled={isReadonly}
                onChange={(e) => handleQueryParamChange(entry.id, 'value', e.target.value)}
                sx={{ minWidth: 150, flexGrow: 1 }}
              />
              {!isReadonly && (
                <IconButton onClick={() => removeQueryParam(entry.id)}>
                  <MinusIcon />
                </IconButton>
              )}
            </Box>
          ))}
        </>
      )}
      {hasDuplicates && (
        <Typography variant="body2" color="error" mb={1}>
          Duplicate parameter keys detected. Each key must be unique.
        </Typography>
      )}
      {entries.length === 0 && (
        <Typography variant="body2" color="textSecondary">
          No query parameters configured. Use query parameters to pass additional options to Prometheus (e.g.,
          dedup=false for Thanos).
        </Typography>
      )}
      {!isReadonly && (
        <IconButton onClick={addQueryParam}>
          <PlusIcon />
        </IconButton>
      )}
    </>
  );
}
