// Copyright The Perses Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import type { StatusError } from '@perses-dev/client';
import { useDatasourceClient, useTimeRange, useVariableValues, useDatasourceStore } from '@perses-dev/plugin-system';
import type { DatasourceSelector } from '@perses-dev/spec';
import type { UseQueryResult } from '@tanstack/react-query';
import { useQuery } from '@tanstack/react-query';
import { useMemo } from 'react';

import type {
  LabelNamesRequestParameters,
  LabelValuesRequestParameters,
  LabelValuesResponse,
  Metric,
  MetricMetadata,
  MetricMetadataRequestParameters,
  MetricMetadataResponse,
  PrometheusClient,
  SeriesRequestParameters,
  SeriesResponse,
} from '../../model';
import { getInterpolatedRequestOptions } from '../../plugins/interpolation';
import type { LabelFilter, LabelValueCounter } from './types';
import { computeFilterExpr } from './types';

// Retrieve metric metadata from the Prometheus API
export function useMetricMetadata(
  metricName: string,
  datasource: DatasourceSelector,
  enabled?: boolean,
): {
  isLoading: false | true;
  metadata: MetricMetadata | undefined;
  error: StatusError | null;
} {
  const { data: client } = useDatasourceClient<PrometheusClient>(datasource);
  const datasourceStore = useDatasourceStore();
  const variableState = useVariableValues();

  // histograms and summaries timeseries desc are not always added to prefixed timeseries
  const name = metricName.replace(/(_count|_sum|_bucket)$/, '');

  const { data, isLoading, error } = useQuery<MetricMetadataResponse, StatusError>({
    enabled: !!client && enabled,
    queryKey: ['metricMetadata', name], // Not indexed on datasource, assuming a metric metadata should be similar across datasources
    queryFn: async () => {
      const params: MetricMetadataRequestParameters = { metric: name };

      const interpolatedOptions = await getInterpolatedRequestOptions(datasourceStore, datasource, variableState);

      return await client!.metricMetadata(params, interpolatedOptions);
    },
  });

  // Find the first result with help text
  const metadata: MetricMetadata | undefined = useMemo(() => {
    for (const metric of data?.data?.[name] ?? []) {
      if (metric.help.length > 0) {
        return metric;
      }
    }
    return undefined;
  }, [data, name]);

  return { metadata, isLoading, error };
}

export function useLabels(
  filters: LabelFilter[],
  datasource: DatasourceSelector,
): UseQueryResult<LabelValuesResponse, StatusError> {
  const {
    absoluteTimeRange: { start, end },
  } = useTimeRange();
  const { data: client } = useDatasourceClient<PrometheusClient>(datasource);
  const datasourceStore = useDatasourceStore();
  const variableState = useVariableValues();

  return useQuery<LabelValuesResponse, StatusError>({
    enabled: !!client,
    queryKey: ['labels', 'datasource', datasource.name, 'start', start, 'end', end, 'filters', ...filters],
    queryFn: async () => {
      const params: LabelNamesRequestParameters = {
        start: start.valueOf() / 1000,
        end: end.valueOf() / 1000,
      };
      if (filters.length) {
        params['match[]'] = [`{${computeFilterExpr(filters)}}`];
      }

      const interpolatedOptions = await getInterpolatedRequestOptions(datasourceStore, datasource, variableState);

      return await client!.labelNames(params, interpolatedOptions);
    },
  });
}

// Retrieve label values from the Prometheus API for a given label name and filters
export function useLabelValues(
  labelName: string,
  filters: LabelFilter[],
  datasource: DatasourceSelector,
): UseQueryResult<LabelValuesResponse, StatusError> {
  const {
    absoluteTimeRange: { start, end },
  } = useTimeRange();
  const { data: client } = useDatasourceClient<PrometheusClient>(datasource);
  const datasourceStore = useDatasourceStore();
  const variableState = useVariableValues();

  return useQuery<LabelValuesResponse, StatusError>({
    enabled: !!client,
    queryKey: ['labelValues', labelName, 'datasource', datasource.name, 'start', start, 'end', 'filters', ...filters],
    queryFn: async () => {
      const params: LabelValuesRequestParameters = {
        labelName: labelName,
        start: start.valueOf() / 1000,
        end: end.valueOf() / 1000,
      };
      if (filters.length) {
        params['match[]'] = [`{${computeFilterExpr(filters)}}`];
      }

      const interpolatedOptions = await getInterpolatedRequestOptions(datasourceStore, datasource, variableState);

      return await client!.labelValues(params, interpolatedOptions);
    },
  });
}

// Retrieve series from the Prometheus API for a given metric name and filters
// Also computes the number of times a label value appears for the given metric name and filters
export function useSeriesStates(
  metricName: string,
  filters: LabelFilter[],
  datasource: DatasourceSelector,
): {
  series: Metric[] | undefined;
  labelValueCounters: Map<string, Array<{ labelValue: string; counter: number }>>;
  isLoading: boolean;
  isError: boolean;
  error: StatusError | null;
} {
  const {
    absoluteTimeRange: { start, end },
  } = useTimeRange();
  const { data: client } = useDatasourceClient<PrometheusClient>(datasource);
  const datasourceStore = useDatasourceStore();
  const variableState = useVariableValues();

  const {
    data: seriesData,
    isLoading,
    isError,
    error,
  } = useQuery<SeriesResponse, StatusError>({
    enabled: !!client,
    queryKey: ['series', metricName, 'datasource', datasource, 'start', start, 'end', 'filters', ...filters],
    queryFn: async () => {
      const params: SeriesRequestParameters = {
        'match[]': [`{${computeFilterExpr(filters)}}`],
        start: start.valueOf() / 1000,
        end: end.valueOf() / 1000,
      };

      const interpolatedOptions = await getInterpolatedRequestOptions(datasourceStore, datasource, variableState);

      return await client!.series(params, interpolatedOptions);
    },
  });

  const labelValueCounters: Map<string, Array<{ labelValue: string; counter: number }>> = useMemo(() => {
    const result = new Map<string, LabelValueCounter[]>();
    if (seriesData?.data === undefined) {
      return result;
    }

    for (const series of seriesData.data) {
      for (const [label, value] of Object.entries(series)) {
        const labelCounters = result.get(label);
        if (labelCounters === undefined) {
          result.set(label, [{ labelValue: value, counter: 1 }]);
          continue;
        }

        const labelValueCounter = labelCounters.find((counter) => counter.labelValue === value);
        if (labelValueCounter === undefined) {
          labelCounters.push({ labelValue: value, counter: 1 });
        } else {
          labelValueCounter.counter += 1;
        }
      }
    }

    return result;
  }, [seriesData]);

  return { series: seriesData?.data, labelValueCounters, isLoading, isError, error };
}
