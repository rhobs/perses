// Copyright The Perses Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import { Box, Stack, Tab, Tabs, ToggleButton, ToggleButtonGroup } from '@mui/material';
import { Panel } from '@perses-dev/dashboards';
import { useExplorerManagerContext } from '@perses-dev/explore';
import { DataQueriesProvider, MultiQueryEditor, useSuggestedStepMs } from '@perses-dev/plugin-system';
import type { QueryDefinition } from '@perses-dev/spec';
import type { ReactElement } from 'react';
import { useState } from 'react';
import useResizeObserver from 'use-resize-observer';

import { DEFAULT_PROM } from '../model/prometheus-selectors';
import { PrometheusMetricsFinder } from './PrometheusMetricsFinder';
import type { FinderQueryParams } from './PrometheusMetricsFinder/types';

interface MetricsExplorerQueryParams extends FinderQueryParams {
  tab?: string;
  queries?: QueryDefinition[];
}

const PANEL_PREVIEW_HEIGHT = 700;
const FILTERED_QUERY_PLUGINS = ['PrometheusTimeSeriesQuery'];

function TimeSeriesPanel({ queries }: { queries: QueryDefinition[] }): ReactElement {
  const { width, ref: boxRef } = useResizeObserver();
  const height = PANEL_PREVIEW_HEIGHT;
  const [stacked, setStacked] = useState(false);

  const suggestedStepMs = useSuggestedStepMs(width);

  const chartSpec = stacked
    ? { legend: { position: 'bottom', mode: 'list' }, visual: { stack: 'all', areaOpacity: 0.3 } }
    : { legend: { position: 'bottom', mode: 'list' } };

  return (
    <Stack>
      <ToggleButtonGroup
        value={stacked ? 'stacked' : 'unstacked'}
        exclusive
        onChange={(_, value) => setStacked(value === 'stacked')}
        size="small"
        sx={{
          alignSelf: 'flex-end',
          mt: 2,
          backgroundColor: 'background.lighter',
          borderRadius: 1,
          p: 0.5,
          '& .MuiToggleButton-root': {
            border: 'none',
            borderRadius: '4px !important',
            px: 2,
            color: 'text.secondary',
            '&.Mui-selected': {
              backgroundColor: 'background.default',
              color: 'text.primary',
            },
            '&:hover': {
              backgroundColor: 'action.hover',
            },
          },
        }}
      >
        <ToggleButton value="unstacked">Unstacked</ToggleButton>
        <ToggleButton value="stacked">Stacked</ToggleButton>
      </ToggleButtonGroup>
      <Box ref={boxRef} height={height}>
        <DataQueriesProvider definitions={queries} options={{ suggestedStepMs, mode: 'range' }}>
          <Panel
            panelOptions={{
              hideHeader: true,
            }}
            definition={{
              kind: 'Panel',
              spec: {
                queries: queries,
                display: { name: '' },
                plugin: { kind: 'TimeSeriesChart', spec: chartSpec },
              },
            }}
          />
        </DataQueriesProvider>
      </Box>
    </Stack>
  );
}

function MetricDataTable({ queries }: { queries: QueryDefinition[] }): ReactElement {
  const height = PANEL_PREVIEW_HEIGHT;

  return (
    <Box height={height}>
      <DataQueriesProvider definitions={queries} options={{ mode: 'instant' }}>
        <Panel
          panelOptions={{
            hideHeader: true,
          }}
          definition={{
            kind: 'Panel',
            spec: { queries: queries, display: { name: '' }, plugin: { kind: 'TimeSeriesTable', spec: {} } },
          }}
        />
      </DataQueriesProvider>
    </Box>
  );
}

export function PrometheusExplorer(): ReactElement {
  const {
    data: { tab = 'table', queries = [], datasource = DEFAULT_PROM, filters = [], exploredMetric = undefined },
    setData,
  } = useExplorerManagerContext<MetricsExplorerQueryParams>();

  const [queryDefinitions, setQueryDefinitions] = useState<QueryDefinition[]>(queries);

  return (
    <Stack gap={2} sx={{ width: '100%' }}>
      <Tabs
        value={tab}
        onChange={(_, state) => setData({ tab: state, queries })}
        variant="scrollable"
        sx={{ borderBottom: 1, borderColor: 'divider' }}
      >
        <Tab value="table" label="Table" />
        <Tab value="graph" label="Graph" />
        <Tab value="finder" label="Finder" />
      </Tabs>
      <Stack gap={1}>
        {tab === 'table' && (
          <Stack>
            <MultiQueryEditor
              queryTypes={['TimeSeriesQuery']}
              onChange={(state) => setQueryDefinitions(state)}
              queries={queryDefinitions}
              onQueryRun={() => setData({ tab, queries: queryDefinitions })}
              filteredQueryPlugins={FILTERED_QUERY_PLUGINS}
            />
            <MetricDataTable queries={queries} />
          </Stack>
        )}
        {tab === 'graph' && (
          <Stack>
            <MultiQueryEditor
              queryTypes={['TimeSeriesQuery']}
              onChange={(state) => setQueryDefinitions(state)}
              queries={queryDefinitions}
              onQueryRun={() => setData({ tab, queries: queryDefinitions })}
              filteredQueryPlugins={FILTERED_QUERY_PLUGINS}
            />
            <TimeSeriesPanel queries={queries} />
          </Stack>
        )}
        {tab === 'finder' && (
          <Stack>
            <PrometheusMetricsFinder
              onChange={(state) => setData({ tab, ...state })}
              value={{ datasource, filters, exploredMetric }}
            />
          </Stack>
        )}
      </Stack>
    </Stack>
  );
}
