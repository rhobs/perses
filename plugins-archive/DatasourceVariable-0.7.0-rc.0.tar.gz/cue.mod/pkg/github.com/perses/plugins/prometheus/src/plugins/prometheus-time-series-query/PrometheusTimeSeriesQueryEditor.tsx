// Copyright The Perses Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import { Button, ButtonGroup, FormControl, Stack, TextField } from '@mui/material';
import { useId } from '@perses-dev/components';
import { PanelEditorContext } from '@perses-dev/dashboards';
import type { DatasourceSelectProps } from '@perses-dev/plugin-system';
import {
  DatasourceSelect,
  replaceVariables,
  useAllVariableValues,
  useDatasource,
  useDatasourceClient,
  useDatasourceSelectValueToSelector,
  useSuggestedStepMs,
  useTimeRange,
} from '@perses-dev/plugin-system';
import { produce } from 'immer';
import type { ReactElement } from 'react';
import { useContext, useMemo } from 'react';

import { PromQLEditor } from '../../components';
import type { DurationString, PrometheusClient, PrometheusDatasourceSelector } from '../../model';
import {
  DEFAULT_PROM,
  getDurationStringSeconds,
  getPrometheusTimeRange,
  getRangeStep,
  isDefaultPromSelector,
  isPrometheusDatasourceSelector,
  PROM_DATASOURCE_KIND,
} from '../../model';
import type { PrometheusDatasourceSpec } from '../types';
import { DEFAULT_SCRAPE_INTERVAL } from '../types';
import type { PrometheusTimeSeriesQueryEditorProps } from './query-editor-model';
import { useQueryState, useFormatState, useMinStepState, useInstantState } from './query-editor-model';
/**
 * The options editor component for editing a PrometheusTimeSeriesQuery's spec.
 */
export function PrometheusTimeSeriesQueryEditor(props: PrometheusTimeSeriesQueryEditorProps): ReactElement {
  const {
    onChange,
    value,
    value: { query, datasource },
    isReadonly,
  } = props;

  const datasourceSelectValue = datasource ?? DEFAULT_PROM;

  const datasourceSelectLabelID = useId('prom-datasource-label'); // for panels with multiple queries, this component is rendered multiple times on the same page

  const selectedDatasource = useDatasourceSelectValueToSelector(
    datasourceSelectValue,
    PROM_DATASOURCE_KIND,
  ) as PrometheusDatasourceSelector;

  const { data: client } = useDatasourceClient<PrometheusClient>(selectedDatasource);
  const promURL = client?.options.datasourceUrl;
  const { data: datasourceResource } = useDatasource(selectedDatasource);

  const { handleQueryChange, handleQueryBlur } = useQueryState(props);
  const { format, handleFormatChange, handleFormatBlur } = useFormatState(props);
  const { minStep, handleMinStepChange, handleMinStepBlur } = useMinStepState(props);
  const { instant, handleInstantChange } = useInstantState(props);
  const minStepPlaceholder =
    minStep ??
    (datasourceResource && (datasourceResource.plugin.spec as PrometheusDatasourceSpec).scrapeInterval) ??
    DEFAULT_SCRAPE_INTERVAL;

  const handleDatasourceChange: DatasourceSelectProps['onChange'] = (next) => {
    if (isPrometheusDatasourceSelector(next)) {
      /* Good to know: The usage of onchange here causes an immediate spec update which eventually updates the panel
         This was probably intentional to allow for quick switching between datasources.
         Could have been triggered only with Run Query button as well.
      */
      onChange(
        produce(value, (draft) => {
          // If they're using the default, just omit the datasource prop (i.e. set to undefined)
          const nextDatasource = isDefaultPromSelector(next) ? undefined : next;
          draft.datasource = nextDatasource;
        }),
      );
      return;
    }

    throw new Error('Got unexpected non-Prometheus datasource selector');
  };

  const variableState = useAllVariableValues();
  const { absoluteTimeRange } = useTimeRange();
  const panelEditorContext = useContext(PanelEditorContext);
  const suggestedStepMs = useSuggestedStepMs(panelEditorContext?.preview.previewPanelWidth);

  const minStepMs = useMemo(() => {
    /* Try catch is necessary, because when the minStep value is being typed, it will be valid when the duration unit is added. Example: 2m = 2 + m */
    try {
      const durationsSeconds = getDurationStringSeconds(
        replaceVariables(minStepPlaceholder, variableState) as DurationString,
      );
      return durationsSeconds !== undefined ? durationsSeconds * 1000 : undefined;
    } catch {
      return undefined;
    }
  }, [variableState, minStepPlaceholder]);

  const intervalMs = useMemo(() => {
    const minStepSeconds = (minStepMs ?? 0) / 1000;
    return getRangeStep(getPrometheusTimeRange(absoluteTimeRange), minStepSeconds, undefined, suggestedStepMs) * 1000;
  }, [absoluteTimeRange, minStepMs, suggestedStepMs]);

  const treeViewMetadata = useMemo(() => {
    return minStepMs && intervalMs
      ? {
          minStepMs,
          intervalMs,
        }
      : undefined;
  }, [minStepMs, intervalMs]);

  return (
    <Stack spacing={2}>
      <FormControl margin="dense" fullWidth={false}>
        <DatasourceSelect
          datasourcePluginKind={PROM_DATASOURCE_KIND}
          value={datasourceSelectValue}
          onChange={handleDatasourceChange}
          labelId={datasourceSelectLabelID}
          label="Prometheus Datasource"
          notched
          readOnly={isReadonly}
        />
      </FormControl>
      <PromQLEditor
        completeConfig={{ remote: { url: promURL } }}
        value={query} // here we are passing `value.query` and not `query` from useQueryState in order to get updates only on onBlur events
        datasource={selectedDatasource}
        onChange={handleQueryChange}
        onBlur={handleQueryBlur}
        isReadOnly={isReadonly}
        treeViewMetadata={treeViewMetadata}
      />
      <Stack direction="row" spacing={2} alignItems="flex-start">
        <TextField
          fullWidth
          label="Legend"
          placeholder="Example: '{{instance}}' will generate series names like 'webserver-123', 'webserver-456'..."
          helperText="Text to be displayed in the legend and the tooltip. Use {{label_name}} to interpolate label values."
          value={format ?? ''}
          onChange={(e) => handleFormatChange(e.target.value)}
          onBlur={handleFormatBlur}
          slotProps={{
            inputLabel: { shrink: isReadonly ? true : undefined },
            input: { readOnly: isReadonly },
          }}
        />
        <TextField
          label="Min Step"
          placeholder={minStepPlaceholder}
          helperText="Lower bound for the step. If not provided, the scrape interval of the datasource is used."
          value={minStep ?? ''}
          onChange={(e) => handleMinStepChange(e.target.value ? (e.target.value as DurationString) : undefined)}
          onBlur={handleMinStepBlur}
          disabled={instant === true}
          sx={{ width: '250px' }}
          slotProps={{
            inputLabel: { shrink: isReadonly ? true : undefined },
            input: { readOnly: isReadonly },
          }}
        />
        <ButtonGroup disabled={isReadonly} sx={{ '& .MuiButton-root': { px: 2, py: 2 } }}>
          <Button variant={instant === false ? 'contained' : 'outlined'} onClick={() => handleInstantChange(false)}>
            Range
          </Button>
          <Button variant={instant === true ? 'contained' : 'outlined'} onClick={() => handleInstantChange(true)}>
            Instant
          </Button>
          <Button
            variant={instant === undefined ? 'contained' : 'outlined'}
            onClick={() => handleInstantChange(undefined)}
          >
            Auto
          </Button>
        </ButtonGroup>
      </Stack>
    </Stack>
  );
}
