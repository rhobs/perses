// Copyright The Perses Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import { Box, Stack } from '@mui/material';
import { ErrorAlert, ErrorBoundary, LoadingOverlay, NoDataOverlay, useTimeZone } from '@perses-dev/components';
import { Panel } from '@perses-dev/dashboards';
import { useExplorerManagerContext } from '@perses-dev/explore';
import { DataQueriesProvider, MultiQueryEditor, useDataQueries } from '@perses-dev/plugin-system';
import type { QueryDefinition } from '@perses-dev/spec';
import { isValidTraceId } from '@perses-dev/spec';
import type { ReactElement } from 'react';
import { useState } from 'react';

import { ClosableAlert } from '../components/ClosableAlert';
import type { TempoTraceQuerySpec } from '../model';
import { linkToSpan, linkToTrace } from './links';

interface TracesExplorerQueryParams {
  queries?: QueryDefinition[];
  spanId?: string;
}

interface SearchResultsPanelProps {
  queries: QueryDefinition[];
}

function SearchResultsPanel({ queries }: SearchResultsPanelProps): ReactElement {
  const { timeZone } = useTimeZone();
  const { isFetching, isLoading, queryResults } = useDataQueries('TraceQuery');

  // no query executed, show empty panel
  if (queryResults.length === 0) {
    return <></>;
  }

  if (isLoading || isFetching) {
    return <LoadingOverlay />;
  }

  const queryError = queryResults.find((d) => d.error);
  if (queryError) {
    throw queryError.error;
  }

  const tracesFound = queryResults.some((traceData) => (traceData.data?.searchResult ?? []).length > 0);
  if (!tracesFound) {
    return <NoDataOverlay resource="traces" />;
  }

  const hasMoreResults = queryResults.some((traceData) => traceData.data?.metadata?.hasMoreResults);

  return (
    <Stack sx={{ height: '100%' }} gap={2}>
      {hasMoreResults && (
        <ClosableAlert severity="warning">
          Not all matching traces are currently visible. Increase the display limit to view more.
        </ClosableAlert>
      )}
      <Box sx={{ height: '35%', flexShrink: 0 }}>
        <Panel
          panelOptions={{
            hideHeader: true,
          }}
          definition={{
            kind: 'Panel',
            spec: {
              queries,
              display: { name: '' },
              plugin: {
                kind: 'ScatterChart',
                spec: {
                  link: linkToTrace(timeZone),
                },
              },
            },
          }}
        />
      </Box>
      <Panel
        sx={{ flexGrow: 1 }}
        panelOptions={{
          hideHeader: true,
        }}
        definition={{
          kind: 'Panel',
          spec: {
            queries,
            display: { name: '' },
            plugin: {
              kind: 'TraceTable',
              spec: {
                links: {
                  trace: linkToTrace(timeZone),
                },
              },
            },
          },
        }}
      />
    </Stack>
  );
}

interface TracingGanttChartPanelProps {
  queries: QueryDefinition[];
  selectedSpanId?: string;
}

function TracingGanttChartPanel(props: TracingGanttChartPanelProps): ReactElement {
  const { queries, selectedSpanId } = props;
  const { timeZone } = useTimeZone();
  const firstQuery = (queries[0]?.spec.plugin.spec as TempoTraceQuerySpec | undefined)?.query;

  return (
    <Panel
      panelOptions={{ showIcons: 'always' }}
      definition={{
        kind: 'Panel',
        spec: {
          queries,
          display: { name: `Trace ${firstQuery}` },
          plugin: {
            kind: 'TracingGanttChart',
            spec: {
              links: {
                trace: linkToTrace(timeZone),
                span: linkToSpan(timeZone),
              },
              selectedSpanId,
            },
          },
        },
      }}
    />
  );
}

export function TempoExplorer(): ReactElement {
  const {
    data: { queries = [], spanId: selectedSpanId },
    setData,
  } = useExplorerManagerContext<TracesExplorerQueryParams>();

  const [queryDefinitions, setQueryDefinitions] = useState<QueryDefinition[]>(queries);

  const firstQuery = (queries[0]?.spec.plugin.spec as TempoTraceQuerySpec | undefined)?.query;
  const isSingleTrace = isValidTraceId(firstQuery ?? '');

  return (
    <Stack gap={2} sx={{ width: '100%' }}>
      <MultiQueryEditor
        queryTypes={['TraceQuery']}
        onChange={(state) => setQueryDefinitions(state)}
        queries={queryDefinitions}
        onQueryRun={() => setData({ queries: queryDefinitions })}
      />

      <ErrorBoundary FallbackComponent={ErrorAlert} resetKeys={[queries]}>
        <DataQueriesProvider definitions={queries}>
          <Box height={700}>
            {isSingleTrace ? (
              <TracingGanttChartPanel queries={queries} selectedSpanId={selectedSpanId} />
            ) : (
              <SearchResultsPanel queries={queries} />
            )}
          </Box>
        </DataQueriesProvider>
      </ErrorBoundary>
    </Stack>
  );
}
