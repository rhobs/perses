// Copyright The Perses Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import type { TraceQueryContext } from '@perses-dev/plugin-system';
import type { DatasourceSpec } from '@perses-dev/spec';
import type { Mock } from 'vitest';

import { MOCK_SEARCH_RESPONSE_VPARQUET4, MOCK_TRACE_DATA_SEARCHRESULT, MOCK_TRACE_RESPONSE_SMALL } from '../test';
import { TempoDatasource } from './tempo-datasource';
import type { TempoDatasourceSpec } from './tempo-datasource-types';
import { TempoTraceQuery } from './tempo-trace-query/TempoTraceQuery';

vi.mock('echarts/core');

const datasource: TempoDatasourceSpec = {
  directUrl: '/test',
};

const tempoStubClient = TempoDatasource.createClient(datasource, {});
tempoStubClient.query = vi.fn(async () => MOCK_TRACE_RESPONSE_SMALL);
tempoStubClient.search = vi.fn(async () => MOCK_SEARCH_RESPONSE_VPARQUET4);

const getDatasourceClient: Mock = vi.fn(() => {
  return tempoStubClient;
});

const getDatasource: Mock = vi.fn((): DatasourceSpec<TempoDatasourceSpec> => {
  return {
    default: false,
    plugin: {
      kind: 'TempoDatasource',
      spec: datasource,
    },
  };
});

const stubTempoContext: TraceQueryContext = {
  variableState: {},
  datasourceStore: {
    getDatasource: getDatasource,
    getDatasourceClient: getDatasourceClient,
    listDatasourceSelectItems: vi.fn(),

    getLocalDatasources: vi.fn(),
    setLocalDatasources: vi.fn(),
    getSavedDatasources: vi.fn(),
    setSavedDatasources: vi.fn(),
  },
  absoluteTimeRange: {
    start: new Date('2023-12-16T21:57:48.057Z'), // last 1 hour
    end: new Date('2023-12-16T22:57:48.057Z'),
  },
};

describe('TempoTraceQuery', () => {
  it('should return trace query results', async () => {
    const results = await TempoTraceQuery.getTraceData(
      {
        query: 'duration > 900ms',
      },
      stubTempoContext,
    );
    expect(results).toEqual(MOCK_TRACE_DATA_SEARCHRESULT);
  });

  it('should convert base64-encoded trace IDs and span IDs in the response to hex format', async () => {
    const results = await TempoTraceQuery.getTraceData({ query: 'fbd37845209d43cdccd418dc5f9ff021' }, stubTempoContext);
    expect(results.trace?.resourceSpans[0]?.scopeSpans[0]?.spans[1]?.traceId).toEqual(
      'fbd37845209d43cdccd418dc5f9ff021',
    );
    expect(results.trace?.resourceSpans[0]?.scopeSpans[0]?.spans[1]?.spanId).toEqual('8467bca11377c166');
    expect(results.trace?.resourceSpans[0]?.scopeSpans[0]?.spans[1]?.parentSpanId).toEqual('9c22eb77cb5c14c7');
  });
});
