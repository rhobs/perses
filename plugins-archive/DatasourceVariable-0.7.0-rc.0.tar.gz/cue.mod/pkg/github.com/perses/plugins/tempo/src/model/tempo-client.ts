// Copyright The Perses Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import type { RequestHeaders } from '@perses-dev/client';
import { fetchJson, UserFriendlyError } from '@perses-dev/client';
import type { DatasourceClient } from '@perses-dev/plugin-system';

import type {
  QueryRequestParameters,
  SearchRequestParameters,
  SearchTagsRequestParameters,
  SearchTagsResponse,
  QueryResponse,
  SearchResponse,
  SearchTagValuesRequestParameters,
  SearchTagValuesResponse,
} from './api-types';

interface TempoClientOptions {
  datasourceUrl: string;
  headers?: RequestHeaders;
}

export interface TempoClient extends DatasourceClient {
  options: TempoClientOptions;
  // https://grafana.com/docs/tempo/latest/api_docs/
  query(params: QueryRequestParameters, headers?: RequestHeaders): Promise<QueryResponse>;
  search(params: SearchRequestParameters, headers?: RequestHeaders): Promise<SearchResponse>;
  searchTags(params: SearchTagsRequestParameters, headers?: RequestHeaders): Promise<SearchTagsResponse>;
  searchTagValues(params: SearchTagValuesRequestParameters, headers?: RequestHeaders): Promise<SearchTagValuesResponse>;
}

export interface QueryOptions {
  datasourceUrl: string;
  headers?: RequestHeaders;
}

async function fetchWithGet<TRequest extends RequestParams<TRequest>, TResponse>(
  apiURI: string,
  params: TRequest,
  queryOptions: QueryOptions,
): Promise<TResponse> {
  const { datasourceUrl, headers = {} } = queryOptions;

  let url = `${datasourceUrl}${apiURI}`;
  const urlParams = buildSearchParams(params).toString();
  if (urlParams !== '') {
    url += '?' + urlParams;
  }
  const init = {
    method: 'GET',
    headers: {
      Accept: 'application/json',
      ...headers,
    },
  };

  try {
    return await fetchJson<TResponse>(url, init);
  } catch (e) {
    // fetchJson() puts the entire response body in the error message,
    // which can be a full HTML page. Replace with a short status message.
    if (e instanceof Error && 'status' in e && /^\s*</.test(e.message)) {
      throw new UserFriendlyError(`Invalid response from server`, e.status as number);
    }
    throw e;
  }
}

type RequestParams<T> = { [K in keyof T]: string | number };

function buildSearchParams<T>(params: RequestParams<T>): URLSearchParams {
  const urlSearchParams = new URLSearchParams();
  for (const key in params) {
    const value = params[key];
    switch (typeof value) {
      case 'string':
        urlSearchParams.append(key, value);
        break;

      case 'number':
        urlSearchParams.append(key, value.toString());
        break;
    }
  }
  return urlSearchParams;
}

/**
 * Returns a summary report of traces that satisfy the query.
 */
export function search(params: SearchRequestParameters, queryOptions: QueryOptions): Promise<SearchResponse> {
  return fetchWithGet<SearchRequestParameters, SearchResponse>('/api/search', params, queryOptions);
}

/**
 * Returns an entire trace.
 * Throws an 404 if trace is not found.
 */
export async function query(params: QueryRequestParameters, queryOptions: QueryOptions): Promise<QueryResponse> {
  const response = await fetchWithGet<Record<string, never>, QueryResponse>(
    `/api/v2/traces/${encodeURIComponent(params.traceId)}`,
    {},
    queryOptions,
  );

  // /api/v2/traces returns an empty trace if trace is not found.
  // Throw a 404 instead.
  if (!response.trace?.resourceSpans) {
    throw new UserFriendlyError('Trace not found', 404);
  }
  return response;
}

/**
 * Returns a list of all tag names for a given scope.
 */
export function searchTags(
  params: SearchTagsRequestParameters,
  queryOptions: QueryOptions,
): Promise<SearchTagsResponse> {
  return fetchWithGet<SearchTagsRequestParameters, SearchTagsResponse>('/api/v2/search/tags', params, queryOptions);
}

/**
 * Returns a list of all tag values for a given tag.
 */
export function searchTagValues(
  params: SearchTagValuesRequestParameters,
  queryOptions: QueryOptions,
): Promise<SearchTagValuesResponse> {
  const { tag, ...rest } = params;
  return fetchWithGet<Omit<SearchTagValuesRequestParameters, 'tag'>, SearchTagValuesResponse>(
    `/api/v2/search/tag/${encodeURIComponent(tag)}/values`,
    rest,
    queryOptions,
  );
}
