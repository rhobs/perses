// Copyright The Perses Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import type * as otlpcommonv1 from '@perses-dev/spec/dist/dashboard/query-type/otlp/common/v1/common';
import type * as otlptracev1 from '@perses-dev/spec/dist/dashboard/query-type/otlp/trace/v1/trace';

/**
 * Request parameters of Tempo HTTP API endpoint GET /api/search
 * https://grafana.com/docs/tempo/latest/api_docs/#search
 */
export interface SearchRequestParameters {
  q: string;
  start?: number;
  end?: number;
  /** max number of search results, default: 20 */
  limit?: number;
  /** max number of matching spans per trace in search result, default: 3 */
  spss?: number;
}

export const DEFAULT_SEARCH_LIMIT = 20;

/**
 * Response of Tempo HTTP API endpoint GET /api/search
 * https://grafana.com/docs/tempo/latest/api_docs/#search
 */
export interface SearchResponse {
  traces: TraceSearchResponse[];
}

export interface TraceSearchResponse {
  traceID: string;
  rootServiceName: string;
  rootTraceName: string;
  startTimeUnixNano: string;
  /** unset if duration is less than 1ms */
  durationMs?: number;
  /** @deprecated spanSet is deprecated in favor of spanSets */
  spanSet?: {
    spans: SpanSearchResponse[];
    matched: number;
  };
  spanSets?: Array<{
    spans: SpanSearchResponse[];
    matched: number;
  }>;
  /** ServiceStats are only available in Tempo vParquet4+ blocks */
  serviceStats?: Record<string, ServiceStats>;
}

export interface SpanSearchResponse {
  spanID: string;
  name?: string;
  startTimeUnixNano: string;
  durationNanos: string;
  attributes?: otlpcommonv1.KeyValue[];
}

export interface ServiceStats {
  spanCount: number;
  /** number of spans with errors, unset if zero */
  errorCount?: number;
}

/**
 * Request parameters of Tempo HTTP API endpoint GET /api/v2/traces/<traceID>
 * https://grafana.com/docs/tempo/latest/api_docs/#query-v2
 */
export interface QueryRequestParameters {
  traceId: string;
}

/**
 * Response of Tempo HTTP API endpoint GET /api/v2/traces/<traceID>
 * https://github.com/grafana/tempo/blob/v2.10.7/pkg/tempopb/tempo.pb.go#L260
 */
export interface QueryResponse {
  trace: otlptracev1.TracesData;
  status?: 'PARTIAL' | 'COMPLETE';
  message?: string;
}

/**
 * Request parameters of Tempo HTTP API endpoint GET /api/v2/search/tags
 * https://grafana.com/docs/tempo/latest/api_docs/#search-tags-v2
 */
export interface SearchTagsRequestParameters {
  scope?: 'resource' | 'span' | 'intrinsic';
  q?: string;
  start?: number;
  end?: number;
  limit?: number;
  maxStaleValues?: number;
}

/**
 * Response of Tempo HTTP API endpoint GET /api/v2/search/tags
 * https://grafana.com/docs/tempo/latest/api_docs/#search-tags-v2
 */
export interface SearchTagsResponse {
  scopes: SearchTagsScope[];
}

export interface SearchTagsScope {
  name: 'resource' | 'span' | 'intrinsic';
  tags: string[];
}

/**
 * Request parameters of Tempo HTTP API endpoint GET /api/v2/search/tag/<tag>/values
 * https://grafana.com/docs/tempo/latest/api_docs/#search-tag-values-v2
 */
export interface SearchTagValuesRequestParameters {
  tag: string;
  q?: string;
  start?: number;
  end?: number;
  limit?: number;
  maxStaleValues?: number;
}

/**
 * Response of Tempo HTTP API endpoint GET /api/v2/search/tag/<tag>/values
 * https://grafana.com/docs/tempo/latest/api_docs/#search-tag-values-v2
 */
export interface SearchTagValuesResponse {
  tagValues: SearchTagValue[];
}

export interface SearchTagValue {
  type: string;
  /** The tag value. Empty strings are omitted (i.e. undefined) in the response. */
  value?: string;
}
