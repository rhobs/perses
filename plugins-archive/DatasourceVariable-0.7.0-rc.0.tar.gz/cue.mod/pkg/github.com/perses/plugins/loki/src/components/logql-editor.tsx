// Copyright The Perses Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import { useTheme } from '@mui/material';
import type { ReactCodeMirrorProps } from '@uiw/react-codemirror';
import CodeMirror, { EditorView } from '@uiw/react-codemirror';
import type { ReactElement } from 'react';
import { useMemo } from 'react';

import type { CompletionConfig } from './logql-extension';
import { LogQLExtension } from './logql-extension';

export type LogQLEditorProps = Omit<ReactCodeMirrorProps, 'theme' | 'extensions'> & {
  completionConfig?: CompletionConfig;
};

export function LogQLEditor(props: LogQLEditorProps): ReactElement {
  const { completionConfig, ...codemirrorProps } = props;
  const theme = useTheme();
  const isDarkMode = theme.palette.mode === 'dark';

  const logqlExtension = useMemo(() => {
    return LogQLExtension(completionConfig);
  }, [completionConfig]);

  const codemirrorTheme = useMemo(() => {
    const borderColor = theme.palette.mode === 'light' ? 'rgba(0, 0, 0, 0.23)' : 'rgba(255, 255, 255, 0.23)';

    return EditorView.theme({
      '&': {
        backgroundColor: 'transparent !important', // required for dark mode
        border: `1px solid ${borderColor}`,
        borderRadius: `${theme.shape.borderRadius}px`,
      },
      '&.cm-focused.cm-editor': {
        outline: 'none',
      },
      '.cm-content': {
        padding: '8px',
      },
    });
  }, [theme]);

  return (
    <CodeMirror
      {...codemirrorProps}
      theme={isDarkMode ? 'dark' : 'light'}
      basicSetup={{
        lineNumbers: false,
        highlightActiveLine: false,
        highlightActiveLineGutter: false,
        foldGutter: false,
        syntaxHighlighting: true,
      }}
      extensions={[EditorView.lineWrapping, logqlExtension, codemirrorTheme]}
      placeholder='Example: {job="my-service"} |= "error"'
    />
  );
}
