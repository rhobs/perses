// Copyright The Perses Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import type { VariablePlugin } from '@perses-dev/plugin-system';
import {
  replaceVariables,
  parseVariables,
  datasourceSelectValueToSelector,
  isVariableDatasource,
} from '@perses-dev/plugin-system';

import type { LokiClient } from '../model';
import { DEFAULT_LOKI, getLokiTimeRange, LOKI_DATASOURCE_KIND } from '../model';
import { stringArrayToVariableOptions, LokiLabelNamesVariableEditor } from './loki-variables';
import type { LokiLabelNamesVariableOptions } from './types';

export const LokiLabelNamesVariable: VariablePlugin<LokiLabelNamesVariableOptions> = {
  getVariableOptions: async (spec, ctx) => {
    const datasourceSelector =
      datasourceSelectValueToSelector(
        spec.datasource ?? DEFAULT_LOKI,
        ctx.variables,
        await ctx.datasourceStore.listDatasourceSelectItems(LOKI_DATASOURCE_KIND),
      ) ?? DEFAULT_LOKI;
    const client: LokiClient = await ctx.datasourceStore.getDatasourceClient(datasourceSelector);
    const query = spec.matchers ? replaceVariables(spec.matchers[0] ?? '', ctx.variables) || undefined : undefined;
    const timeRange = getLokiTimeRange(ctx.timeRange);
    const { data: options } = await client.labels({ start: timeRange.start, end: timeRange.end, query });
    return { data: stringArrayToVariableOptions(options) };
  },
  dependsOn: (spec) => {
    const matcherVariables = spec.matchers?.flatMap((m) => parseVariables(m)) || [];
    const datasourceVariables =
      spec.datasource && isVariableDatasource(spec.datasource) ? parseVariables(spec.datasource) : [];
    return { variables: [...matcherVariables, ...datasourceVariables] };
  },
  OptionsEditorComponent: LokiLabelNamesVariableEditor,
  createInitialOptions: () => ({}),
};
