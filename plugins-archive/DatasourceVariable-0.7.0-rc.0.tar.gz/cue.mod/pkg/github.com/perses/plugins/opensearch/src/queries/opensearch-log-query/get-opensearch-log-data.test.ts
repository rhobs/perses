// Copyright The Perses Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import type { LogQueryContext } from '@perses-dev/plugin-system';
import type { Mock } from 'vitest';

import { OpenSearchDatasource } from '../../datasources/opensearch-datasource';
import type { OpenSearchDatasourceSpec } from '../../datasources/opensearch-datasource/opensearch-datasource-types';
import type { OpenSearchPPLResponse } from '../../model/opensearch-client-types';
import { buildBoundedPPL, convertPPLToLogs, parseTimestamp } from './get-opensearch-log-data';
import { OpenSearchLogQuery } from './OpenSearchLogQuery';

const datasource: OpenSearchDatasourceSpec = {
  directUrl: '/test',
};

const stubClient = OpenSearchDatasource.createClient(datasource, {});

stubClient.ppl = vi.fn(async () => {
  const response: OpenSearchPPLResponse = {
    schema: [
      { name: '@timestamp', type: 'timestamp' },
      { name: 'message', type: 'text' },
      { name: 'level', type: 'keyword' },
    ],
    datarows: [
      ['2025-01-01T00:00:00.000Z', 'Error processing request', 'error'],
      ['2025-01-01T00:00:01.000Z', 'Retrying', 'warn'],
    ],
    total: 2,
    size: 2,
  };
  return response;
});

const getDatasourceClient: Mock = vi.fn(() => stubClient);

function createStubContext(): LogQueryContext {
  return {
    datasourceStore: {
      getDatasource: vi.fn(),
      getDatasourceClient,
      listDatasourceSelectItems: vi.fn(),
      getLocalDatasources: vi.fn(),
      setLocalDatasources: vi.fn(),
      getSavedDatasources: vi.fn(),
      setSavedDatasources: vi.fn(),
    },
    timeRange: {
      start: new Date('2025-01-01T00:00:00.000Z'),
      end: new Date('2025-01-01T01:00:00.000Z'),
    },
    variableState: {},
    refreshKey: '',
  };
}

describe('OpenSearchLogQuery', () => {
  afterEach(() => {
    (stubClient.ppl as Mock).mockClear();
  });

  it('creates initial options with empty query', () => {
    expect(OpenSearchLogQuery.createInitialOptions()).toEqual({ query: '' });
  });

  it('resolves variable dependencies from query and index', () => {
    if (!OpenSearchLogQuery.dependsOn) throw new Error('dependsOn is not defined');
    const { variables } = OpenSearchLogQuery.dependsOn(
      {
        query: 'source=$index | where service="$service" and level="$level"',
        index: '$index',
      },
      createStubContext(),
    );
    expect(variables?.toSorted()).toEqual(['index', 'level', 'service']);
  });

  it('returns empty log data for an empty query without calling the client', async () => {
    const result = await OpenSearchLogQuery.getLogData({ query: '' }, createStubContext());
    expect(result.logs.entries).toEqual([]);
    expect(result.logs.totalCount).toBe(0);
    expect(stubClient.ppl).not.toHaveBeenCalled();
  });

  it('treats a whitespace-only query as empty and does not call the client', async () => {
    const result = await OpenSearchLogQuery.getLogData({ query: '   ' }, createStubContext());
    expect(result.logs.entries).toEqual([]);
    expect(result.logs.totalCount).toBe(0);
    expect(stubClient.ppl).not.toHaveBeenCalled();
  });

  it('reports traceId in dependsOn when query references $traceId', () => {
    if (!OpenSearchLogQuery.dependsOn) throw new Error('dependsOn is not defined');
    const { variables } = OpenSearchLogQuery.dependsOn(
      { query: "source=logs-* | where traceId='$traceId'" },
      createStubContext(),
    );
    expect(variables).toContain('traceId');
  });

  it('passes timestampField + messageField through to the bounder and mapper', async () => {
    const pplMock = stubClient.ppl as Mock;
    pplMock.mockImplementationOnce(async () => ({
      schema: [
        { name: 'time', type: 'timestamp' },
        { name: 'body', type: 'text' },
      ],
      datarows: [['2025-01-01T00:00:30.000Z', 'OTel-style row']],
    }));

    const result = await OpenSearchLogQuery.getLogData(
      {
        query: 'source=otel-logs-* | head 1',
        timestampField: 'time',
        messageField: 'body',
      },
      createStubContext(),
    );

    const sentQuery = pplMock.mock.calls[0]?.[0]?.query as string;
    expect(sentQuery).toContain('`time` >=');
    expect(result.logs.entries[0]?.line).toBe('OTel-style row');
  });

  it('substitutes a $traceId variable into the PPL before sending', async () => {
    const pplMock = stubClient.ppl as Mock;
    pplMock.mockImplementationOnce(async () => ({ schema: [], datarows: [] }));

    await OpenSearchLogQuery.getLogData(
      { query: "source=logs-* | where traceId='$traceId'" },
      {
        ...createStubContext(),
        variableState: {
          traceId: { value: 'abc123', loading: false },
        } as unknown as LogQueryContext['variableState'],
      },
    );

    const sentQuery = pplMock.mock.calls[0]?.[0]?.query as string;
    expect(sentQuery).toContain("where traceId='abc123'");
  });

  it('executes a PPL query and maps rows to log entries', async () => {
    const result = await OpenSearchLogQuery.getLogData(
      { query: 'source=logs-* | where level="error"' },
      createStubContext(),
    );

    expect(stubClient.ppl).toHaveBeenCalledTimes(1);
    expect(result.logs.totalCount).toBe(2);
    expect(result.logs.entries[0]).toEqual({
      timestamp: new Date('2025-01-01T00:00:00.000Z').getTime() / 1000,
      line: 'Error processing request',
      labels: { level: 'error' },
    });
    expect(result.metadata?.executedQueryString).toContain('where level="error"');
  });
});

describe('buildBoundedPPL', () => {
  const start = new Date('2025-01-01T00:00:00.000Z');
  const end = new Date('2025-01-01T01:00:00.000Z');

  it('injects the time-range filter immediately after the source clause', () => {
    const q = buildBoundedPPL('source=logs-* | where level="error"', start, end);
    expect(q).toBe(
      "source=logs-* | where `@timestamp` >= '2025-01-01T00:00:00.000Z' and `@timestamp` <= '2025-01-01T01:00:00.000Z' | where level=\"error\"",
    );
  });

  it('prepends source=<index> when the user query does not declare one', () => {
    const q = buildBoundedPPL('where level="error"', start, end, { index: 'logs-*' });
    expect(q).toBe(
      "source=logs-* | where `@timestamp` >= '2025-01-01T00:00:00.000Z' and `@timestamp` <= '2025-01-01T01:00:00.000Z' | where level=\"error\"",
    );
  });

  it('leaves the user source clause alone when already present and ignores the spec.index hint', () => {
    const q = buildBoundedPPL('source=other-* | head 10', start, end, { index: 'logs-*' });
    expect(q).toBe(
      "source=other-* | where `@timestamp` >= '2025-01-01T00:00:00.000Z' and `@timestamp` <= '2025-01-01T01:00:00.000Z' | head 10",
    );
  });

  it('uses a custom timestamp field name in the injected where clause', () => {
    const q = buildBoundedPPL('source=logs-* | head 10', start, end, { timestampField: 'time' });
    expect(q).toBe(
      "source=logs-* | where `time` >= '2025-01-01T00:00:00.000Z' and `time` <= '2025-01-01T01:00:00.000Z' | head 10",
    );
  });

  it('escapes backticks in a user-supplied timestamp field to prevent breaking out of the identifier', () => {
    const q = buildBoundedPPL('source=logs-* | head 10', start, end, { timestampField: '`inject` x' });
    // each backtick is doubled so the value stays a single backtick-quoted identifier
    const quoted = '```inject`` x`';
    expect(q).toBe(
      `source=logs-* | where ${quoted} >= '2025-01-01T00:00:00.000Z' and ${quoted} <= '2025-01-01T01:00:00.000Z' | head 10`,
    );
  });

  it('runs the bound BEFORE a stats command (otherwise @timestamp is gone)', () => {
    const q = buildBoundedPPL('source=logs-* | stats count() by service', start, end);
    expect(q).toBe(
      "source=logs-* | where `@timestamp` >= '2025-01-01T00:00:00.000Z' and `@timestamp` <= '2025-01-01T01:00:00.000Z' | stats count() by service",
    );
  });

  it('runs the bound BEFORE a fields command that excludes @timestamp', () => {
    const q = buildBoundedPPL('source=logs-* | fields service, body', start, end);
    expect(q).toBe(
      "source=logs-* | where `@timestamp` >= '2025-01-01T00:00:00.000Z' and `@timestamp` <= '2025-01-01T01:00:00.000Z' | fields service, body",
    );
  });

  it('runs the bound BEFORE a top command (which collapses to top-N rows without @timestamp)', () => {
    const q = buildBoundedPPL('source=logs-* | top 3 service', start, end);
    expect(q).toBe(
      "source=logs-* | where `@timestamp` >= '2025-01-01T00:00:00.000Z' and `@timestamp` <= '2025-01-01T01:00:00.000Z' | top 3 service",
    );
  });

  it('appends a single where pipe when the user query has no other pipes', () => {
    const q = buildBoundedPPL('source=logs-*', start, end);
    expect(q).toBe(
      "source=logs-* | where `@timestamp` >= '2025-01-01T00:00:00.000Z' and `@timestamp` <= '2025-01-01T01:00:00.000Z'",
    );
  });

  it('preserves a comma-separated multi-source clause', () => {
    const q = buildBoundedPPL('source=logs-2026.04,logs-2026.05 | head 10', start, end);
    expect(q.startsWith('source=logs-2026.04,logs-2026.05 | where `@timestamp`')).toBe(true);
    expect(q).toContain('| head 10');
  });

  it("preserves the optional 'search' keyword in front of source=", () => {
    const q = buildBoundedPPL('search source=logs-* | head 10', start, end);
    expect(q.startsWith('search source=logs-* | where `@timestamp`')).toBe(true);
    expect(q).toContain('| head 10');
  });

  it('preserves whitespace around the source equals sign', () => {
    const q = buildBoundedPPL('source = logs-* | head 10', start, end);
    expect(q.startsWith('source = logs-* | where `@timestamp`')).toBe(true);
    expect(q).toContain('| head 10');
  });

  it('keeps the user time filter intact when one is already present (PPL ANDs them, both run before stats)', () => {
    const q = buildBoundedPPL(
      "source=logs-* | where `@timestamp` >= '2024-12-31T00:00:00Z' | stats count() by service",
      start,
      end,
    );
    expect(q).toBe(
      "source=logs-* | where `@timestamp` >= '2025-01-01T00:00:00.000Z' and `@timestamp` <= '2025-01-01T01:00:00.000Z' | where `@timestamp` >= '2024-12-31T00:00:00Z' | stats count() by service",
    );
  });

  it('skips the time-range filter when disableTimeFilter is true', () => {
    const q = buildBoundedPPL('source=logs-* | where level="error"', start, end, { disableTimeFilter: true });
    expect(q).toBe('source=logs-* | where level="error"');
  });

  it('still applies the source=<index> prefix when disableTimeFilter is true', () => {
    const q = buildBoundedPPL('where level="error"', start, end, { index: 'logs-*', disableTimeFilter: true });
    expect(q).toBe('source=logs-* | where level="error"');
  });

  it('preserves wildcards and multi-index commas in a sanitized index prefix', () => {
    const q = buildBoundedPPL('head 10', start, end, { index: 'logs-2026.*,otel-*', disableTimeFilter: true });
    expect(q).toBe('source=logs-2026.*,otel-* | head 10');
  });

  it('strips pipes/backticks/quotes from the index so it cannot inject an extra PPL stage', () => {
    const q = buildBoundedPPL('head 10', start, end, { index: 'logs-* | delete `x`', disableTimeFilter: true });
    // whitespace, pipe, backticks and quotes removed → the value stays a single source clause
    expect(q).toBe('source=logs-*deletex | head 10');
    expect(q).not.toContain('| delete');
  });

  it('does not emit a dangling pipe when the query is just a source clause with a trailing pipe', () => {
    const q = buildBoundedPPL('source=logs-* |', start, end);
    expect(q).toBe(
      "source=logs-* | where `@timestamp` >= '2025-01-01T00:00:00.000Z' and `@timestamp` <= '2025-01-01T01:00:00.000Z'",
    );
    expect(q.trimEnd().endsWith('|')).toBe(false);
  });
});

describe('parseTimestamp', () => {
  // 2025-01-01T00:00:00Z expressed in each epoch unit; all normalize to seconds.
  const seconds = 1735689600;

  it('passes through seconds unchanged', () => {
    expect(parseTimestamp(seconds)).toBe(seconds);
  });

  it('converts milliseconds to seconds', () => {
    expect(parseTimestamp(seconds * 1e3)).toBe(seconds);
  });

  it('converts microseconds to seconds', () => {
    expect(parseTimestamp(seconds * 1e6)).toBe(seconds);
  });

  it('converts nanoseconds to seconds (does not land far in the future)', () => {
    expect(parseTimestamp(seconds * 1e9)).toBe(seconds);
  });

  // A ns epoch (~1.7e18) is past Number.MAX_SAFE_INTEGER, so a well-behaved API sends
  // it as a numeric string. We still only emit seconds, so the sub-second remainder is
  // expected to drop — what matters is that the magnitude is right (not year ~57000).
  it('handles numeric-string epochs that overflow JS safe integers', () => {
    expect(Math.floor(parseTimestamp('1735689600123456789'))).toBe(seconds); // nanoseconds
    expect(parseTimestamp(String(seconds * 1e6))).toBe(seconds); // microseconds
    expect(parseTimestamp(String(seconds * 1e3))).toBe(seconds); // milliseconds
    expect(parseTimestamp(String(seconds))).toBe(seconds); // seconds
  });

  it('parses ISO-8601 string timestamps to seconds', () => {
    expect(parseTimestamp('2025-01-01T00:00:00.000Z')).toBe(seconds);
  });

  // OpenSearch PPL returns timestamp fields as space-separated UTC strings without a
  // zone designator; these must be read as UTC (not the browser's local time).
  it('treats OpenSearch zoneless "YYYY-MM-DD HH:MM:SS" strings as UTC', () => {
    expect(parseTimestamp('2025-01-01 00:00:00')).toBe(seconds);
    expect(parseTimestamp('2025-01-01 00:00:00.000')).toBe(seconds);
    // same instant expressed with an explicit zone must resolve identically
    expect(parseTimestamp('2025-01-01 00:00:00')).toBe(parseTimestamp('2025-01-01T00:00:00Z'));
  });

  it('returns 0 for null, undefined, and unparseable values', () => {
    expect(parseTimestamp(null)).toBe(0);
    expect(parseTimestamp(undefined)).toBe(0);
    expect(parseTimestamp('not-a-date')).toBe(0);
  });
});

describe('convertPPLToLogs', () => {
  it('maps @timestamp and message fields and collects remaining fields as labels', () => {
    const logs = convertPPLToLogs({
      schema: [
        { name: '@timestamp', type: 'timestamp' },
        { name: 'message', type: 'text' },
        { name: 'service', type: 'keyword' },
      ],
      datarows: [['2025-01-01T00:00:00.000Z', 'hello', 'api']],
    });
    expect(logs.entries).toHaveLength(1);
    expect(logs.entries[0]?.line).toBe('hello');
    expect(logs.entries[0]?.labels).toEqual({ service: 'api' });
  });

  it('parses numeric epoch-millis timestamps into seconds', () => {
    const logs = convertPPLToLogs({
      schema: [
        { name: '@timestamp', type: 'long' },
        { name: 'message', type: 'text' },
      ],
      datarows: [[1735689600000, 'hello']],
    });
    expect(logs.entries[0]?.timestamp).toBe(1735689600);
  });

  it('falls back to a JSON dump of the row when no message field is present', () => {
    const logs = convertPPLToLogs({
      schema: [
        { name: '@timestamp', type: 'timestamp' },
        { name: 'event', type: 'text' },
      ],
      datarows: [['2025-01-01T00:00:00.000Z', 'started']],
    });
    expect(logs.entries[0]?.line).toContain('"event":"started"');
  });

  it('handles empty datarows', () => {
    const logs = convertPPLToLogs({ schema: [], datarows: [] });
    expect(logs).toEqual({ entries: [], totalCount: 0 });
  });

  it('honors explicit timestampField and messageField overrides', () => {
    const logs = convertPPLToLogs(
      {
        schema: [
          { name: 'time', type: 'timestamp' },
          { name: 'body', type: 'text' },
          { name: 'message', type: 'text' },
        ],
        datarows: [['2025-01-01T00:00:00.000Z', 'OTel body wins', 'noise']],
      },
      { timestampField: 'time', messageField: 'body' },
    );
    expect(logs.entries[0]?.line).toBe('OTel body wins');
    expect(logs.entries[0]?.labels).toEqual({ message: 'noise' });
    expect(logs.entries[0]?.timestamp).toBe(new Date('2025-01-01T00:00:00.000Z').getTime() / 1000);
  });

  it('falls back to defaults when the override field is not in the schema', () => {
    const logs = convertPPLToLogs(
      {
        schema: [
          { name: '@timestamp', type: 'timestamp' },
          { name: 'message', type: 'text' },
        ],
        datarows: [['2025-01-01T00:00:00.000Z', 'hello']],
      },
      { timestampField: 'nope', messageField: 'also-missing' },
    );
    expect(logs.entries[0]?.line).toBe('hello');
  });

  it('puts trace_id columns into labels for trace pivot', () => {
    const logs = convertPPLToLogs({
      schema: [
        { name: '@timestamp', type: 'timestamp' },
        { name: 'message', type: 'text' },
        { name: 'traceId', type: 'keyword' },
      ],
      datarows: [['2025-01-01T00:00:00.000Z', 'hello', 'abc123']],
    });
    expect(logs.entries[0]?.labels.traceId).toBe('abc123');
  });
});
