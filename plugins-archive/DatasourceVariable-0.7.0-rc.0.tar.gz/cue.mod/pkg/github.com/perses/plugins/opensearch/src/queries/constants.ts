// Copyright The Perses Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

export const DATASOURCE_KIND = 'OpenSearchDatasource';
export const DEFAULT_DATASOURCE = { kind: DATASOURCE_KIND };

// Default field names inside OpenSearch log documents. OpenSearch doesn't enforce a schema,
// so these are used as reasonable fallbacks when mapping rows to log entries.
export const DEFAULT_TIMESTAMP_FIELDS = ['@timestamp', 'timestamp', 'time'];
export const DEFAULT_MESSAGE_FIELDS = ['message', 'log', 'body'];

// OpenSearch PPL reference documentation.
export const PPL_DOCS_URL = 'https://opensearch.org/docs/latest/search-plugins/sql/ppl/index/';

// A handful of copy-pasteable PPL examples shown in the editor's "Query Examples" disclosure.
export const PPL_QUERY_EXAMPLES = `source=logs-* | where level="error" | head 20
source=logs-* | fields @timestamp, service, message | head 50
source=logs-* | stats count() by service
source=logs-* | where traceId='$traceId'`;
