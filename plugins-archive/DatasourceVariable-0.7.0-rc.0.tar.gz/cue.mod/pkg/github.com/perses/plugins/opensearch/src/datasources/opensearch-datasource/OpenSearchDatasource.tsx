// Copyright The Perses Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import type { DatasourcePlugin } from '@perses-dev/plugin-system';

import type { OpenSearchClient } from '../../model/opensearch-client';
import { ppl } from '../../model/opensearch-client';
import type { OpenSearchDatasourceSpec } from './opensearch-datasource-types';
import { OpenSearchDatasourceEditor } from './OpenSearchDatasourceEditor';

const createClient: DatasourcePlugin<OpenSearchDatasourceSpec, OpenSearchClient>['createClient'] = (spec, options) => {
  const { directUrl, proxy } = spec;
  const { proxyUrl } = options;

  const datasourceUrl = directUrl ?? proxyUrl;
  if (datasourceUrl === undefined) {
    throw new Error('No URL specified for OpenSearch client. You can use directUrl in the spec to configure it.');
  }

  const specHeaders = proxy?.spec.headers;

  return {
    options: {
      datasourceUrl,
    },
    ppl: (params, headers, signal) => ppl(params, { datasourceUrl, headers: headers ?? specHeaders }, signal),
  };
};

export const OpenSearchDatasource: DatasourcePlugin<OpenSearchDatasourceSpec, OpenSearchClient> = {
  createClient,
  OptionsEditorComponent: OpenSearchDatasourceEditor,
  createInitialOptions: () => ({ directUrl: '' }),
  healthCheckPath: '/_cluster/health',
};
