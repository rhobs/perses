import { ReactElement } from 'react';
import { Labels } from '@perses-dev/spec';
interface SeriesNameProps {
    name: string;
    labels?: Labels;
    formattedName?: string;
    isFormatted?: boolean;
}
export declare function SeriesName({ name, labels, formattedName, isFormatted }: SeriesNameProps): ReactElement;
export {};
//# sourceMappingURL=SeriesName.d.ts.map