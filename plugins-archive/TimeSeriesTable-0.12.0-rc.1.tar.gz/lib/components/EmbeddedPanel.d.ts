import { PanelData } from '@perses-dev/plugin-system';
import { ReactElement } from 'react';
import { QueryDataType, UnknownSpec } from '@perses-dev/spec';
interface EmbeddedPanelProps {
    kind: string;
    spec: UnknownSpec;
    queryResults: Array<PanelData<QueryDataType>>;
}
export declare function EmbeddedPanel({ kind, spec, queryResults }: EmbeddedPanelProps): ReactElement;
export {};
//# sourceMappingURL=EmbeddedPanel.d.ts.map