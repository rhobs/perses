import { DatasourceSelector } from '@perses-dev/spec';
import { LokiQueryRangeMatrixResponse, LokiQueryResponse } from '../../model/loki-client-types';
export interface LokiTimeSeriesQuerySpec {
    query: string;
    datasource?: DatasourceSelector;
    step?: string;
}
export type LokiTimeSeriesQueryResponse = LokiQueryRangeMatrixResponse | LokiQueryResponse;
//# sourceMappingURL=loki-time-series-query-types.d.ts.map