import { LogQueryPlugin } from '@perses-dev/plugin-system';
import { LokiLogQuerySpec } from './loki-log-query-types';
export declare const getLokiLogData: LogQueryPlugin<LokiLogQuerySpec>['getLogData'];
//# sourceMappingURL=get-loki-log-data.d.ts.map