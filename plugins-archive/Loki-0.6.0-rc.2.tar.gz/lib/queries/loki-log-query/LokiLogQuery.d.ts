import { LogQueryPlugin } from '@perses-dev/plugin-system';
import { LokiLogQuerySpec } from './loki-log-query-types';
export declare const LokiLogQuery: LogQueryPlugin<LokiLogQuerySpec>;
//# sourceMappingURL=LokiLogQuery.d.ts.map