import { DatasourceSelector } from '@perses-dev/spec';
import { LokiQueryRangeStreamsResponse } from '../../model/loki-client-types';
export interface LokiLogQuerySpec {
    query: string;
    datasource?: DatasourceSelector;
    direction?: 'backward' | 'forward';
}
export type LokiLogQueryResponse = LokiQueryRangeStreamsResponse;
//# sourceMappingURL=loki-log-query-types.d.ts.map