import { VariablePlugin } from '@perses-dev/plugin-system';
import { LokiLogQLVariableOptions } from './types';
export declare const LokiLogQLVariable: VariablePlugin<LokiLogQLVariableOptions>;
//# sourceMappingURL=LokiLogQLVariable.d.ts.map