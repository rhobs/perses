import { DatasourceSelectValue } from '@perses-dev/plugin-system';
import { LokiDatasourceSelector } from '../model/loki-selectors';
export interface LokiVariableOptionsBase {
    datasource?: DatasourceSelectValue<LokiDatasourceSelector>;
}
export type LokiLabelNamesVariableOptions = LokiVariableOptionsBase & {
    matchers?: string[];
};
export type LokiLabelValuesVariableOptions = LokiVariableOptionsBase & {
    labelName: string;
    matchers?: string[];
};
export type LokiLogQLVariableOptions = LokiVariableOptionsBase & {
    expr: string;
    labelName: string;
};
//# sourceMappingURL=types.d.ts.map