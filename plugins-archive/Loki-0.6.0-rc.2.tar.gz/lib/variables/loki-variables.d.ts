import { OptionsEditorProps, VariableOption } from '@perses-dev/plugin-system';
import { ReactElement } from 'react';
import { LokiStreamResult } from '../model';
import { LokiLabelNamesVariableOptions, LokiLabelValuesVariableOptions, LokiLogQLVariableOptions } from './types';
export declare function LokiLabelValuesVariableEditor(props: OptionsEditorProps<LokiLabelValuesVariableOptions>): ReactElement;
export declare function LokiLabelNamesVariableEditor(props: OptionsEditorProps<LokiLabelNamesVariableOptions>): ReactElement;
export declare function LokiLogQLVariableEditor(props: OptionsEditorProps<LokiLogQLVariableOptions>): ReactElement;
export declare function capturingMetric(results: Array<{
    metric: Record<string, string>;
}>, labelName: string): string[];
export declare function capturingStreams(results: LokiStreamResult[], labelName: string): string[];
export declare const stringArrayToVariableOptions: (values?: string[]) => VariableOption[];
//# sourceMappingURL=loki-variables.d.ts.map