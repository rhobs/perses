import { VariablePlugin } from '@perses-dev/plugin-system';
import { LokiLabelNamesVariableOptions } from './types';
export declare const LokiLabelNamesVariable: VariablePlugin<LokiLabelNamesVariableOptions>;
//# sourceMappingURL=LokiLabelNamesVariable.d.ts.map