import { VariablePlugin } from '@perses-dev/plugin-system';
import { LokiLabelValuesVariableOptions } from './types';
export declare const LokiLabelValuesVariable: VariablePlugin<LokiLabelValuesVariableOptions>;
//# sourceMappingURL=LokiLabelValuesVariable.d.ts.map