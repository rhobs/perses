import { HTTPProxy } from '@perses-dev/spec';
export interface LokiDatasourceSpec {
    directUrl?: string;
    proxy?: HTTPProxy;
}
//# sourceMappingURL=loki-datasource-types.d.ts.map