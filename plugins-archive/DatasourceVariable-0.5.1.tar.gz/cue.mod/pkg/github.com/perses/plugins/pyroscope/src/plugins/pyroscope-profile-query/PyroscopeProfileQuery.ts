// Copyright The Perses Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import { LabelFilter } from '../../utils/types';
import { getProfileData } from './get-profile-data';
import { PyroscopeProfileQueryEditor } from './PyroscopeProfileQueryEditor';

export const PyroscopeProfileQuery = {
  getProfileData,
  OptionsEditorComponent: PyroscopeProfileQueryEditor,
  createInitialOptions: (): {
    maxNodes: number;
    datasource?: string;
    service: string;
    profileType: string;
    filters: LabelFilter[];
  } => ({
    maxNodes: 0,
    datasource: undefined,
    service: '',
    profileType: '',
    filters: [{ labelName: '', labelValue: '', operator: '=' }],
  }),
};
