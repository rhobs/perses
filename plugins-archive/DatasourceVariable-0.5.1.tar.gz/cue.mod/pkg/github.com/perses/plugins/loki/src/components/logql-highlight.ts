// Copyright The Perses Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import { styleTags, tags } from '@lezer/highlight';

export const logqlHighlight = styleTags({
  LineComment: tags.comment,
  'Identifier StreamSelector': tags.labelName,
  'LabelName LabelMatcher': tags.labelName,
  String: tags.string,
  'Number Float Duration': tags.number,
  'LogRangeAggregation VectorAggregation': tags.function(tags.keyword),
  'And Or Unless': tags.logicOperator,
  'Eq Neq Re Nre Gt Lt Gte Lte': tags.compareOperator,
  'Add Sub Mul Div Mod Pow': tags.arithmeticOperator,
  Pipe: tags.operator,
  'By Without': tags.keyword,
  '( )': tags.paren,
  '[ ]': tags.squareBracket,
  '{ }': tags.brace,
  '⚠': tags.invalid,
});
