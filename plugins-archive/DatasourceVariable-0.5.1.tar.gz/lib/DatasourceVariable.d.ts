import { OptionsEditorProps, VariablePlugin } from '@perses-dev/plugin-system';
import { ReactElement } from 'react';
type StaticListVariableOptions = {
    datasourcePluginKind: string;
};
export declare const DatasourceVariableOptionEditor: (props: OptionsEditorProps<StaticListVariableOptions>) => ReactElement;
export declare const DatasourceVariable: VariablePlugin<StaticListVariableOptions>;
export {};
//# sourceMappingURL=DatasourceVariable.d.ts.map