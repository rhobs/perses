import type { LogQueryPlugin } from '@perses-dev/plugin-system';
import type { LokiLogQuerySpec } from './loki-log-query-types';
export declare const LokiLogQuery: LogQueryPlugin<LokiLogQuerySpec>;
//# sourceMappingURL=LokiLogQuery.d.ts.map