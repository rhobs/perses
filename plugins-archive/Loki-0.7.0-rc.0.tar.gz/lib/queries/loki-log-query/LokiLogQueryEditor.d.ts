import type { OptionsEditorProps } from '@perses-dev/plugin-system';
import type { ReactElement } from 'react';
import type { LokiLogQuerySpec } from './loki-log-query-types';
type LokiQueryEditorProps = OptionsEditorProps<LokiLogQuerySpec>;
export declare function LokiLogQueryEditor(props: LokiQueryEditorProps): ReactElement;
export {};
//# sourceMappingURL=LokiLogQueryEditor.d.ts.map