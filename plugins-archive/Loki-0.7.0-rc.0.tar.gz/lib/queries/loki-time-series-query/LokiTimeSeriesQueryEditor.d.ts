import type { OptionsEditorProps } from '@perses-dev/plugin-system';
import type { ReactElement } from 'react';
import type { LokiTimeSeriesQuerySpec } from './loki-time-series-query-types';
type LokiQueryEditorProps = OptionsEditorProps<LokiTimeSeriesQuerySpec>;
export declare function LokiQueryEditor(props: LokiQueryEditorProps): ReactElement;
export {};
//# sourceMappingURL=LokiTimeSeriesQueryEditor.d.ts.map