import type { TimeSeriesQueryPlugin } from '@perses-dev/plugin-system';
import type { LokiTimeSeriesQuerySpec } from './loki-time-series-query-types';
export declare const LokiTimeSeriesQuery: TimeSeriesQueryPlugin<LokiTimeSeriesQuerySpec>;
//# sourceMappingURL=LokiTimeSeriesQuery.d.ts.map