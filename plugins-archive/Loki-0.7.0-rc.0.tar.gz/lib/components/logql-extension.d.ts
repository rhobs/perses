import { LRLanguage } from '@codemirror/language';
import type { AbsoluteTimeRange } from '@perses-dev/spec';
import type { Extension } from '@uiw/react-codemirror';
import type { LokiClient } from '../model';
export interface CompletionConfig {
    /** a LokiClient instance, can be created with LokiDatasource.createClient() */
    client?: LokiClient;
    /** search for label values in a given time range */
    timeRange?: AbsoluteTimeRange;
}
export declare function createLogQLExtension(completionCfg?: CompletionConfig): Array<LRLanguage | Extension>;
//# sourceMappingURL=logql-extension.d.ts.map