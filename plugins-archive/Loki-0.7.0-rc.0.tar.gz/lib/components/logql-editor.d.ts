import type { ReactCodeMirrorProps } from '@uiw/react-codemirror';
import type { ReactElement } from 'react';
import type { CompletionConfig } from './logql-extension';
export type LogQLEditorProps = Omit<ReactCodeMirrorProps, 'theme' | 'extensions'> & {
    completionConfig?: CompletionConfig;
};
export declare function LogQLEditor(props: LogQLEditorProps): ReactElement;
//# sourceMappingURL=logql-editor.d.ts.map