import type { DatasourcePlugin } from '@perses-dev/plugin-system';
import type { LokiClient } from '../../model/loki-client';
import type { LokiDatasourceSpec } from './loki-datasource-types';
export declare const LokiDatasource: DatasourcePlugin<LokiDatasourceSpec, LokiClient>;
//# sourceMappingURL=LokiDatasource.d.ts.map