import type { VariablePlugin } from '@perses-dev/plugin-system';
import type { LokiLogQLVariableOptions } from './types';
export declare const LokiLogQLVariable: VariablePlugin<LokiLogQLVariableOptions>;
//# sourceMappingURL=LokiLogQLVariable.d.ts.map