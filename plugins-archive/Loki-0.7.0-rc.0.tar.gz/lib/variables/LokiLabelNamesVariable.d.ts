import type { VariablePlugin } from '@perses-dev/plugin-system';
import type { LokiLabelNamesVariableOptions } from './types';
export declare const LokiLabelNamesVariable: VariablePlugin<LokiLabelNamesVariableOptions>;
//# sourceMappingURL=LokiLabelNamesVariable.d.ts.map