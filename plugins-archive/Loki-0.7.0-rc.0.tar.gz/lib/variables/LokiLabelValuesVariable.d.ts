import type { VariablePlugin } from '@perses-dev/plugin-system';
import type { LokiLabelValuesVariableOptions } from './types';
export declare const LokiLabelValuesVariable: VariablePlugin<LokiLabelValuesVariableOptions>;
//# sourceMappingURL=LokiLabelValuesVariable.d.ts.map