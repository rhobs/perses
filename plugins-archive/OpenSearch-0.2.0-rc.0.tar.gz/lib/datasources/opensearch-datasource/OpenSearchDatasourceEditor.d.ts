import type { DatasourceEditorProps } from '@perses-dev/plugin-system';
import type { ReactElement } from 'react';
import type { OpenSearchDatasourceSpec } from './opensearch-datasource-types';
export type OpenSearchDatasourceEditorProps = DatasourceEditorProps<OpenSearchDatasourceSpec>;
export declare function OpenSearchDatasourceEditor(props: OpenSearchDatasourceEditorProps): ReactElement;
//# sourceMappingURL=OpenSearchDatasourceEditor.d.ts.map