import type { DatasourcePlugin } from '@perses-dev/plugin-system';
import type { OpenSearchClient } from '../../model/opensearch-client';
import type { OpenSearchDatasourceSpec } from './opensearch-datasource-types';
export declare const OpenSearchDatasource: DatasourcePlugin<OpenSearchDatasourceSpec, OpenSearchClient>;
//# sourceMappingURL=OpenSearchDatasource.d.ts.map