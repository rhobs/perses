import type { OptionsEditorProps } from '@perses-dev/plugin-system';
import type { ReactElement } from 'react';
import type { OpenSearchLogQuerySpec } from './opensearch-log-query-types';
type OpenSearchQueryEditorProps = OptionsEditorProps<OpenSearchLogQuerySpec>;
export declare function OpenSearchLogQueryEditor(props: OpenSearchQueryEditorProps): ReactElement;
export {};
//# sourceMappingURL=OpenSearchLogQueryEditor.d.ts.map