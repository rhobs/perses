export { getPluginModule } from './getPluginModule';
export { HistogramChartPanel } from './components';
export * from './histogram-chart-model';
export * from './HistogramChart';
//# sourceMappingURL=index.d.ts.map