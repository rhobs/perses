import { ReactElement } from 'react';
export interface AddFilterItemProps {
    onClick: () => void;
}
export declare function AddFilterItem(props: AddFilterItemProps): ReactElement;
//# sourceMappingURL=AddFilterItem.d.ts.map