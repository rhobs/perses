import { ReactElement } from 'react';
export interface DeleteFilterItemProps {
    onClick: () => void;
}
export declare function DeleteFilterItem(props: DeleteFilterItemProps): ReactElement;
//# sourceMappingURL=DeleteFilterItem.d.ts.map