import { ReactElement } from 'react';
export declare function PyroscopeExplorer(): ReactElement;
//# sourceMappingURL=PyroscopeExplorer.d.ts.map